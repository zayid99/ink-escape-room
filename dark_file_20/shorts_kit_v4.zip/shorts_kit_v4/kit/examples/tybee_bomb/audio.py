"""Original music + sound effects for Dark File #19, mixed under the narration.
Everything is synthesized here (no samples). Output: audio/mix.wav (48 kHz stereo, about -14 LUFS)."""
import json, numpy as np, soundfile as sf
from scipy import signal
import pyloudnorm as pyln

ROOT = "/home/claude/short"
SR = 48000
tl = json.load(open(f"{ROOT}/web/timeline.json"))
DUR = tl["dur"]
N = int(DUR * SR)
t = np.arange(N) / SR
rng = np.random.default_rng(7)
S = tl["segs"]
mid = lambda a, b: (S[a]["t1"] + S[b]["t0"]) / 2
CUTS = [0, mid(0, 1), mid(1, 2), mid(2, 3), mid(3, 4), mid(5, 6), mid(6, 7), DUR]
T_COMPLETE = next(w["t0"] for w in tl["words"] if w["w"].startswith("complete"))

# ---------- helpers ----------
def env_ad(n, a, d):
    e = np.ones(n); na = max(1, int(a * SR)); e[:na] = np.linspace(0, 1, na)
    e *= np.exp(-np.arange(n) / SR / max(d, 1e-3)); return e
def lp(x, fc, order=2): b, a = signal.butter(order, fc / (SR / 2), 'low'); return signal.lfilter(b, a, x)
def hp(x, fc, order=2): b, a = signal.butter(order, fc / (SR / 2), 'high'); return signal.lfilter(b, a, x)
def bp(x, lo, hi, order=2): b, a = signal.butter(order, [lo / (SR / 2), hi / (SR / 2)], 'band'); return signal.lfilter(b, a, x)
def reverb(x, dur=2.2, wet=0.3, seed=1):
    r = np.random.default_rng(seed); n = int(dur * SR)
    ir = r.standard_normal(n) * np.exp(-np.arange(n) / SR * (6.9 / dur)); ir = lp(ir, 5000); ir /= np.sqrt((ir ** 2).sum())
    y = signal.fftconvolve(x, ir)[:len(x)]; return x * (1 - wet) + y * wet * 3
def place(buf, x, at, gain=1.0):
    i = int(at * SR)
    if i >= len(buf): return
    j = min(len(buf), i + len(x)); buf[i:j] += x[: j - i] * gain
def db(v): return 10 ** (v / 20)

music = np.zeros(N); sfx = np.zeros(N)

# ---------- music: a low drone bed in D minor that thins out for the turn ----------
def drone_part(f, amp, lfo):
    ph = 2 * np.pi * f * t + 0.4 * np.sin(2 * np.pi * lfo * t)
    return amp * (np.sin(ph) + 0.35 * np.sin(2 * ph + 0.3) + 0.12 * np.sin(3 * ph + 1.1))
bed = drone_part(55.0, 1.0, 0.07) + drone_part(82.41, 0.55, 0.05) + drone_part(110.0, 0.3, 0.09) + drone_part(130.81, 0.18, 0.04)
wash = lp(hp(rng.standard_normal(N), 180), 900) * 0.25 * (0.6 + 0.4 * np.sin(2 * np.pi * 0.11 * t))
bed = bed + wash
lvl = np.ones(N)
def ramp(a, b, va, vb):
    i, j = int(a * SR), int(b * SR); lvl[i:j] = np.linspace(va, vb, j - i)
t_turn = CUTS[4]
lvl[:] = 1.0
ramp(t_turn - 0.25, t_turn + 0.1, 1.0, 0.18)           # drop out at the turn
lvl[int((t_turn + 0.1) * SR):int((T_COMPLETE - 0.8) * SR)] = 0.18
ramp(T_COMPLETE - 0.8, T_COMPLETE, 0.18, 0.55)
ramp(T_COMPLETE, T_COMPLETE + 0.05, 0.55, 1.15)
lvl[int((T_COMPLETE + 0.05) * SR):] = 1.0
music += bed * lvl * 0.32
# a slow two-note motif (minor second) in shots 2-4 for tension
for k, at in enumerate(np.arange(CUTS[1], CUTS[4] - 0.5, 1.6)):
    f = 293.66 if k % 2 == 0 else 311.13
    n = int(1.5 * SR); tt = np.arange(n) / SR
    tone = (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2 * f * tt)) * env_ad(n, 0.05, 0.6)
    place(music, reverb(tone, 1.8, 0.45, k + 3), at, 0.10)
# heartbeat pulse during the turn
for at in np.arange(t_turn + 0.4, T_COMPLETE - 0.1, 0.92):
    for off, g in ((0, 1.0), (0.18, 0.6)):
        n = int(0.25 * SR); tt = np.arange(n) / SR
        thump = np.sin(2 * np.pi * (48 + 30 * np.exp(-tt * 30)) * tt) * env_ad(n, 0.004, 0.07)
        place(music, thump, at + off, 0.55 * g)

# ---------- sound effects ----------
def ping(gain=1.0):
    n = int(0.9 * SR); tt = np.arange(n) / SR
    x = np.sin(2 * np.pi * 1180 * tt * (1 - 0.04 * tt)) * env_ad(n, 0.002, 0.16)
    return reverb(x, 2.4, 0.55, 5) * gain
def jet(dur, seed):
    n = int(dur * SR); r = np.random.default_rng(seed).standard_normal(n)
    tt = np.arange(n) / SR
    x = bp(r, 120, 2600) * (0.4 + 0.6 * np.clip(tt / dur, 0, 1) ** 2) + 0.4 * np.sin(2 * np.pi * (300 + 400 * tt / dur) * tt) * 0.15
    return x
def crunch():
    n = int(1.6 * SR); tt = np.arange(n) / SR
    nz = rng.standard_normal(n) * env_ad(n, 0.001, 0.12)
    thump = np.sin(2 * np.pi * (70 + 60 * np.exp(-tt * 20)) * tt) * env_ad(n, 0.001, 0.25)
    metal = sum(np.sin(2 * np.pi * f * tt + p) * env_ad(n, 0.001, d) for f, p, d in ((523, 0.1, 0.5), (787, 1.2, 0.35), (1213, 2.0, 0.25), (1730, 0.7, 0.18)))
    return reverb(bp(nz, 200, 6000) * 1.2 + thump * 1.3 + metal * 0.35, 1.6, 0.3, 9)
def clank(gain=1.0):
    n = int(0.6 * SR); tt = np.arange(n) / SR
    x = sum(np.sin(2 * np.pi * f * tt) * env_ad(n, 0.001, d) for f, d in ((180, 0.15), (420, 0.08), (960, 0.05)))
    x += bp(rng.standard_normal(n), 300, 3000) * env_ad(n, 0.001, 0.03)
    return reverb(x, 0.9, 0.25, 11) * gain
def whistle(dur):
    n = int(dur * SR); tt = np.arange(n) / SR
    f = 1500 * (1 - 0.6 * tt / dur); ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * 0.35 + bp(rng.standard_normal(n), 400, 2500) * 0.5
    return x * np.clip(tt / dur, 0, 1) ** 1.5
def splash():
    n = int(2.5 * SR); tt = np.arange(n) / SR
    nz = lp(rng.standard_normal(n), 3500) * env_ad(n, 0.005, 0.35)
    boom = np.sin(2 * np.pi * (45 + 40 * np.exp(-tt * 12)) * tt) * env_ad(n, 0.002, 0.5)
    bub = np.zeros(n)
    for k in range(40):
        a = int(rng.uniform(0.15, 2.0) * SR); m = int(0.06 * SR)
        if a + m < n:
            f0 = rng.uniform(250, 900); tb = np.arange(m) / SR
            bub[a:a + m] += np.sin(2 * np.pi * f0 * (1 + 3 * tb) * tb) * np.exp(-tb * 60) * 0.4
    return nz * 1.1 + boom * 1.3 + bub * 0.6
def whoosh(dur, rise=True):
    n = int(dur * SR); tt = np.arange(n) / SR
    e = (tt / dur) ** 2 if rise else np.exp(-tt * 4)
    return bp(rng.standard_normal(n), 150, 1800) * e
def waves(dur, seed):
    n = int(dur * SR); tt = np.arange(n) / SR
    x = lp(np.random.default_rng(seed).standard_normal(n), 700) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.35 * tt) ** 2)
    return x
def hit_low():
    n = int(3.0 * SR); tt = np.arange(n) / SR
    x = np.sin(2 * np.pi * (38 + 50 * np.exp(-tt * 9)) * tt) * env_ad(n, 0.002, 0.9)
    x += lp(rng.standard_normal(n), 900) * env_ad(n, 0.001, 0.25) * 0.6
    return reverb(x, 3.0, 0.35, 13)

# shot 1 + shot 7: sonar pings (the last one lands right before the loop point)
for at in (0.02, 1.62, 3.22):
    place(sfx, ping(), at, 0.32)
for at in (CUTS[6] + 0.15, CUTS[6] + 1.75, DUR - 0.35):
    place(sfx, ping(), at, 0.30)
# shot 2: jet roar builds into the impact; then the parachute
T_HIT = CUTS[1] + 2.02
place(sfx, jet(T_HIT - CUTS[1], 3), CUTS[1], 0.22)
place(sfx, whoosh(0.6, True), T_HIT - 0.6, 0.35)
place(sfx, crunch(), T_HIT, 0.75)
place(sfx, whoosh(1.2, False) * 0.6, T_HIT + 0.9, 0.25)
# shot 3: bay doors, release, falling whistle, splash
place(sfx, clank(0.6), CUTS[2] + 0.05, 0.6)
place(sfx, clank(1.0), CUTS[2] + 0.62, 0.7)
place(sfx, whistle(CUTS[2] + 2.55 - (CUTS[2] + 0.75)), CUTS[2] + 0.75, 0.22)
place(sfx, splash(), CUTS[2] + 2.55, 0.8)
# shot 4: water and distant boat engines; pings that find nothing
place(sfx, waves(CUTS[4] - CUTS[3], 4), CUTS[3], 0.18)
n = int((CUTS[4] - CUTS[3]) * SR); tt = np.arange(n) / SR
place(sfx, lp(np.sin(2 * np.pi * 38 * tt) * (0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 7 * tt))), 200), CUTS[3], 0.12)
for at in np.arange(CUTS[3] + 0.3, CUTS[4] - 0.4, 1.2):
    place(sfx, ping(), at, 0.18)
# shot 5: swell into a hard low hit on "complete"
place(sfx, whoosh(0.9, True), T_COMPLETE - 0.9, 0.3)
place(sfx, hit_low(), T_COMPLETE, 0.85)
# shot 6: rising rumble, the surface break, then waves and wind
T_SURF = CUTS[5] + 1.99
place(sfx, lp(whoosh(T_SURF - CUTS[5], True), 600), CUTS[5], 0.45)
place(sfx, splash() * 0.5, T_SURF, 0.45)
place(sfx, waves(CUTS[6] - T_SURF + 0.4, 8), T_SURF, 0.22)

# ---------- mix ----------
vo, vsr = sf.read(f"{ROOT}/audio/vo.wav")
vo = signal.resample_poly(vo, SR, vsr)[:N]
vo = np.pad(vo, (0, max(0, N - len(vo))))
# set music/effects levels relative to the voice (measured where the voice is active)
act = np.abs(vo) > 0.01
vrms = np.sqrt((vo[act] ** 2).mean())
music *= vrms * db(-17) / np.sqrt((music ** 2).mean())
sfx *= vrms * db(-9) / np.sqrt((sfx ** 2).mean())
# duck music + effects under the voice
env = np.abs(vo); env = lp(env, 6) ; env = env / (env.max() + 1e-9)
duck = 1 - 0.45 * np.clip(env * 4, 0, 1)
mus = music * duck
fx = sfx * (1 - 0.25 * np.clip(env * 4, 0, 1))
# simple stereo: music wide, voice centered
L = vo * 1.0 + mus * 0.9 + fx * 0.95 + np.roll(mus, 240) * 0.1
R = vo * 1.0 + mus * 0.9 + fx * 0.95 + np.roll(mus, -240) * 0.1
mix = np.stack([L, R], 1)
meter = pyln.Meter(SR)
loud = meter.integrated_loudness(mix)
mix = pyln.normalize.loudness(mix, loud, -14.0)
pk = np.abs(mix).max()
if pk > db(-1.0):
    # soft limit the few peaks above -1 dBFS
    th = db(-1.0); mix = np.where(np.abs(mix) > th * 0.8, np.sign(mix) * (th * 0.8 + (th * 0.2) * np.tanh((np.abs(mix) - th * 0.8) / (th * 0.2))), mix)
sf.write(f"{ROOT}/audio/mix.wav", mix.astype(np.float32), SR)
print("loudness", round(meter.integrated_loudness(mix), 2), "LUFS, peak", round(float(np.abs(mix).max()), 3), "dur", round(len(mix) / SR, 2))
print("music:voice (dB)", round(20 * np.log10(np.sqrt((mus ** 2).mean()) / vrms), 1), " sfx:voice", round(20 * np.log10(np.sqrt((fx ** 2).mean()) / vrms), 1), " sfx peak:voice peak", round(20 * np.log10(np.abs(fx).max() / np.abs(vo).max()), 1))
