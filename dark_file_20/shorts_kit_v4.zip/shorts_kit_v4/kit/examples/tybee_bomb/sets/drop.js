// Shot 3: bay doors open under the damaged bomber, the bomb drops away, then hits the black sea.
import * as THREE from 'three';
import { makeBomber, makeBomb, skyDome, stars, sprite, glowTex, radialTex, waterNormalTex, glitter, rng, clamp, lerp, smooth, ease, wobble } from '../lib.js';
import { cloudLayer } from './sky.js';

export function seaSurface(size = 3000) {
  const nt = waterNormalTex(4);
  const mat = new THREE.MeshStandardMaterial({ color: 0x0a1b24, emissive: 0x03080b, roughness: 0.42, metalness: 0.0, normalMap: nt, normalScale: new THREE.Vector2(0.45, 0.45) });
  const m = new THREE.Mesh(new THREE.PlaneGeometry(size, size), mat); m.rotation.x = -Math.PI / 2;
  m.userData.update = (t) => { nt.offset.set(t * 0.004, t * 0.006); };
  return m;
}
export function coastLights(n, z, xr, y, seed) {
  const g = new THREE.Group(); const R = rng(seed); const tex = glowTex();
  for (let i = 0; i < n; i++) { const s = sprite(tex, R() > 0.85 ? 0xfff2d8 : 0xffc777, 2 + R() * 3, 0.55 + R() * 0.4); s.position.set((R() - 0.5) * xr, y + R() * 3, z + (R() - 0.5) * 30); g.add(s); }
  return g;
}

export function build() {
  // --- A: under the bomber ---
  const A = new THREE.Scene();
  A.add(skyDome([[0, '#04091a'], [0.4, '#081129'], [0.5, '#14203a'], [0.6, '#0a1222'], [1, '#03060c']]));
  const halo = new THREE.Mesh(new THREE.PlaneGeometry(3000, 3000), new THREE.MeshBasicMaterial({ map: radialTex([[0, 'rgba(70,95,150,0.9)'], [0.25, 'rgba(30,45,85,0.55)'], [0.6, 'rgba(10,18,40,0.2)'], [1, 'rgba(0,0,0,0)']], 512), transparent: true, depthWrite: false, fog: false }));
  halo.rotation.x = Math.PI / 2; halo.position.set(-60, 690, 120); A.add(halo);
  A.add(stars(1200, 850, 33));
  A.add(new THREE.HemisphereLight(0x3b4d78, 0x0a0c10, 1.0));
  const ml = new THREE.DirectionalLight(0xc8d6ff, 2.2); ml.position.set(-60, 700, 120); A.add(ml);
  const under = new THREE.DirectionalLight(0x8094c0, 1.5); under.position.set(80, -300, 60); A.add(under);
  const bayLight = new THREE.PointLight(0xe8f0ff, 3.5, 9, 1.5); bayLight.position.set(-0.5, -2.2, 0); A.add(bayLight);
  const bomber = makeBomber(); A.add(bomber);
  const bombA = makeBomb('air'); A.add(bombA);
  const camA = new THREE.PerspectiveCamera(46, 1080 / 1920, 0.1, 3000);

  // --- B: the sea ---
  const B = new THREE.Scene();
  B.add(skyDome([[0, '#020309'], [0.42, '#081022'], [0.5, '#1a2840'], [0.52, '#0b1424'], [1, '#02050a']]));
  B.add(stars(900, 850, 35, 0.12));
  B.fog = new THREE.Fog(0x0a1424, 150, 1400);
  B.add(new THREE.HemisphereLight(0x33476e, 0x05080c, 0.5));
  const mlB = new THREE.DirectionalLight(0xd2deff, 0.8); mlB.position.set(500, 260, 300); B.add(mlB);
  const moon = sprite(radialTex([[0, 'rgba(255,255,255,1)'], [0.12, 'rgba(240,244,255,1)'], [0.16, 'rgba(200,215,255,0.35)'], [0.5, 'rgba(120,150,220,0.08)'], [1, 'rgba(0,0,0,0)']]), 0xffffff, 120, 1); moon.position.set(150, 95, -780); B.add(moon);
  const gl = glitter(7000, 3, new THREE.Vector3(2, 0.2, 4), new THREE.Vector3(150, 0.2, -760), 7, 60); B.add(gl);
  const bombLight = new THREE.PointLight(0xc8d6ff, 40, 30, 1.5); B.add(bombLight);
  const sea = seaSurface(); B.add(sea);
  B.add(coastLights(70, -700, 900, 2, 12));
  const land = new THREE.Mesh(new THREE.BoxGeometry(2000, 6, 60), new THREE.MeshBasicMaterial({ color: 0x020406 })); land.position.set(0, 2, -730); B.add(land);
  const bombB = makeBomb('air'); B.add(bombB);
  // splash: rising droplets + foam disc + expanding ring
  const NS = 500, R = rng(91);
  const sv = []; for (let i = 0; i < NS; i++) { const a = R() * 6.283, s = R(); sv.push(new THREE.Vector3(Math.cos(a) * (1 + s * 5), 10 + R() * 22 * (1 - s * 0.6), Math.sin(a) * (1 + s * 5))); }
  const sp = new Float32Array(NS * 3); const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(sp, 3));
  const drops = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xdfeef5, size: 0.7, map: glowTex(), transparent: true, depthWrite: false, opacity: 0 }));
  B.add(drops);
  const foam = sprite(glowTex(), 0xe8f4f8, 1, 0, false); foam.position.y = 0.3; B.add(foam);
  const ringM = new THREE.MeshBasicMaterial({ color: 0xcfe6ee, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false });
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.9, 1.0, 72), ringM); ring.rotation.x = -Math.PI / 2; ring.position.y = 0.1; B.add(ring);
  const camB = new THREE.PerspectiveCamera(40, 1080 / 1920, 0.5, 4000);

  const SPLIT = 1.95, REL = 0.62, HIT = 2.55;
  const out = { scene: A, camera: camA, bloom: 0.5 };
  out.update = (t, u) => {
    if (u < SPLIT) {
      out.scene = A; out.camera = camA;
      bomber.userData.beacon.visible = (u % 1.1) < 0.12;
      bomber.rotation.set(0.05 + Math.sin(u * 2) * 0.01, 0, -0.04);
      const op = ease(clamp(u / 0.5));
      bomber.userData.doors[0].rotation.x = -op * 1.45; bomber.userData.doors[1].rotation.x = op * 1.45;
      const dt = Math.max(0, u - REL);
      // carried horizontal (nose toward -X), then falls and pitches nose-down, drifting back
      const p = new THREE.Vector3(-0.5 + 2.2 * dt * dt, -1.25 - 6.5 * dt * dt, 0);
      p.applyEuler(bomber.rotation); bombA.position.copy(p);
      bombA.rotation.set(0, 0, -Math.PI / 2 + 0.9 * smooth(0, 1.3, dt));
      const look = new THREE.Vector3(-0.5, -1.6, 0).lerp(bombA.position.clone().add(new THREE.Vector3(0, -1, 0)), smooth(0.1, 1.2, dt));
      camA.up.set(-1, 0, 0);
      camA.position.set(2.0 + wobble(u, 0.9, 3) * 0.15, -15 + dt * 1.2, 3.2);
      camA.lookAt(look.x + 1.5, look.y, look.z + 1.0); camA.updateMatrixWorld();
    } else {
      out.scene = B; out.camera = camB;
      const v = u - SPLIT, dh = u - HIT;
      sea.userData.update(t); gl.userData.update(t);
      // falls in from above the frame, nose down
      const y = dh < 0 ? 0.6 + 34 * Math.pow(-dh / (HIT - SPLIT), 1.6) : -50;
      bombB.visible = dh < 0.02; bombB.position.set(0, y + 1.8, 0); bombB.rotation.set(0.15, 0, 0.25); bombLight.position.set(5, y + 6, 8); bombLight.intensity = dh < 0 ? 40 : 0;
      const s = Math.max(0, dh);
      drops.material.opacity = dh > 0 ? Math.max(0, 1 - s / 1.0) : 0;
      for (let i = 0; i < NS; i++) { sp[i * 3] = sv[i].x * s; sp[i * 3 + 1] = Math.max(0, sv[i].y * s - 16 * s * s); sp[i * 3 + 2] = sv[i].z * s; }
      sg.attributes.position.needsUpdate = true;
      foam.material.opacity = dh > 0 ? 0.85 * Math.exp(-s * 1.4) : 0; foam.scale.set(6 + s * 22, 6 + s * 22, 1);
      ringM.opacity = dh > 0 ? 0.7 * Math.exp(-s * 1.2) : 0; ring.scale.setScalar(2 + s * 16);
      const sh = dh > 0 ? Math.exp(-dh * 5) * 0.35 : 0;
      camB.position.set(4 + wobble(u, 3, 1) * sh, 9.5 - v * 0.5 + wobble(u, 2.6, 2) * sh, 34 - v * 1.6);
      camB.lookAt(0, 4.5, 0); camB.updateMatrixWorld();
    }
  };
  return out;
}
