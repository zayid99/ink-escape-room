// Shot 6: from the buried bomb, up through dark water, breaking the surface: quiet Georgia coast at night.
import * as THREE from 'three';
import { skyDome, stars, sprite, glowTex, radialTex, canvasTex, waterNormalTex, glitter, rng, clamp, lerp, smooth, ease, wobble } from '../lib.js';
import { addSeabed, addWater } from './cut.js';
import { coastLights } from './drop.js';

const SURF = 9;

function lighthouse() {
  const g = new THREE.Group();
  const tex = canvasTex(64, 512, (c, W, H) => { c.fillStyle = '#e8e6df'; c.fillRect(0, 0, W, H); c.fillStyle = '#121416'; c.fillRect(0, 0, W, H * 0.38); });
  const tower = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 2.6, 34, 24), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.8 }));
  tower.position.y = 17; g.add(tower);
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(1.9, 1.9, 2.6, 16), new THREE.MeshStandardMaterial({ color: 0x15181b })); cap.position.y = 35.3; g.add(cap);
  const lamp = sprite(glowTex(), 0xfff1c8, 14, 1); lamp.position.y = 35.3; g.add(lamp);
  g.userData.lamp = lamp;
  const beam = new THREE.Mesh(new THREE.ConeGeometry(9, 260, 24, 1, true), new THREE.MeshBasicMaterial({ color: 0xfff1c8, transparent: true, opacity: 0.05, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false }));
  beam.geometry.translate(0, -130, 0); beam.rotation.z = Math.PI / 2; const piv = new THREE.Group(); piv.position.y = 35.3; piv.add(beam); g.add(piv); beam.visible = false;
  g.userData.piv = piv;
  return g;
}

export function build() {
  const scene = new THREE.Scene();
  // underwater part (same seabed as shot 1)
  const W = addWater(scene, { seed: 12, density: 0.03 });
  const S = addSeabed(scene, { seed: 4 });
  const uwBack = scene.background.clone();
  // above-water world
  const above = new THREE.Group(); scene.add(above);
  above.add(skyDome([[0, '#010207'], [0.38, '#071026'], [0.48, '#1b2a48'], [0.5, '#2c3550'], [0.505, '#0a1322'], [1, '#02050a']]));
  above.add(stars(1400, 850, 61, 0.06));
  const moon = sprite(radialTex([[0, 'rgba(255,255,255,1)'], [0.12, 'rgba(240,244,255,1)'], [0.16, 'rgba(200,215,255,0.35)'], [0.5, 'rgba(120,150,220,0.08)'], [1, 'rgba(0,0,0,0)']]), 0xffffff, 110, 1); moon.position.set(150, SURF + 95, -800); above.add(moon);
  const gl = glitter(7000, 7, new THREE.Vector3(1, SURF + 0.15, 2), new THREE.Vector3(150, SURF + 0.15, -330), 6, 60); above.add(gl);
  const ml = new THREE.DirectionalLight(0xd2deff, 0.7); ml.position.set(500, 260, 300); scene.add(ml);
  const land = new THREE.Mesh(new THREE.BoxGeometry(1600, 7, 80), new THREE.MeshStandardMaterial({ color: 0x07090b, roughness: 1 })); land.position.set(0, SURF + 1.5, -330); above.add(land);
  const trees = new THREE.Group(); const R = rng(8); const tm = new THREE.MeshStandardMaterial({ color: 0x050708, roughness: 1 });
  for (let i = 0; i < 120; i++) { const h = 6 + R() * 12; const tr = new THREE.Mesh(new THREE.ConeGeometry(2 + R() * 3, h, 6), tm); tr.position.set((R() - 0.5) * 1200, SURF + 4 + h / 2, -345 - R() * 30); trees.add(tr); }
  above.add(trees);
  above.add(coastLights(140, -300, 1000, SURF + 3, 21));
  const lh = lighthouse(); lh.position.set(-70, SURF + 3, -305); above.add(lh);
  // the water surface, seen from below and from above
  const nt = waterNormalTex(9);
  const top = new THREE.Mesh(new THREE.PlaneGeometry(3000, 3000), new THREE.MeshStandardMaterial({ color: 0x0a1b24, emissive: 0x03080b, roughness: 0.42, metalness: 0.0, normalMap: nt, normalScale: new THREE.Vector2(0.45, 0.45) }));
  top.rotation.x = -Math.PI / 2; top.position.y = SURF; scene.add(top);
  const under = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshStandardMaterial({ color: 0x2c6f76, emissive: 0x1c4e54, emissiveIntensity: 0.9, roughness: 0.3, normalMap: nt, side: THREE.BackSide, transparent: true, opacity: 0.92 }));
  under.rotation.x = -Math.PI / 2; under.position.y = SURF - 0.01; scene.add(under);
  const fogAbove = new THREE.Fog(0x0b1324, 120, 900), fogBelow = scene.fog;

  const camera = new THREE.PerspectiveCamera(38, 1080 / 1920, 0.05, 3000);
  const update = (t, u, shot) => {
    W.parts.userData.update(t); W.shafts.userData.update(t); S.grass.userData.update(t);
    nt.offset.set(t * 0.004, t * 0.006);
    lh.userData.piv.rotation.y = t * 1.1; gl.userData.update(t);
    lh.userData.lamp.material.opacity = 0.35 + 0.65 * Math.pow(Math.max(0, Math.cos(t * 1.1)), 8);
    const d = shot.t1 - shot.t0;
    const k = ease(smooth(0.35, d - 0.55, u));
    const y = lerp(-0.6, SURF + 1.6, k);
    const z = lerp(9.5, 22, k);
    camera.position.set(lerp(0.9, 0, k) + wobble(t, 0.1, 3) * 0.05, y, z);
    const look = new THREE.Vector3(0.15, -2.1, 0).lerp(new THREE.Vector3(0, SURF + 4.5, -300), smooth(0.25, 0.9, k));
    camera.lookAt(look); camera.updateMatrixWorld();
    const aboveW = y > SURF;
    scene.fog = aboveW ? fogAbove : fogBelow;
    scene.background = aboveW ? new THREE.Color(0x02050a) : uwBack;
    above.visible = aboveW || y > SURF - 3;
    W.parts.visible = !aboveW; W.shafts.visible = !aboveW;
    scene.children.forEach((c) => { if (c.isMesh && c.geometry && c.geometry.parameters && c.geometry.parameters.width === 400 && c.geometry.parameters.height === 160) c.visible = !aboveW; });
  };
  return { scene, camera, update, bloom: 0.5 };
}
