// Shot 5 (the turn): close on the buried bomb. The casing fades to an x-ray outline and shows
// an empty space with a question mark ("core removed"). On "complete weapon" a warning glow pulses there.
import * as THREE from 'three';
import { makeBomb, driftParticles, lightShafts, gradientTex, sprite, glowTex, clamp, lerp, smooth, ease, wobble } from '../lib.js';

function xrayMat() {
  return new THREE.ShaderMaterial({
    uniforms: { uOp: { value: 0 }, uCol: { value: new THREE.Color(0x63e6f0) } },
    vertexShader: `varying vec3 vN; varying vec3 vV; void main(){ vec4 mv = modelViewMatrix * vec4(position,1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `uniform float uOp; uniform vec3 uCol; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(clamp(1.0 - abs(dot(normalize(vN), normalize(vV))), 0.0, 1.0), 2.2); gl_FragColor = vec4(uCol * (0.08 + 1.25 * f), (0.05 + 0.9 * f) * uOp); }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
  });
}

export function build() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x041214);
  scene.fog = new THREE.FogExp2(0x061a1e, 0.045);
  const back = new THREE.Mesh(new THREE.PlaneGeometry(200, 120), new THREE.MeshBasicMaterial({ map: gradientTex([[0, '#1d555b'], [0.4, '#0b2a2f'], [1, '#020809']]), fog: false }));
  back.position.set(0, 10, -40); scene.add(back);
  scene.add(new THREE.HemisphereLight(0x5ea6ae, 0x2a2318, 0.8));
  const key = new THREE.SpotLight(0xfff0dc, 70, 25, 0.55, 0.6, 1.4); key.position.set(-4, 3, 6); scene.add(key, key.target);
  const rim = new THREE.PointLight(0x5fd2dc, 14, 10, 1.5); rim.position.set(2.6, 1.0, -1.5); scene.add(rim);
  const parts = driftParticles(700, new THREE.Box3(new THREE.Vector3(-5, -5, -5), new THREE.Vector3(5, 5, 6)), 14, 0xcfe6ea, 0.035, 0.5); scene.add(parts);
  const shafts = lightShafts(6, 3, { x0: -5, dx: 10, y: 8, z0: -8, dz: 5, w: 1.2, h: 18 }); scene.add(shafts);

  const pivot = new THREE.Group(); scene.add(pivot);
  const bomb = makeBomb('sea'); pivot.add(bomb);
  pivot.rotation.z = -0.12;
  // x-ray twin
  const xr = []; const ghost = new THREE.Group(); pivot.add(ghost);
  const solids = [];
  bomb.traverse((o) => {
    if (o.isMesh) {
      solids.push(o); o.material = o.material.clone(); o.material.transparent = true;
      const m = xrayMat(); xr.push(m);
      const g = o.isInstancedMesh ? null : new THREE.Mesh(o.geometry, m);
      if (g) { g.position.copy(o.position); g.rotation.copy(o.rotation); g.scale.copy(o.scale); ghost.add(g); }
    }
  });
  // the empty space where the nuclear core would sit: a simple outline, no internal detail
  const C = new THREE.Vector3(0, 0.1, 0);
  const wire = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.IcosahedronGeometry(0.27, 1)), new THREE.LineBasicMaterial({ color: 0x8ff3fb, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending }));
  wire.position.copy(C); pivot.add(wire);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.36, 0.006, 6, 80), new THREE.MeshBasicMaterial({ color: 0x8ff3fb, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending }));
  ring.rotation.x = Math.PI / 2; ring.position.copy(C); pivot.add(ring);
  const glow = sprite(glowTex(), 0xffa040, 1, 0); glow.position.copy(C); pivot.add(glow);
  const glowL = new THREE.PointLight(0xff9a40, 0, 6, 1.6); glowL.position.copy(C); pivot.add(glowL);

  const camera = new THREE.PerspectiveCamera(36, 1080 / 1920, 0.05, 400);
  let tCW = null; // set from the timeline: when "complete" is spoken
  const out = { scene, camera, bloom: 0.6 };
  out.update = (t, u, shot) => {
    if (tCW === null) tCW = (window.__tl && window.__tl.words.find((w) => w.w.startsWith('complete'))?.t0) || (shot.t0 + 6.7);
    parts.userData.update(t); shafts.userData.update(t);
    bomb.rotation.y = 0.6 + u * 0.12; ghost.rotation.y = bomb.rotation.y;
    // casing fades to an x-ray outline on "nuclear core"
    const k = smooth(0.7, 1.7, u);
    solids.forEach((o) => { o.material.opacity = 1 - k; o.visible = k < 0.999; });
    xr.forEach((m) => { m.uniforms.uOp.value = k; });
    const w = smooth(1.4, 2.0, u);
    const dc = t - tCW;
    const warm = dc > 0 ? smooth(0, 0.35, dc) : 0;
    const col = new THREE.Color(0x8ff3fb).lerp(new THREE.Color(0xffb04a), warm);
    wire.material.color.copy(col); ring.material.color.copy(col);
    wire.material.opacity = 0.85 * w; ring.material.opacity = 0.7 * w;
    wire.rotation.y = u * 0.5; wire.rotation.x = u * 0.2;
    const pulse = dc > 0 ? (0.75 + 0.25 * Math.sin(dc * 9)) * smooth(0, 0.25, dc) : 0;
    glow.material.opacity = 0.9 * pulse; glow.scale.setScalar(0.6 + 1.6 * pulse);
    glowL.intensity = 30 * pulse;
    xr.forEach((m) => m.uniforms.uCol.value.copy(new THREE.Color(0x63e6f0).lerp(new THREE.Color(0xff9c4a), warm * 0.6)));
    // camera pushes in and orbits; the core space stays at frame center
    const p = ease(clamp(u / (shot.t1 - shot.t0)));
    const ang = lerp(0.45, -0.25, p), dist = lerp(7.2, 3.9, p);
    const sh = dc > 0 ? Math.exp(-dc * 4) * 0.06 : 0;
    const wc = C.clone().applyMatrix4(pivot.matrixWorld);
    camera.position.set(wc.x + Math.sin(ang) * dist + wobble(t, 3, 1) * sh, wc.y + lerp(0.9, 0.3, p) + wobble(t, 2.5, 2) * sh, wc.z + Math.cos(ang) * dist);
    camera.lookAt(wc); camera.updateMatrixWorld();
    key.target.position.copy(wc); key.target.updateMatrixWorld();
  };
  scene.updateMatrixWorld();
  return out;
}
