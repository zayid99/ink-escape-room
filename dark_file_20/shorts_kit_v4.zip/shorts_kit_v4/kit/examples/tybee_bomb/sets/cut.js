// Seabed cutaway: the bomb buried nose-down in mud, murky water above, sonar sweeping over it.
// Used by shot 1 (hook) and shot 7 (CTA loop back to shot 1's opening framing).
import * as THREE from 'three';
import { makeBomb, mudFaceTexture, sandTexture, gradientTex, driftParticles, lightShafts, glowTex, sprite, rng, lerp, ease, smooth, clamp, wobble } from '../lib.js';

export function addSeabed(scene, opts = {}) {
  const mud = mudFaceTexture();
  const sand = sandTexture(5);
  const sideMat = new THREE.MeshStandardMaterial({ color: 0x2a261f, roughness: 1 });
  const faceMat = new THREE.MeshStandardMaterial({ map: mud, roughness: 0.95, metalness: 0 });
  const topMat = new THREE.MeshStandardMaterial({ map: sand, roughness: 1 });
  const block = new THREE.Mesh(new THREE.BoxGeometry(16, 9, 8), [sideMat, sideMat, topMat, sideMat, faceMat, sideMat]);
  block.position.set(0, -4.5, -4); scene.add(block);
  // seabed continuing behind
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ map: sandTexture(40), roughness: 1 }));
  floor.rotation.x = -Math.PI / 2; floor.position.set(0, -0.02, -100); scene.add(floor);
  // the cut face edge: a thin bright lip so the cross-section reads
  const lip = new THREE.Mesh(new THREE.BoxGeometry(16, 0.04, 0.04), new THREE.MeshStandardMaterial({ color: 0x8c8068, roughness: 1 }));
  lip.position.set(0, 0, 0.0); scene.add(lip);
  // rocks, shells, a rusted chain, sea grass on top
  const R = rng(opts.seed || 4);
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x4a463d, roughness: 0.95, flatShading: true });
  for (let i = 0; i < 26; i++) {
    const r = new THREE.Mesh(new THREE.DodecahedronGeometry(0.08 + R() * 0.22, 0), rockMat);
    r.position.set((R() - 0.5) * 14, 0.02, -R() * 7.5); r.scale.y = 0.5 + R() * 0.4; r.rotation.set(R() * 3, R() * 3, R() * 3); scene.add(r);
  }
  const shellMat = new THREE.MeshStandardMaterial({ color: 0xcfc4a8, roughness: 0.7 });
  for (let i = 0; i < 30; i++) {
    const s = new THREE.Mesh(new THREE.SphereGeometry(0.06 + R() * 0.05, 10, 6, 0, 6.283, 0, 1.4), shellMat);
    s.position.set((R() - 0.5) * 14, 0.01, -R() * 7); s.scale.y = 0.4; s.rotation.y = R() * 6; scene.add(s);
  }
  const chainMat = new THREE.MeshStandardMaterial({ color: 0x5a3a22, roughness: 0.9, metalness: 0.4 });
  for (let i = 0; i < 18; i++) {
    const l = new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.025, 6, 14), chainMat);
    l.position.set(-5.2 + i * 0.15, 0.03, -1.2 - Math.sin(i * 0.4) * 0.4); l.rotation.set(Math.PI / 2, 0, i % 2 ? Math.PI / 2 : 0); l.rotation.y = i % 2 ? 0.0 : 0.3; scene.add(l);
  }
  const grass = new THREE.Group(); const gMat = new THREE.MeshStandardMaterial({ color: 0x3f5a36, roughness: 0.9, side: THREE.DoubleSide });
  for (let i = 0; i < 70; i++) {
    const h = 0.3 + R() * 0.7; const b = new THREE.Mesh(new THREE.PlaneGeometry(0.05, h, 1, 4), gMat);
    b.geometry.translate(0, h / 2, 0);
    const cx = (R() > 0.5 ? 1 : -1) * (2.5 + R() * 4.5);
    b.position.set(cx, 0, -0.3 - R() * 5); b.rotation.y = R() * 3; b.userData.ph = R() * 6; grass.add(b);
  }
  grass.userData.update = (t) => grass.children.forEach((b) => { b.rotation.z = Math.sin(t * 1.1 + b.userData.ph) * 0.18; });
  scene.add(grass);
  // dark hollow around the bomb on the cut face
  const hollow = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 5.2), new THREE.MeshBasicMaterial({ map: glowTex(), color: 0x000000, transparent: true, opacity: 0.55, depthWrite: false }));
  hollow.position.set(0.15, -2.1, 0.01); hollow.rotation.z = -0.3; scene.add(hollow);
  // the bomb, nose down, 1.5-4.5 m under the surface of the mud
  const bomb = makeBomb('sea');
  bomb.position.set(0.15, -2.1, 0.1); bomb.rotation.set(0.0, 0.9, -0.3);
  scene.add(bomb);
  return { bomb, grass };
}

export function addWater(scene, opts = {}) {
  const root = opts.root || scene;
  scene.fog = new THREE.FogExp2(opts.fog || 0x0a2328, opts.density || 0.03);
  const back = new THREE.Mesh(new THREE.PlaneGeometry(400, 160), new THREE.MeshBasicMaterial({ map: gradientTex([[0, '#2b6b72'], [0.35, '#123a40'], [0.7, '#081b1f'], [1, '#040b0d']]), fog: false }));
  back.position.set(0, 20, -60); root.add(back);
  scene.background = new THREE.Color(0x061316);
  root.add(new THREE.HemisphereLight(0x5ea6ae, 0x2a2318, 0.45));
  const moon = new THREE.DirectionalLight(0xa9d8e0, 1.0); moon.position.set(-4, 12, 6); root.add(moon);
  const key = new THREE.SpotLight(0xffe2c0, 170, 30, 0.33, 0.7, 1.4); key.position.set(-4.5, 1.5, 8); key.target.position.set(0.15, -2.0, 0); root.add(key, key.target);
  const rim = new THREE.PointLight(0x5fd2dc, 16, 12, 1.5); rim.position.set(3.0, -0.8, 2.4); root.add(rim);
  const parts = driftParticles(900, new THREE.Box3(new THREE.Vector3(-7, -0.2, -6), new THREE.Vector3(7, 9, 9)), opts.seed || 3, 0xcfe6ea, 0.045, 0.55);
  root.add(parts);
  const shafts = lightShafts(7, 9, { x0: -6, dx: 12, y: 9, z0: -8, dz: 7, w: 1.4, h: 18 });
  root.add(shafts);
  return { parts, shafts, key, rim };
}

export function addSonar(scene) {
  const g = new THREE.Group(); g.position.set(3.2, 7, -1.5); scene.add(g);
  const len = 8.4;
  const cone = new THREE.Mesh(new THREE.ConeGeometry(1.1, len, 40, 1, true), new THREE.MeshBasicMaterial({ color: 0x8ff6ff, transparent: true, opacity: 0.3, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false }));
  cone.geometry.translate(0, -len / 2, 0); // apex at the origin, opening downward
  g.add(cone);
  const core = new THREE.Mesh(new THREE.ConeGeometry(0.22, len, 16, 1, true), new THREE.MeshBasicMaterial({ color: 0xc8fbff, transparent: true, opacity: 0.4, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false }));
  core.geometry.translate(0, -len / 2, 0); g.add(core);
  const ringMat = new THREE.MeshBasicMaterial({ color: 0x8ff3fb, transparent: true, opacity: 0.0, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false });
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.92, 1.0, 64), ringMat); ring.rotation.x = -Math.PI / 2; scene.add(ring);
  const spot = sprite(glowTex(), 0x7feaf3, 2.6, 0.0); scene.add(spot);
  const update = (t) => {
    const a = -(Math.sin(t * 0.55) * 0.22 + 0.32); // sweep across the bomb
    g.rotation.z = a; g.rotation.x = Math.sin(t * 0.31) * 0.12;
    cone.material.opacity = 0.15 + 0.04 * Math.sin(t * 3.0); core.material.opacity = 0.2 + 0.06 * Math.sin(t * 3.0);
    // where the beam meets the seabed (y=0)
    const dir = new THREE.Vector3(0, -1, 0).applyEuler(g.rotation);
    const k = -g.position.y / dir.y; const hit = g.position.clone().addScaledVector(dir, k);
    const ph = (t % 1.6) / 1.6;
    ring.position.set(hit.x, 0.03, hit.z); ring.scale.setScalar(0.3 + ph * 2.2); ringMat.opacity = 0.55 * (1 - ph);
    spot.position.set(hit.x, 0.1, hit.z); spot.material.opacity = 0.35;
  };
  return { update };
}

export function build() {
  const scene = new THREE.Scene();
  const W = addWater(scene, { seed: 3 });
  const S = addSeabed(scene, { seed: 4 });
  const sonar = addSonar(scene);
  const camera = new THREE.PerspectiveCamera(36, 1080 / 1920, 0.1, 500);
  // P0 = opening framing (also the CTA end framing, for a clean loop)
  const P0 = { pos: new THREE.Vector3(0.9, -1.2, 12.8), look: new THREE.Vector3(0.15, -1.75, 0) };
  const P1 = { pos: new THREE.Vector3(0.7, -1.35, 11.3), look: new THREE.Vector3(0.15, -1.85, 0) };
  const PC = { pos: new THREE.Vector3(2.2, 0.6, 15.0), look: new THREE.Vector3(0.4, -1.2, 0) };
  const setCam = (a, b, k, t) => {
    camera.position.lerpVectors(a.pos, b.pos, k);
    camera.position.x += wobble(t, 0.07, 1) * 0.05; camera.position.y += wobble(t, 0.06, 2) * 0.04;
    const look = a.look.clone().lerp(b.look, k); camera.lookAt(look);
  };
  const update = (t, u, shot) => {
    W.parts.userData.update(t); W.shafts.userData.update(t); S.grass.userData.update(t); sonar.update(t);
    if (shot.id === 'cta') {
      const k = ease(clamp(u / (shot.t1 - shot.t0)));
      setCam(PC, P0, k, t);
    } else {
      const k = clamp(u / (shot.t1 - shot.t0));
      setCam(P0, P1, 1 - Math.pow(1 - k, 1.6), t);
    }
    camera.updateMatrixWorld();
  };
  return { scene, camera, update, P0 };
}
