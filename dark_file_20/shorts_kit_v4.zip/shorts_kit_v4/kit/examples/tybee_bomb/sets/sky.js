// Shot 2: night above the clouds over Georgia. The fighter climbs into the bomber's right wing.
import * as THREE from 'three';
import { makeBomber, makeFighter, skyDome, stars, sprite, glowTex, radialTex, canvasTex, rng, clamp, lerp, smooth, ease, wobble } from '../lib.js';

export function cloudLayer(y, size, seed, opacity = 0.9, tint = 0x3a4a63) {
  const tex = canvasTex(1024, 1024, (g, W, H) => {
    const R = rng(seed);
    g.clearRect(0, 0, W, H);
    for (let i = 0; i < 420; i++) {
      const x = R() * W, yy = R() * H, r = 30 + R() * 120;
      const gr = g.createRadialGradient(x, yy, 0, x, yy, r);
      const a = 0.08 + R() * 0.14;
      gr.addColorStop(0, `rgba(255,255,255,${a})`); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr;
      for (const dx of [-W, 0, W]) for (const dy of [-H, 0, H]) { g.save(); g.translate(dx, dy); g.fillRect(x - r, yy - r, 2 * r, 2 * r); g.restore(); }
    }
  }, { repeat: [3, 3] });
  const m = new THREE.Mesh(new THREE.PlaneGeometry(size, size), new THREE.MeshBasicMaterial({ map: tex, color: tint, transparent: true, opacity, depthWrite: false }));
  m.rotation.x = -Math.PI / 2; m.position.y = y;
  return m;
}

export function build() {
  const scene = new THREE.Scene();
  scene.add(skyDome([[0, '#04091a'], [0.35, '#081129'], [0.5, '#16233a'], [0.56, '#0c1424'], [1, '#03060c']]));
  const halo = new THREE.Mesh(new THREE.PlaneGeometry(3000, 3000), new THREE.MeshBasicMaterial({ map: radialTex([[0, 'rgba(70,95,150,0.9)'], [0.25, 'rgba(30,45,85,0.55)'], [0.6, 'rgba(10,18,40,0.2)'], [1, 'rgba(0,0,0,0)']], 512), transparent: true, depthWrite: false, fog: false }));
  halo.rotation.x = Math.PI / 2; halo.position.set(-120, 690, -60); scene.add(halo);
  scene.add(stars(1600, 850, 21));
  const moon = sprite(radialTex([[0, 'rgba(255,255,255,1)'], [0.12, 'rgba(240,244,255,1)'], [0.16, 'rgba(200,215,255,0.35)'], [0.5, 'rgba(120,150,220,0.08)'], [1, 'rgba(0,0,0,0)']]), 0xffffff, 260, 1, true);
  moon.position.set(-120, 700, -60); moon.scale.setScalar(90); scene.add(moon);
  scene.add(new THREE.HemisphereLight(0x3b4d78, 0x0a0c10, 0.9));
  const ml = new THREE.DirectionalLight(0xc8d6ff, 2.4); ml.position.set(-120, 700, -60); scene.add(ml);
  const fill = new THREE.DirectionalLight(0x8094c0, 1.3); fill.position.set(60, -300, 40); scene.add(fill);

  const bomber = makeBomber(); scene.add(bomber);
  const fighter = makeFighter(); scene.add(fighter);
  // the fighter's left wing tears off at the impact
  const looseWing = fighter.userData.wingL.clone(); looseWing.visible = false; scene.add(looseWing);

  const hit = new THREE.Vector3(3.5, 0.9, 8.5); // on the bomber's right wing (bomber coords = world here)
  const UC = 2.02; // impact time inside the shot (on "slammed")
  const P0 = new THREE.Vector3(24, -27, 15);
  const vIn = hit.clone().sub(P0).divideScalar(UC);

  // sparks
  const NS = 320, R = rng(77);
  const sv = []; for (let i = 0; i < NS; i++) { const d = new THREE.Vector3(R() - 0.5, R() - 0.3, R() - 0.5).normalize().multiplyScalar(6 + R() * 22); sv.push(d); }
  const sp = new Float32Array(NS * 3); const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(sp, 3));
  const sparks = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffb35a, size: 0.55, map: glowTex(), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0 }));
  scene.add(sparks);
  const flash = sprite(glowTex(), 0xffd9a0, 1, 0); flash.position.copy(hit); scene.add(flash);
  const flashL = new THREE.PointLight(0xffa860, 0, 60, 1.6); flashL.position.copy(hit); scene.add(flashL);
  // debris
  const debris = []; const dm = new THREE.MeshStandardMaterial({ color: 0x9aa3ab, metalness: 0.8, roughness: 0.4 });
  for (let i = 0; i < 18; i++) { const d = new THREE.Mesh(new THREE.BoxGeometry(0.2 + R() * 0.6, 0.04, 0.15 + R() * 0.4), dm); d.userData = { v: new THREE.Vector3((R() - 0.2) * 14, (R() - 0.5) * 10, (R() - 0.3) * 12), w: new THREE.Vector3(R() * 9, R() * 9, R() * 9) }; d.visible = false; scene.add(d); debris.push(d); }
  // a tiny parachute: the fighter pilot ejects and survives
  const chute = new THREE.Group();
  const can = new THREE.Mesh(new THREE.SphereGeometry(1.2, 16, 8, 0, 6.283, 0, 1.3), new THREE.MeshStandardMaterial({ color: 0xd8dde2, roughness: 0.8, side: THREE.DoubleSide }));
  chute.add(can); const pil = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.6, 0.25), new THREE.MeshStandardMaterial({ color: 0x15181b })); pil.position.y = -2.4; chute.add(pil);
  chute.visible = false; scene.add(chute);

  const camera = new THREE.PerspectiveCamera(42, 1080 / 1920, 0.1, 3000);
  const q = new THREE.Quaternion(), m4 = new THREE.Matrix4(), up = new THREE.Vector3(0, 1, 0);
  const update = (t, u) => {
    // clouds stream backward (+X) as the bomber flies toward -X
    bomber.userData.beacon.visible = (u % 1.1) < 0.12;
    const dt = u - UC;
    // bomber jolt after impact
    const j = dt > 0 ? Math.exp(-2.2 * dt) : 0;
    bomber.rotation.set(j * 0.16 * Math.sin(dt * 13) + (dt > 0 ? 0.06 * smooth(0, 1.2, dt) : 0), 0, -(dt > 0 ? 0.05 * smooth(0, 1.5, dt) : 0));
    bomber.position.set(0, dt > 0 ? -dt * dt * 0.6 : 0, 0);
    // fighter
    if (dt < 0) {
      const p = P0.clone().addScaledVector(vIn, u); fighter.position.copy(p);
      m4.lookAt(new THREE.Vector3(), vIn.clone().negate(), up); // nose (-X local) along velocity
      q.setFromRotationMatrix(m4); fighter.quaternion.copy(q); fighter.rotateY(Math.PI / 2); fighter.rotateX(-0.35);
      fighter.userData.wingL.visible = true; looseWing.visible = false;
    } else {
      const v = vIn.clone().multiplyScalar(0.45).add(new THREE.Vector3(6, -4, 4));
      fighter.position.copy(hit).addScaledVector(v, dt).add(new THREE.Vector3(0, -6 * dt * dt, 0)).add(new THREE.Vector3(1.5, -0.8, 1.2));
      m4.lookAt(new THREE.Vector3(), vIn.clone().negate(), up); q.setFromRotationMatrix(m4);
      fighter.quaternion.copy(q); fighter.rotateY(Math.PI / 2); fighter.rotateX(-0.35 + dt * 7.5); fighter.rotateZ(dt * 2.2);
      fighter.userData.wingL.visible = false; looseWing.visible = true;
      looseWing.position.copy(hit).add(new THREE.Vector3(2.5 * dt, 3 * dt - 7 * dt * dt, 5 * dt));
      looseWing.rotation.set(dt * 9, dt * 4, dt * 6);
    }
    // sparks, flash, debris
    const sa = dt > 0 ? Math.max(0, 1 - dt / 1.3) : 0;
    sparks.material.opacity = sa;
    for (let i = 0; i < NS; i++) { const d = Math.max(0, dt) * (0.6 + (i % 7) * 0.08); sp[i * 3] = hit.x + sv[i].x * d; sp[i * 3 + 1] = hit.y + sv[i].y * d - 5 * d * d; sp[i * 3 + 2] = hit.z + sv[i].z * d; }
    sg.attributes.position.needsUpdate = true;
    const fl = dt > 0 ? Math.exp(-dt * 7) : 0;
    flash.material.opacity = fl; flash.scale.setScalar(6 + 26 * fl); flashL.intensity = 900 * fl;
    debris.forEach((d) => { d.visible = dt > 0; if (dt > 0) { d.position.copy(hit).addScaledVector(d.userData.v, dt).add(new THREE.Vector3(0, -4 * dt * dt, 0)); d.rotation.set(d.userData.w.x * dt, d.userData.w.y * dt, d.userData.w.z * dt); } });
    chute.visible = dt > 0.9;
    if (chute.visible) { const k = Math.min(1, (dt - 0.9) / 0.25); chute.scale.setScalar(k * 1.4); chute.position.set(10 + dt * 1.5, -20 - dt * 1.0, 6.5); chute.rotation.x = Math.PI; }
    // camera: straight below the bomber looking up, nose toward the top of the frame; shake after impact
    const sh = dt > 0 ? Math.exp(-2.5 * dt) * 0.9 : 0;
    camera.up.set(-1, 0, 0);
    const zoom = lerp(-78, -72, smooth(0, 3.5, u));
    camera.position.set(2 + wobble(u, 3.1, 1) * sh, zoom, 1.5 + wobble(u, 2.7, 2) * sh);
    camera.lookAt(2, 0, 1.5); camera.updateMatrixWorld();
  };
  return { scene, camera, update, bloom: 0.55 };
}
