// Shot 4: split view. Above the waterline, search boats sweep the sea with lights.
// Below it, a sonar beam slides across the seabed and misses the buried bomb.
import * as THREE from 'three';
import { makeBoat, skyDome, stars, sprite, glowTex, rng, clamp, lerp, smooth, wobble } from '../lib.js';
import { seaSurface, coastLights } from './drop.js';
import { addSeabed, addWater } from './cut.js';

export function build() {
  // ---- above ----
  const A = new THREE.Scene();
  A.add(skyDome([[0, '#02040b'], [0.4, '#0a1428'], [0.49, '#2a3550'], [0.5, '#3a3f52'], [0.52, '#0c1626'], [1, '#02050a']]));
  A.add(stars(900, 850, 41, 0.08));
  A.fog = new THREE.Fog(0x141d30, 80, 900);
  A.add(new THREE.HemisphereLight(0x3a4a70, 0x05080c, 0.7));
  const ml = new THREE.DirectionalLight(0xc8d6ff, 1.6); ml.position.set(-200, 120, -400); A.add(ml);
  const sea = seaSurface(); A.add(sea);
  A.add(coastLights(50, -650, 900, 2, 7));
  const boats = [];
  const spots = [];
  for (const [x, z, s, r] of [[-3.2, -17, 1, 0.5], [6.5, -33, 1, -0.7], [-13, -66, 1, 0.9]]) {
    const b = makeBoat(true); b.position.set(x, 0, z); b.rotation.y = r; b.scale.setScalar(s); A.add(b); boats.push(b);
    const sl = new THREE.SpotLight(0xfff0c8, 600, 80, 0.22, 0.5, 1.2); sl.position.set(x, 3, z); A.add(sl, sl.target); spots.push(sl);
    // light pool on the water
    const pool = sprite(glowTex(), 0xfff3d0, 10, 0.35); pool.material.depthTest = true; A.add(pool); b.userData.pool = pool;
  }
  const camA = new THREE.PerspectiveCamera(40, 1080 / 1920, 0.1, 3000);

  // ---- below ----
  const B = new THREE.Scene();
  B.fog = null;
  const ground = new THREE.Group(); B.add(ground);
  const W = addWater(B, { seed: 6, density: 0.032, root: ground });
  const S = addSeabed(ground, { seed: 9 });
  ground.position.set(1.2, -10, -6);
  // sonar beam from the first boat's hull, sweeping across the seabed but missing the bomb
  const sonar = new THREE.Group(); B.add(sonar); sonar.position.set(0.5, 0, -9.0);
  const len = 10.6;
  const cone = new THREE.Mesh(new THREE.ConeGeometry(0.6, len, 40, 1, true), new THREE.MeshBasicMaterial({ color: 0x6fe3ee, transparent: true, opacity: 0.05, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false }));
  cone.geometry.translate(0, -len / 2, 0); sonar.add(cone);
  const ringM = new THREE.MeshBasicMaterial({ color: 0x8ff3fb, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false });
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.92, 1.0, 64), ringM); ring.rotation.x = -Math.PI / 2; B.add(ring);
  // hull silhouette at the very top of the underwater view
  
  const camB = new THREE.PerspectiveCamera(40, 1080 / 1920, 0.1, 500);

  const update = (t, u, shot) => {
    sea.userData.update(t);
    boats.forEach((b, i) => {
      b.position.y = Math.sin(t * 1.3 + i) * 0.12; b.rotation.z = Math.sin(t * 0.9 + i * 2) * 0.03;
      const sw = Math.sin(t * 0.6 + i * 1.7) * 0.7;
      b.userData.lamp.rotation.y = sw; b.userData.lamp.rotation.z = -0.05;
      const dir = new THREE.Vector3(-1, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), b.rotation.y + sw);
      const tgt = b.position.clone().addScaledVector(dir, 22); tgt.y = 0;
      spots[i].position.copy(b.position).add(new THREE.Vector3(0, 3, 0)); spots[i].target.position.copy(tgt); spots[i].target.updateMatrixWorld();
      b.userData.pool.position.set(tgt.x, 0.2, tgt.z);
    });
    camA.position.set(0 + wobble(t, 0.1, 1) * 0.2, 2.2 + Math.sin(t * 1.1) * 0.08, 10);
    camA.lookAt(0, -9.3, -90); camA.updateMatrixWorld();

    W.parts.userData.update(t); W.shafts.userData.update(t); S.grass.userData.update(t);
    // sonar sweeps from the right toward the bomb, then stops short
    const k = smooth(0, 3.0, u);
    sonar.rotation.z = lerp(-0.42, -0.1, k) + Math.sin(t * 2.2) * 0.01; sonar.rotation.x = -0.06;
    const dir = new THREE.Vector3(0, -1, 0).applyEuler(sonar.rotation);
    const kk = (ground.position.y - sonar.position.y) / dir.y; const hit = sonar.position.clone().addScaledVector(dir, kk);
    const ph = (t % 1.2) / 1.2; ring.position.set(hit.x, ground.position.y + 0.04, hit.z); ring.scale.setScalar(0.4 + ph * 2.6); ringM.opacity = 0.6 * (1 - ph);
    camB.position.set(1.5, -2.2, 9.5); camB.lookAt(0.6, -8.6, -4); camB.updateMatrixWorld();
  };
  return { split: { a: { scene: A, camera: camA }, b: { scene: B, camera: camB }, splitY: 757 / 1920 }, update, scene: A, camera: camA, bloom: 0.5 };
}
