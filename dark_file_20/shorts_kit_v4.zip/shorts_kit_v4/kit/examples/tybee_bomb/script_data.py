"""Script for Dark File #19: the lost Tybee hydrogen bomb.

Each segment is one voice line. {SHOWN|spoken words} shows SHOWN in captions but speaks the
second part. `gap` is the silence after the line, in seconds.
"""
VOICE = "am_michael"
SPEED = 1.2
LEAD_IN = 0.12   # first word must start by 0.2 s
TAIL = 0.7       # silence after the last line

SEGS = [
    {"text": "In {1958,|nineteen fifty-eight,} America lost a hydrogen bomb. It's still missing.", "gap": 0.40},
    {"text": "Over Georgia, a fighter jet slammed into a bomber at night.", "gap": 0.30},
    {"text": "To land safely, the pilot dropped the bomb into the sea.", "gap": 0.35},
    {"text": "A hundred Navy men searched for weeks. They never found it.", "gap": 0.55},
    {"text": "The Air Force says its nuclear core was taken out first.", "gap": 0.30},
    {"text": "But in {1966,|nineteen sixty-six,} a defense official called it a complete weapon.", "gap": 0.55},
    {"text": "It's still down there, buried in mud off the Georgia coast.", "gap": 0.40},
    {"text": "Tap the button below for {a|uh} new dark file every day.", "gap": 0.0},
]

import re

TOKEN = re.compile(r"\{([^|}]*)\|([^|}]*)(?:\|(\d+))?\}|(\S+)")


def tokens(text):
    """[(shown, spoken, forced_model_word_count or None)] per display token."""
    out = []
    for m in TOKEN.finditer(text):
        if m.group(4) is not None:
            out.append((m.group(4), m.group(4), None))
        else:
            out.append((m.group(1), m.group(2), int(m.group(3)) if m.group(3) else None))
    return out


def spoken(text):
    return " ".join(sp for _, sp, _ in tokens(text))
