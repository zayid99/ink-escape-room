// Shot list, cut in the silence between voice lines.
export function makeShots(tl) {
  const s = tl.segs;
  const mid = (a, b) => (s[a].t1 + s[b].t0) / 2;
  const c = [0, mid(0, 1), mid(1, 2), mid(2, 3), mid(3, 4), mid(5, 6), mid(6, 7), tl.dur];
  const ids = [['hook', 'cut'], ['collide', 'sky'], ['drop', 'drop'], ['search', 'search'], ['turn', 'xray'], ['rise', 'rise'], ['cta', 'cut']];
  return ids.map(([id, set], i) => ({ id, set, n: i + 1, t0: c[i], t1: c[i + 1] }));
}
export const shotAt = (shots, t) => shots.find((s) => t >= s.t0 && t < s.t1) || shots[shots.length - 1];
