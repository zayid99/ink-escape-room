"""Original music + sound effects for Dark File #20 (Goiania), mixed under the narration.
Everything is synthesized here (no samples). Output: audio/mix.wav (48 kHz stereo, about -14 LUFS)."""
import json, numpy as np, soundfile as sf
from scipy import signal
import pyloudnorm as pyln

ROOT = "/home/claude/short"
SR = 48000
tl = json.load(open(f"{ROOT}/web/timeline.json"))
DUR = tl["dur"]
N = int(DUR * SR)
t = np.arange(N) / SR
rng = np.random.default_rng(7)
S = tl["segs"]
mid = lambda a, b: (S[a]["t1"] + S[b]["t0"]) / 2
CUTS = [0, mid(0, 1), mid(2, 3), mid(3, 4), mid(4, 5), mid(5, 6), mid(6, 7), DUR]  # must match web/shots.js
W = lambda seg, txt: next(w["t0"] for w in tl["words"] if w["seg"] == seg and w["w"].strip(".,").lower() == txt)
T_TURN = S[4]["t0"]
T_RADIO = W(4, "radioactive")
T_DROP = S[2]["t0"] + 2.0          # clinic: treatment head tips, lands 0.55 s later (clinic.js)
T_TORN = W(6, "torn")

# ---------- helpers ----------
def env_ad(n, a, d):
    e = np.ones(n); na = max(1, int(a * SR)); e[:na] = np.linspace(0, 1, na)
    e *= np.exp(-np.arange(n) / SR / max(d, 1e-3)); return e
def lp(x, fc, order=2): b, a = signal.butter(order, fc / (SR / 2), 'low'); return signal.lfilter(b, a, x)
def hp(x, fc, order=2): b, a = signal.butter(order, fc / (SR / 2), 'high'); return signal.lfilter(b, a, x)
def bp(x, lo, hi, order=2): b, a = signal.butter(order, [lo / (SR / 2), hi / (SR / 2)], 'band'); return signal.lfilter(b, a, x)
def reverb(x, dur=2.2, wet=0.3, seed=1):
    r = np.random.default_rng(seed); n = int(dur * SR)
    ir = r.standard_normal(n) * np.exp(-np.arange(n) / SR * (6.9 / dur)); ir = lp(ir, 5000); ir /= np.sqrt((ir ** 2).sum())
    y = signal.fftconvolve(x, ir)[:len(x)]; return x * (1 - wet) + y * wet * 3
def place(buf, x, at, gain=1.0):
    i = int(at * SR)
    if i >= len(buf): return
    j = min(len(buf), i + len(x)); buf[i:j] += x[: j - i] * gain
def db(v): return 10 ** (v / 20)

music = np.zeros(N); sfx = np.zeros(N)

# ---------- music: a cold drone in C# minor; thins out on the turn, surges on "radioactive" ----------
def drone_part(f, amp, lfo):
    ph = 2 * np.pi * f * t + 0.4 * np.sin(2 * np.pi * lfo * t)
    return amp * (np.sin(ph) + 0.35 * np.sin(2 * ph + 0.3) + 0.12 * np.sin(3 * ph + 1.1))
bed = drone_part(69.30, 1.0, 0.07) + drone_part(103.83, 0.5, 0.05) + drone_part(138.59, 0.28, 0.09) + drone_part(164.81, 0.16, 0.04)
bed = bed + lp(hp(rng.standard_normal(N), 180), 900) * 0.25 * (0.6 + 0.4 * np.sin(2 * np.pi * 0.11 * t))
lvl = np.ones(N)
def ramp(a, b, va, vb):
    i, j = int(a * SR), int(b * SR); lvl[i:j] = np.linspace(va, vb, j - i)
ramp(T_TURN - 0.25, T_TURN + 0.05, 1.0, 0.15)
lvl[int((T_TURN + 0.05) * SR):int((T_RADIO - 0.6) * SR)] = 0.15
ramp(T_RADIO - 0.6, T_RADIO, 0.15, 0.6); ramp(T_RADIO, T_RADIO + 0.05, 0.6, 1.2)
lvl[int((T_RADIO + 0.05) * SR):] = 1.0
ramp(CUTS[6], CUTS[6] + 0.8, 1.0, 0.9)   # CTA settles back to the opening level so the loop matches
music += bed * lvl * 0.32
# glassy music-box notes for the glow shot (shot 3), and a falling minor motif in shot 2
def bell(f, dur=1.6):
    n = int(dur * SR); tt = np.arange(n) / SR
    x = sum(a * np.sin(2 * np.pi * f * m * tt) * np.exp(-tt * d) for m, a, d in ((1, 1, 2.2), (2.76, 0.4, 4), (5.4, 0.2, 7)))
    return x * env_ad(n, 0.003, 10)
for k, (at, f) in enumerate(zip(np.arange(CUTS[2] + 0.1, CUTS[3] - 0.3, 0.55), [554.37, 659.25, 830.61, 739.99, 659.25, 554.37])):
    place(music, reverb(bell(f), 2.4, 0.5, k + 20), at, 0.09)
for k, at in enumerate(np.arange(CUTS[1] + 0.3, CUTS[2] - 0.6, 1.8)):
    f = 277.18 if k % 2 == 0 else 293.66
    n = int(1.5 * SR); tt = np.arange(n) / SR
    tone = (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2 * f * tt)) * env_ad(n, 0.05, 0.6)
    place(music, reverb(tone, 1.8, 0.45, k + 3), at, 0.09)
# pulse under the payoff (bus + street)
for at in np.arange(CUTS[4] + 0.2, CUTS[6] - 0.3, 0.86):
    n = int(0.25 * SR); tt = np.arange(n) / SR
    place(music, np.sin(2 * np.pi * (46 + 28 * np.exp(-tt * 30)) * tt) * env_ad(n, 0.004, 0.08), at, 0.5)

# ---------- sound effects ----------
def hit_low():
    n = int(3.0 * SR); tt = np.arange(n) / SR
    x = np.sin(2 * np.pi * (38 + 50 * np.exp(-tt * 9)) * tt) * env_ad(n, 0.002, 0.9)
    x += lp(rng.standard_normal(n), 900) * env_ad(n, 0.001, 0.25) * 0.6
    return reverb(x, 3.0, 0.35, 13)
def hum(dur, seed):
    n = int(dur * SR); tt = np.arange(n) / SR
    x = sum(a * np.sin(2 * np.pi * f * tt + p) for f, a, p in ((120, 1, 0), (240, 0.45, 1), (360, 0.25, 2), (480, 0.12, 0.5)))
    x *= 0.8 + 0.2 * np.sin(2 * np.pi * 0.7 * tt + seed)
    e = np.clip(tt / 0.05, 0, 1) * np.clip((dur - tt) / 0.15, 0, 1)
    return x * e + bp(np.random.default_rng(seed).standard_normal(n), 2000, 6000) * 0.04 * e
def wind(dur, seed):
    n = int(dur * SR); tt = np.arange(n) / SR
    x = bp(np.random.default_rng(seed).standard_normal(n), 150, 900) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.23 * tt + seed) ** 2)
    return x * np.clip(tt / 0.3, 0, 1) * np.clip((dur - tt) / 0.3, 0, 1)
def drip():
    n = int(0.3 * SR); tt = np.arange(n) / SR
    return reverb(np.sin(2 * np.pi * (900 + 1400 * np.exp(-tt * 40)) * tt) * env_ad(n, 0.001, 0.03), 1.5, 0.6, 31)
def clank(gain=1.0):
    n = int(0.6 * SR); tt = np.arange(n) / SR
    x = sum(np.sin(2 * np.pi * f * tt) * env_ad(n, 0.001, d) for f, d in ((180, 0.15), (420, 0.08), (960, 0.05)))
    x += bp(rng.standard_normal(n), 300, 3000) * env_ad(n, 0.001, 0.03)
    return reverb(x, 0.9, 0.25, 11) * gain
def creak(dur):
    n = int(dur * SR); tt = np.arange(n) / SR
    f = 180 + 60 * np.sin(2 * np.pi * 1.3 * tt); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sign(np.sin(ph)) * 0.3 * (0.5 + 0.5 * np.sin(2 * np.pi * 23 * tt)) * np.clip(tt / 0.1, 0, 1) * np.clip((dur - tt) / 0.1, 0, 1)
def thud():
    n = int(2.0 * SR); tt = np.arange(n) / SR
    x = np.sin(2 * np.pi * (55 + 70 * np.exp(-tt * 18)) * tt) * env_ad(n, 0.001, 0.35)
    x += bp(rng.standard_normal(n), 200, 5000) * env_ad(n, 0.001, 0.15) * 0.8
    x += sum(np.sin(2 * np.pi * f * tt + p) * env_ad(n, 0.001, d) for f, p, d in ((311, 0.1, 0.6), (523, 1.2, 0.4), (887, 2.0, 0.25))) * 0.3
    return reverb(x, 1.8, 0.35, 9)
def step():
    n = int(0.2 * SR); tt = np.arange(n) / SR
    return lp(rng.standard_normal(n), 500) * env_ad(n, 0.002, 0.04) + np.sin(2 * np.pi * 70 * tt) * env_ad(n, 0.002, 0.05) * 0.5
def click():
    n = int(0.012 * SR); tt = np.arange(n) / SR
    return hp(rng.standard_normal(n), 2500) * np.exp(-tt * 900)
def engine(dur, seed):
    n = int(dur * SR); tt = np.arange(n) / SR
    x = lp(np.random.default_rng(seed).standard_normal(n), 220) * 2.0 + 0.5 * np.sin(2 * np.pi * 38 * tt) * (0.7 + 0.3 * np.sin(2 * np.pi * 9 * tt))
    return x * np.clip(tt / 0.1, 0, 1) * np.clip((dur - tt) / 0.1, 0, 1)
def whoosh(dur):
    n = int(dur * SR); tt = np.arange(n) / SR
    return bp(rng.standard_normal(n), 300, 2500) * np.sin(np.pi * tt / dur) ** 2
def hiss(dur):
    n = int(dur * SR); tt = np.arange(n) / SR
    return hp(rng.standard_normal(n), 3000) * np.exp(-tt * 3) * np.clip(tt / 0.02, 0, 1)
def crumble():
    n = int(3.0 * SR); tt = np.arange(n) / SR
    x = lp(rng.standard_normal(n), 1800) * env_ad(n, 0.05, 0.9) * 1.2
    x += np.sin(2 * np.pi * (40 + 30 * np.exp(-tt * 6)) * tt) * env_ad(n, 0.01, 0.8)
    for k in range(30):
        a = int(rng.uniform(0.0, 2.0) * SR); m = int(0.08 * SR)
        if a + m < n: x[a:a + m] += bp(rng.standard_normal(m), 400, 4000) * np.exp(-np.arange(m) / SR * 50) * rng.uniform(0.3, 1.0)
    return reverb(x, 2.0, 0.3, 17)
def toll(f=110):
    n = int(4.0 * SR); tt = np.arange(n) / SR
    x = sum(a * np.sin(2 * np.pi * f * m * tt) * np.exp(-tt * d) for m, a, d in ((1, 1, 0.8), (2.0, 0.6, 1.2), (2.4, 0.4, 1.6), (3.0, 0.25, 2), (4.2, 0.15, 3)))
    return reverb(x * env_ad(n, 0.004, 10), 3.0, 0.4, 41)

# frame 1: low hit; electrical hum under every bench shot (hook, glow, cta)
place(sfx, hit_low(), 0.0, 0.8)
for a, b in ((0, CUTS[1]), (CUTS[2], CUTS[3]), (CUTS[6], DUR)):
    place(sfx, hum(b - a, int(a * 10)), a, 0.10)
# shot 2: clinic wind, drips, men at work, the head tips and lands
place(sfx, wind(CUTS[2] - CUTS[1], 5), CUTS[1], 0.22)
for at in (CUTS[1] + 0.6, CUTS[1] + 2.3, CUTS[1] + 3.9, CUTS[1] + 6.2): place(sfx, drip(), at, 0.25)
for at in np.arange(S[2]["t0"] - 0.5, S[2]["t0"] + 1.0, 0.42): place(sfx, step(), at, 0.35)
place(sfx, clank(0.8), S[2]["t0"] + 0.9, 0.5); place(sfx, clank(1.0), S[2]["t0"] + 1.3, 0.55)
place(sfx, creak(0.9), T_DROP - 0.9, 0.12)
place(sfx, thud(), T_DROP + 0.55, 0.9)
# shot 3: soft footsteps of the family coming closer, hum rises
for at in (CUTS[2] + 0.4, CUTS[2] + 0.9, CUTS[2] + 1.5, CUTS[2] + 2.0): place(sfx, step(), at, 0.25)
# shot 4 (turn): geiger clicks that speed up into a rattle; sub-bass hit on "radioactive"
rate = lambda x: 4 + 60 * (1 / (1 + np.exp(-(x - T_RADIO) * 6)))
x = CUTS[3] + 0.05
while x < CUTS[4] - 0.05:
    place(sfx, click(), x, 0.45)
    x += rng.exponential(1 / rate(x))
place(sfx, hit_low(), T_RADIO, 0.9)
# shot 5: bus engine, a passing whoosh with each streetlight, brake hiss at the end
place(sfx, engine(CUTS[5] - CUTS[4], 12), CUTS[4], 0.35)
for at in np.arange(CUTS[4], CUTS[5] - 0.8, 2.1): place(sfx, whoosh(0.9), at + 0.6, 0.18)
place(sfx, hiss(0.7), CUTS[5] - 0.75, 0.25)
# shot 6: a toll on "Four people died", the house crumbles on "torn", wind
place(sfx, toll(), S[6]["t0"], 0.35)
place(sfx, crumble(), T_TORN, 0.9)
place(sfx, wind(CUTS[6] - CUTS[5], 9), CUTS[5], 0.2)

# ---------- mix ----------
vo, vsr = sf.read(f"{ROOT}/audio/vo.wav")
vo = signal.resample_poly(vo, SR, vsr)[:N]
vo = np.pad(vo, (0, max(0, N - len(vo))))
# set music/effects levels relative to the voice (measured where the voice is active)
act = np.abs(vo) > 0.01
vrms = np.sqrt((vo[act] ** 2).mean())
music *= vrms * db(-17) / np.sqrt((music ** 2).mean())
sfx *= vrms * db(-9) / np.sqrt((sfx ** 2).mean())
# duck music + effects under the voice
env = np.abs(vo); env = lp(env, 6) ; env = env / (env.max() + 1e-9)
duck = 1 - 0.45 * np.clip(env * 4, 0, 1)
mus = music * duck
fx = sfx * (1 - 0.25 * np.clip(env * 4, 0, 1))
# simple stereo: music wide, voice centered
L = vo * 1.0 + mus * 0.9 + fx * 0.95 + np.roll(mus, 240) * 0.1
R = vo * 1.0 + mus * 0.9 + fx * 0.95 + np.roll(mus, -240) * 0.1
mix = np.stack([L, R], 1)
meter = pyln.Meter(SR)
loud = meter.integrated_loudness(mix)
mix = pyln.normalize.loudness(mix, loud, -14.0)
pk = np.abs(mix).max()
if pk > db(-1.0):
    # soft limit the few peaks above -1 dBFS
    th = db(-1.0); mix = np.where(np.abs(mix) > th * 0.8, np.sign(mix) * (th * 0.8 + (th * 0.2) * np.tanh((np.abs(mix) - th * 0.8) / (th * 0.2))), mix)
sf.write(f"{ROOT}/audio/mix.wav", mix.astype(np.float32), SR)
print("loudness", round(meter.integrated_loudness(mix), 2), "LUFS, peak", round(float(np.abs(mix).max()), 3), "dur", round(len(mix) / SR, 2))
print("music:voice (dB)", round(20 * np.log10(np.sqrt((mus ** 2).mean()) / vrms), 1), " sfx:voice", round(20 * np.log10(np.sqrt((fx ** 2).mean()) / vrms), 1), " sfx peak:voice peak", round(20 * np.log10(np.abs(fx).max() / np.abs(vo).max()), 1))
