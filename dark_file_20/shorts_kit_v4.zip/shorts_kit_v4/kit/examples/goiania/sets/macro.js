// Shot 4 (the turn): macro inside the opened capsule. Glowing salt-like grains, faint particle
// streaks flying out of the powder. On "radioactive" the glow surges and the camera jolts.
import * as THREE from 'three';
import { driftParticles, clamp, lerp, ease, smooth, rng, wobble, glowTex, sprite } from '../lib.js';
import { steelTex } from '../props.js';

export function build() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x010306);
  scene.fog = new THREE.FogExp2(0x020a14, 0.09);
  scene.add(new THREE.HemisphereLight(0x1d3a5a, 0x000000, 0.3));
  // capsule interior (macro scale: radius 2.4 units)
  const steel = new THREE.MeshStandardMaterial({ map: steelTex(9), metalness: 0.85, roughness: 0.32, side: THREE.BackSide });
  const tube = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.4, 9, 64, 1, true), steel); tube.rotation.x = Math.PI / 2; tube.position.z = -2; scene.add(tube);
  const backCap = new THREE.Mesh(new THREE.CircleGeometry(2.4, 48), new THREE.MeshStandardMaterial({ map: steelTex(10), metalness: 0.85, roughness: 0.35 })); backCap.position.z = -6.5; scene.add(backCap);
  // powder heap: many small crystals over a mound
  const R = rng(77), N = 9000;
  const gmat = new THREE.MeshStandardMaterial({ color: 0x9cc6e0, emissive: 0x2a8de0, emissiveIntensity: 0.16, roughness: 0.35, metalness: 0.0 });
  const grains = new THREE.InstancedMesh(new THREE.BoxGeometry(0.035, 0.035, 0.035), gmat, N);
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), v = new THREE.Vector3(), sc = new THREE.Vector3();
  const mound = (x, z) => -1.8 + 0.32 * Math.exp(-((x * x) / 1.2 + ((z + 3.5) * (z + 3.5)) / 6)) + 0.04 * Math.sin(x * 5 + z * 3);
  for (let i = 0; i < N; i++) {
    const x = (R() - 0.5) * 3.3, z = -6.3 + R() * 8.5;
    v.set(x, mound(x, z) + R() * 0.05, z); const k = 0.5 + R() * 1.6; sc.set(k, k * (0.6 + R() * 0.6), k);
    e.set(R() * 6, R() * 6, R() * 6); q.setFromEuler(e); m.compose(v, q, sc); grains.setMatrixAt(i, m);
    const b = 0.2 + Math.pow(R(), 2) * 1.1; grains.setColorAt(i, new THREE.Color(b * 0.85, b * 0.95, b));
  }
  scene.add(grains);
  const base = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 9, 40, 80), new THREE.MeshStandardMaterial({ color: 0x0a1622, emissive: 0x1a5f9e, emissiveIntensity: 0.12, roughness: 1 }));
  base.rotation.x = -Math.PI / 2; base.position.z = -2.0;
  const bp = base.geometry.attributes.position;
  for (let i = 0; i < bp.count; i++) { const x = bp.getX(i), z = -bp.getY(i) - 2.0; bp.setZ(i, mound(x, z) - 0.03); }
  base.geometry.computeVertexNormals(); scene.add(base);
  const core = new THREE.PointLight(0x58bfff, 5, 14, 1.5); core.position.set(0.3, -0.9, -2.2);
  const core2 = new THREE.PointLight(0x2f7fd0, 4, 12, 1.5); core2.position.set(-0.6, -1.2, -5.5); scene.add(core2); scene.add(core);
  const halo = sprite(glowTex(), 0x5cc4ff, 6, 0.25); halo.position.set(0, -1.0, -3.5); scene.add(halo);
  // streaks: short lines flying outward from the powder, positions a pure function of t
  const NS = 320; const sp = new Float32Array(NS * 6); const seeds = [];
  for (let i = 0; i < NS; i++) seeds.push({ o: new THREE.Vector3((R() - 0.5) * 3, -1.4 + R() * 0.6, -6 + R() * 6), d: new THREE.Vector3((R() - 0.5) * 1.4, 0.4 + R() * 1.2, 0.6 + R() * 1.6).normalize(), ph: R(), sp: 3 + R() * 5 });
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(sp, 3));
  const smat = new THREE.LineBasicMaterial({ color: 0x9fe0ff, transparent: true, opacity: 0.0, blending: THREE.AdditiveBlending, depthWrite: false });
  const streaks = new THREE.LineSegments(sg, smat); scene.add(streaks);
  const motes = driftParticles(600, new THREE.Box3(new THREE.Vector3(-2.2, -1.6, -6), new THREE.Vector3(2.2, 2, 3)), 12, 0x9fd8ff, 0.035, 0.5); scene.add(motes);

  const camera = new THREE.PerspectiveCamera(42, 1080 / 1920, 0.02, 100);
  let TR = null; // "radioactive" word time
  const out = { scene, camera, bloom: 0.5, exposure: 0.95 };
  out.update = (t, u, shot) => {
    if (TR === null) TR = (window.__tl && window.__tl.words.find((w) => w.w.toLowerCase().startsWith('radioactive'))?.t0) || shot.t0 + 3.0;
    motes.userData.update(t);
    const dr = t - TR, surge = dr > 0 ? smooth(0, 0.25, dr) : 0;
    const k = 1 + 0.08 * Math.sin(t * 2.3) + 0.45 * surge * (0.8 + 0.2 * Math.sin(dr * 11));
    gmat.emissiveIntensity = 0.16 * k; core.intensity = 5 * k; core2.intensity = 4 * k; halo.material.opacity = 0.12 * k; base.material.emissiveIntensity = 0.35 * k;
    // streaks get denser and faster after the reveal
    const dens = lerp(0.35, 1, surge);
    for (let i = 0; i < NS; i++) {
      const s = seeds[i]; const life = ((t * 0.55 * (1 + surge) + s.ph) % 1);
      const on = (i / NS) < dens;
      const a = s.o.clone().addScaledVector(s.d, life * s.sp), b = a.clone().addScaledVector(s.d, on ? 0.18 + 0.4 * surge : 0);
      sp.set([a.x, a.y, a.z, b.x, b.y, b.z], i * 6);
    }
    sg.attributes.position.needsUpdate = true; smat.opacity = 0.35 + 0.45 * surge;
    // camera: from the torn opening, push in over the powder; jolt on "radioactive"
    const D = shot.t1 - shot.t0, p = ease(clamp(u / D));
    const jolt = dr > 0 ? Math.exp(-dr * 5) * 0.08 : 0;
    camera.position.set(0.25 + wobble(t, 5, 1) * jolt + 0.1 * Math.sin(u * 0.4), lerp(-0.9, -1.3, p) + wobble(t, 4.5, 2) * jolt, lerp(3.6, 1.2, p));
    camera.lookAt(0, lerp(-1.75, -1.6, p), -5.5); camera.updateMatrixWorld();
  };
  scene.updateMatrixWorld();
  return out;
}
