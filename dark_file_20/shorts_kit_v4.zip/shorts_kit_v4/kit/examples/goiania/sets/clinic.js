// Shot 2: the abandoned clinic. Moonlight through a broken ceiling onto an old teletherapy unit.
// On the second line two silhouettes come in with torches, their shadows cross the tiles, and the
// heavy treatment head is unbolted and drops onto a cart.
import * as THREE from 'three';
import { driftParticles, lightShafts, gradientTex, clamp, lerp, ease, easeOut, smooth, rng, wobble, glowTex, sprite } from '../lib.js';
import { makeFigure, tileTex, concreteTex, rustTex, plasterTex, scrapChunk } from '../props.js';

function makeTherapyUnit() {
  const g = new THREE.Group();
  const paint = new THREE.MeshStandardMaterial({ color: 0xb9b6a6, roughness: 0.55, metalness: 0.25, map: plasterTex(61, [1, 1], '#c9c3ad') });
  const dark = new THREE.MeshStandardMaterial({ color: 0x3a3c3d, roughness: 0.5, metalness: 0.6 });
  const base = new THREE.Mesh(new THREE.BoxGeometry(6, 1.2, 6), paint); base.position.y = 0.6; g.add(base);
  const col = new THREE.Mesh(new THREE.BoxGeometry(3.2, 17, 3.2), paint); col.position.set(-5.5, 8.5, 0); g.add(col);
  const colBase = new THREE.Mesh(new THREE.BoxGeometry(5, 1.2, 5), paint); colBase.position.set(-5.5, 0.6, 0); g.add(colBase);
  const arm = new THREE.Mesh(new THREE.BoxGeometry(7, 2.4, 2.6), paint); arm.position.set(-2.4, 15, 0); g.add(arm);
  // treatment head: heavy round shielded housing on a yoke
  const head = new THREE.Group(); head.position.set(0.8, 14.2, 0); g.add(head);
  const yoke = new THREE.Mesh(new THREE.TorusGeometry(3.1, 0.35, 10, 40, Math.PI), dark); yoke.rotation.z = Math.PI; head.add(yoke);
  const housing = new THREE.Mesh(new THREE.SphereGeometry(2.7, 36, 24), paint); housing.scale.set(1, 0.92, 1); head.add(housing);
  const band = new THREE.Mesh(new THREE.CylinderGeometry(2.78, 2.78, 0.7, 40), dark); head.add(band);
  const colli = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.5, 2.2, 4), dark); colli.rotation.y = Math.PI / 4; colli.position.y = -3.2; head.add(colli);
  const lens = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.08, 1.2), new THREE.MeshStandardMaterial({ color: 0x1c2a2c, roughness: 0.2, metalness: 0.4 })); lens.position.y = -4.32; head.add(lens);
  // couch
  const couch = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.6, 10), new THREE.MeshStandardMaterial({ color: 0x4a463e, roughness: 0.85 })); couch.position.set(1.0, 6.0, 4.5); g.add(couch);
  const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.2, 6, 12), paint); ped.position.set(1.0, 3.0, 5.5); g.add(ped);
  g.userData = { head };
  return g;
}

export function build() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x030507);
  scene.fog = new THREE.FogExp2(0x070b10, 0.018);
  scene.add(new THREE.HemisphereLight(0x3a4c66, 0x14110c, 0.6));
  const W = 40, D = 40, H = 26;
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(W, D), new THREE.MeshStandardMaterial({ map: concreteTex(14, [3, 3], '#4b4842'), roughness: 0.95 }));
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const tiles = new THREE.MeshStandardMaterial({ map: tileTex(3, [3, 2]), roughness: 0.6 });
  const back = new THREE.Mesh(new THREE.PlaneGeometry(W, H), tiles); back.position.set(0, H / 2, -12); back.receiveShadow = true; scene.add(back);
  const left = new THREE.Mesh(new THREE.PlaneGeometry(D, H), tiles); left.rotation.y = Math.PI / 2; left.position.set(-16, H / 2, 0); left.receiveShadow = true; scene.add(left);
  const right = new THREE.Mesh(new THREE.PlaneGeometry(D, H), tiles); right.rotation.y = -Math.PI / 2; right.position.set(16, H / 2, 0); right.receiveShadow = true; scene.add(right);
  // ceiling with a ragged hole (the building was partly demolished)
  const cs = new THREE.Shape(); cs.moveTo(-20, -20); cs.lineTo(20, -20); cs.lineTo(20, 20); cs.lineTo(-20, 20); cs.lineTo(-20, -20);
  const hole = new THREE.Path(); const R = rng(5);
  for (let i = 0; i <= 14; i++) { const a = i / 14 * Math.PI * 2; const r = 4.5 + R() * 2.5; const x = 2 + Math.cos(a) * r * 1.3, y = -2 + Math.sin(a) * r; i ? hole.lineTo(x, y) : hole.moveTo(x, y); }
  cs.holes.push(hole);
  const ceil = new THREE.Mesh(new THREE.ShapeGeometry(cs), new THREE.MeshStandardMaterial({ map: concreteTex(9, [2, 2], '#3a3732'), roughness: 1, side: THREE.DoubleSide }));
  ceil.rotation.x = Math.PI / 2; ceil.position.y = H; scene.add(ceil);
  const sky = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), new THREE.MeshBasicMaterial({ map: gradientTex([[0, '#24364f'], [1, '#0d1522']]), fog: false }));
  sky.rotation.x = Math.PI / 2; sky.position.y = H + 8; scene.add(sky);
  // moonlight through the hole
  const moon = new THREE.SpotLight(0x9fb8dc, 900, 90, 0.3, 0.5, 1.2); moon.position.set(6, 52, 0); moon.target.position.set(1, 8, -3);
  moon.castShadow = true; moon.shadow.mapSize.set(1024, 1024); moon.shadow.bias = -0.0008; scene.add(moon, moon.target);
  const shafts = lightShafts(5, 7, { x0: -3, dx: 9, y: 13, z0: -4, dz: 8, w: 4, h: 30 }); shafts.children.forEach((m) => { m.material.color.set(0xa9c2e6); }); scene.add(shafts);

  const unit = makeTherapyUnit(); unit.position.set(0, 0, -3); scene.add(unit);
  unit.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  const head = unit.userData.head; const head0 = head.position.clone();
  // cart the head drops onto
  const cartMat = new THREE.MeshStandardMaterial({ map: rustTex(70, [0.5, 0.5]), roughness: 0.7, metalness: 0.6 });
  const cart = new THREE.Group(); cart.position.set(7.5, 0, 1.5); scene.add(cart);
  const tray = new THREE.Mesh(new THREE.BoxGeometry(6, 2.0, 7), cartMat); tray.position.y = 3.2; cart.add(tray);
  const wheel = new THREE.Mesh(new THREE.TorusGeometry(1.1, 0.35, 8, 20), new THREE.MeshStandardMaterial({ color: 0x151515, roughness: 0.9 })); wheel.position.set(0, 1.2, 4.2); wheel.rotation.y = Math.PI / 2; cart.add(wheel);
  for (const s of [-1, 1]) { const h = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 9, 8), cartMat); h.rotation.x = Math.PI / 2 - 0.25; h.position.set(s * 2.4, 3.6, -5); cart.add(h); }
  cart.traverse((o) => { if (o.isMesh) o.castShadow = true; });
  // rubble
  const rub = new THREE.MeshStandardMaterial({ map: concreteTex(22, [0.4, 0.4], '#55514a'), roughness: 1 });
  for (let i = 0; i < 40; i++) { const c = scrapChunk(200 + i, 0.3 + R() * 1.2, rub); c.position.set(-14 + R() * 28, 0.2, -10 + R() * 22); c.rotation.y = R() * 6; c.castShadow = true; scene.add(c); }
  const dust = driftParticles(900, new THREE.Box3(new THREE.Vector3(-8, 0, -8), new THREE.Vector3(10, 24, 10)), 31, 0xc8d6ea, 0.08, 0.35); scene.add(dust);
  // dust burst when the head lands
  const burst = new THREE.Group(); scene.add(burst);
  const bR = rng(9); const puffs = [];
  for (let i = 0; i < 26; i++) { const sp = sprite(glowTex(), 0x8a8478, 3, 0, false); sp.material.blending = THREE.NormalBlending; puffs.push({ sp, dir: new THREE.Vector3(bR() - 0.5, bR() * 0.6, bR() - 0.5).normalize(), sp0: 1 + bR() * 3 }); burst.add(sp); }

  // two silhouettes with torches (enter on the second line)
  const men = [makeFigure({ lean: 0.25, armReach: 0.7 }), makeFigure({ lean: 0.1, armReach: 0.45, h: 17.6 })];
  men.forEach((m) => scene.add(m));
  const torches = men.map((m, i) => {
    const l = new THREE.SpotLight(0xffd7a0, 0, 60, 0.36, 0.5, 1.3); l.castShadow = true; l.shadow.mapSize.set(1024, 1024); l.shadow.bias = -0.001;
    scene.add(l, l.target); const fl = sprite(glowTex(), 0xffe2b8, 1.6, 0); scene.add(fl); return { l, fl };
  });
  men.forEach((m) => m.traverse((o) => { if (o.isMesh) o.castShadow = true; }));

  const camera = new THREE.PerspectiveCamera(40, 1080 / 1920, 0.1, 300);
  let T2 = null; // start of the second line, relative to the shot
  const out = { scene, camera, bloom: 0.45, exposure: 1.25 };
  out.update = (t, u, shot) => {
    if (T2 === null) T2 = ((window.__tl && window.__tl.segs[2].t0) || shot.t0 + 4.6) - shot.t0;
    dust.userData.update(t); shafts.userData.update(t);
    const D = shot.t1 - shot.t0;
    // men walk in from the left/back
    const w = smooth(T2 - 0.6, T2 + 1.4, u);
    const p0 = new THREE.Vector3(lerp(-13, -3.0, w), 0, lerp(12, 6.5, w));
    const p1 = new THREE.Vector3(lerp(-14, -6.5, w), 0, lerp(15, 9.5, w));
    [p0, p1].forEach((p, i) => { men[i].position.copy(p); men[i].rotation.y = 2.4 + i * 0.25; men[i].visible = u > T2 - 0.7; });
    const bob = Math.sin(u * 7) * 0.15 * (1 - w); men[0].position.y = bob; men[1].position.y = -bob;
    torches.forEach(({ l, fl }, i) => {
      const m = men[i]; const on = smooth(T2 - 0.6, T2 - 0.2, u);
      const hand = new THREE.Vector3(0.6, 11.5, 1.6).applyAxisAngle(new THREE.Vector3(0, 1, 0), m.rotation.y).add(m.position);
      l.position.copy(hand); fl.position.copy(hand);
      const aim = i === 0 ? new THREE.Vector3(0.8 + wobble(t, 0.3, 1) * 1.2, 13.5 + wobble(t, 0.4, 2) * 0.8, -3) : new THREE.Vector3(2 + wobble(t, 0.25, 4) * 2, 9, -6);
      l.target.position.copy(aim); l.target.updateMatrixWorld();
      l.intensity = 170 * on; fl.material.opacity = 0.8 * on; l.visible = on > 0.001;
    });
    // the head comes off: tilt, then drop onto the cart
    const TD = T2 + 2.0;
    const tilt = smooth(TD - 0.9, TD, u);
    const fall = clamp((u - TD) / 0.55);
    const land = new THREE.Vector3(7.5, 7.0, 1.5).sub(unit.position);
    const fallE = fall * fall;
    head.position.set(lerp(head0.x, land.x, ease(fall)), lerp(head0.y, land.y, fallE) + (fall >= 1 ? Math.max(0, Math.sin((u - TD - 0.55) * 14) * 0.25 * Math.exp(-(u - TD - 0.55) * 6)) : 0), lerp(head0.z, land.z, ease(fall)));
    head.rotation.set(0, 0, lerp(0, 0.35, tilt) + lerp(0, 0.9, ease(fall)));
    const bt = u - (TD + 0.55);
    puffs.forEach(({ sp, dir, sp0 }) => {
      const k = bt > 0 ? bt : 0; sp.position.copy(new THREE.Vector3(7.5, 5, 1.5)).addScaledVector(dir, sp0 * (1 - Math.exp(-k * 2.2)) * 2.2);
      sp.material.opacity = bt > 0 ? 0.35 * Math.exp(-k * 0.9) * smooth(0, 0.08, k) : 0; sp.scale.setScalar(2 + k * 4);
    });
    // camera: slow push toward the machine, then drifts right to follow the men and the drop
    const p = ease(clamp(u / D));
    const shk = bt > 0 ? Math.exp(-bt * 5) * 0.25 : 0;
    camera.position.set(lerp(4, 7, p) + wobble(t, 4, 1) * shk, lerp(12, 10, p) + wobble(t, 3.6, 2) * shk, lerp(40, 33, p));
    camera.lookAt(lerp(-0.5, 0.8, p), lerp(9.5, 8.2, p), -2); camera.updateMatrixWorld();
  };
  scene.updateMatrixWorld();
  return out;
}
