// Shot 5: a 1980s city bus at night. A plastic bag with the pieces sits on the seat, faintly blue;
// a seated silhouette beside it. Streetlights sweep through the windows.
import * as THREE from 'three';
import { driftParticles, canvasTex, gradientTex, clamp, lerp, ease, smooth, rng, wobble, glowTex, sprite } from '../lib.js';
import { makeFigure, rustTex, concreteTex } from '../props.js';

function vinylTex() {
  return canvasTex(512, 512, (g, W, H) => {
    g.fillStyle = '#34423d'; g.fillRect(0, 0, W, H);
    const R = rng(3);
    for (let i = 0; i < 6000; i++) { g.fillStyle = `rgba(${R() < 0.5 ? '0,0,0' : '255,220,190'},${0.04 + R() * 0.06})`; g.fillRect(R() * W, R() * H, 2, 2); }
    g.strokeStyle = 'rgba(20,10,5,0.5)'; g.lineWidth = 4; for (let x = 0; x < W; x += 64) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, H); g.stroke(); }
    for (let i = 0; i < 12; i++) { const x = R() * W, y = R() * H; const gr = g.createRadialGradient(x, y, 0, x, y, 40 + R() * 60); gr.addColorStop(0, 'rgba(10,6,4,0.4)'); gr.addColorStop(1, 'rgba(10,6,4,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H); }
  });
}

export function build() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x020305);
  scene.fog = new THREE.FogExp2(0x05070a, 0.02);
  scene.add(new THREE.HemisphereLight(0x2e3a4c, 0x120d08, 0.4));
  // interior: floor, ceiling, side walls with a row of windows (bus runs along X)
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(80, 26), new THREE.MeshStandardMaterial({ map: concreteTex(31, [6, 2], '#2c2a27'), roughness: 0.9 }));
  floor.rotation.x = -Math.PI / 2; scene.add(floor);
  const panel = new THREE.MeshStandardMaterial({ color: 0x8f8a7c, roughness: 0.6, metalness: 0.2, map: rustTex(44, [3, 1], '#8f8a7c') });
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(80, 26), panel); ceil.rotation.x = Math.PI / 2; ceil.position.y = 21; scene.add(ceil);
  const mkWall = (z, flip) => {
    const g = new THREE.Group();
    const lower = new THREE.Mesh(new THREE.BoxGeometry(80, 9, 0.3), panel); lower.position.y = 4.5; g.add(lower);
    const upper = new THREE.Mesh(new THREE.BoxGeometry(80, 3.5, 0.3), panel); upper.position.y = 19.2; g.add(upper);
    for (let x = -40; x <= 40; x += 8) { const post = new THREE.Mesh(new THREE.BoxGeometry(0.9, 8.5, 0.5), panel); post.position.set(x, 13.2, 0); g.add(post); }
    g.position.z = z; if (flip) g.rotation.y = Math.PI; scene.add(g); return g;
  };
  mkWall(-11, false); mkWall(11, true);
  // what's outside: a dark street plane with passing lights (lights are sprites moving along X)
  const outside = new THREE.Mesh(new THREE.PlaneGeometry(400, 60), new THREE.MeshBasicMaterial({ map: gradientTex([[0, '#0e1520'], [0.6, '#06090e'], [1, '#020304']]), fog: false }));
  outside.position.set(0, 14, -40); scene.add(outside);
  const passers = []; const R = rng(8);
  for (let i = 0; i < 14; i++) { const s = sprite(glowTex(), R() < 0.7 ? 0xffb35c : 0xd9e6ff, 5 + R() * 4, 0.8); s.userData = { x0: R() * 240, y: 14 + R() * 6, z: -24 - R() * 14 }; scene.add(s); passers.push(s); }
  // moving light that sweeps through the cabin from each streetlight
  const sweep = new THREE.SpotLight(0xffb36a, 0, 90, 0.5, 0.7, 1.2); scene.add(sweep, sweep.target);
  const cabin = new THREE.PointLight(0xbcd2ff, 9, 50, 1.3); cabin.position.set(2, 19, 0); scene.add(cabin);
  // seats facing +X
  const vinyl = new THREE.MeshStandardMaterial({ map: vinylTex(), roughness: 0.55 });
  const frame = new THREE.MeshStandardMaterial({ color: 0x777b7e, metalness: 0.85, roughness: 0.35 });
  for (let row = -4; row <= 3; row++) for (const z of [-7, -3.3]) {
    const g = new THREE.Group(); g.position.set(row * 8, 0, z);
    const seat = new THREE.Mesh(new THREE.BoxGeometry(4.5, 1.1, 3.6), vinyl); seat.position.y = 4.4; g.add(seat);
    const back = new THREE.Mesh(new THREE.BoxGeometry(1.0, 6.5, 3.6), vinyl); back.position.set(-2.4, 7.6, 0); back.rotation.z = 0.12; g.add(back);
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 4, 8), frame); leg.position.y = 2; g.add(leg);
    const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 3.6, 8), frame); bar.rotation.x = Math.PI / 2; bar.position.set(-2.4, 11, 0); g.add(bar);
    scene.add(g);
  }
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 21, 10), frame); pole.position.set(-8.6, 10.5, -1.2); scene.add(pole);
  // the bag (crumpled plastic) on the aisle seat of row 0, with a faint blue glow inside
  const bagGeo = new THREE.SphereGeometry(1.4, 32, 24); const bpos = bagGeo.attributes.position; const bR = rng(15);
  for (let i = 0; i < bpos.count; i++) { const y = bpos.getY(i); const k = 1 + (bR() - 0.5) * 0.18; bpos.setXYZ(i, bpos.getX(i) * k * (y > 0.6 ? 0.55 : 1), y * (y < 0 ? 0.7 : 1.15) * k, bpos.getZ(i) * k * (y > 0.6 ? 0.55 : 1)); }
  bagGeo.computeVertexNormals();
  const bag = new THREE.Mesh(bagGeo, new THREE.MeshPhysicalMaterial({ color: 0xaab4ba, roughness: 0.3, transmission: 0.0, transparent: true, opacity: 0.78, emissive: 0x1d6fb8, emissiveIntensity: 0.18, side: THREE.DoubleSide }));
  bag.position.set(0.4, 6.0, -3.3); scene.add(bag);
  const knot = new THREE.Mesh(new THREE.ConeGeometry(0.35, 0.9, 8), bag.material); knot.position.set(0.4, 7.9, -3.3); scene.add(knot);
  const bagGlow = sprite(glowTex(), 0x4fb4ff, 3.4, 0.3); bagGlow.position.copy(bag.position); scene.add(bagGlow);
  const bagLight = new THREE.PointLight(0x4fb0ff, 1.5, 9, 1.6); bagLight.position.set(0.4, 5.6, -3.3); scene.add(bagLight);
  // seated silhouette beside the bag (window seat)
  const woman = makeFigure({ sit: true, lean: 0.05, armReach: 0.35, h: 16 }); woman.position.set(-0.8, 0.4, -7.0); woman.rotation.y = Math.PI / 2; scene.add(woman);
  const dust = driftParticles(300, new THREE.Box3(new THREE.Vector3(-10, 2, -10), new THREE.Vector3(10, 20, 6)), 51, 0xd8dde6, 0.06, 0.3); scene.add(dust);

  const camera = new THREE.PerspectiveCamera(42, 1080 / 1920, 0.1, 500);
  const out = { scene, camera, bloom: 0.5, exposure: 1.15 };
  out.update = (t, u, shot) => {
    dust.userData.update(t);
    const speed = 26; // units/s the street slides past
    let best = 0;
    passers.forEach((s) => { const x = 120 - ((s.userData.x0 + u * speed) % 240); s.position.set(x, s.userData.y, s.userData.z); });
    // sweep light follows a virtual streetlight passing every 2.1 s
    const ph = (u / 2.1) % 1; const sx = lerp(40, -40, ph);
    sweep.position.set(sx, 26, -30); sweep.target.position.set(sx * 0.4, 4, 2); sweep.target.updateMatrixWorld();
    sweep.intensity = 1600 * Math.pow(Math.sin(Math.PI * ph), 2);
    const f = 1 + 0.06 * Math.sin(t * 2.1);
    bagGlow.material.opacity = 0.3 * f; bagLight.intensity = 1.5 * f;
    // the bus sways gently; camera dollies along the aisle toward the bag
    const sway = Math.sin(u * 1.7) * 0.06 + wobble(t, 1.2, 4) * 0.03;
    const D = shot.t1 - shot.t0, p = ease(clamp(u / D));
    camera.position.set(lerp(9.5, 7.0, p), lerp(9.6, 9.0, p) + sway * 0.6, lerp(10.0, 7.6, p) + sway);
    camera.lookAt(lerp(0.4, 0.2, p), lerp(8.0, 7.4, p), -5.0); camera.rotation.z += sway * 0.08; camera.updateMatrixWorld();
  };
  scene.updateMatrixWorld();
  return out;
}
