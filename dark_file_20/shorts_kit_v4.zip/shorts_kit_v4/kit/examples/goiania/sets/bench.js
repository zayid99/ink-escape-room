// Shots 1, 3 and 7: the opened capsule glowing on a rusty scrapyard workbench at night.
// hook: low push-in. glow: wider, three silhouettes lean in around the light. cta: eases back to the
// exact hook start pose so the replay loops.
import * as THREE from 'three';
import { driftParticles, gradientTex, clamp, lerp, ease, smooth, rng, wobble } from '../lib.js';
import { makeCapsule, makeWrench, makeHammer, makeScrewdriver, scrapChunk, makeFigure, rustTex, concreteTex, corrugatedTex } from '../props.js';

export function hookPose(u) {
  // pure function: camera pose during the hook (u seconds into the shot)
  const p = ease(clamp(u / 4.4));
  return { pos: new THREE.Vector3(lerp(2.8, 2.45, p), lerp(0.66, 0.58, p), lerp(1.5, 1.25, p)), look: new THREE.Vector3(0.3, 0.13, 0.1) };
}

export function build() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x020406);
  scene.fog = new THREE.FogExp2(0x03070b, 0.035);
  scene.add(new THREE.HemisphereLight(0x22344a, 0x0c0a08, 0.22));
  const moon = new THREE.DirectionalLight(0x6f8fb8, 0.35); moon.position.set(-12, 20, -14); scene.add(moon);

  // bench: rusty steel top on a wooden frame; floor 9 units below
  const top = new THREE.Mesh(new THREE.BoxGeometry(16, 0.25, 7), new THREE.MeshStandardMaterial({ map: rustTex(5, [2, 1]), roughness: 0.75, metalness: 0.55 }));
  top.position.set(0, -0.125, 0); scene.add(top);
  const wood = new THREE.MeshStandardMaterial({ color: 0x2e2116, roughness: 0.9 });
  for (const [x, z] of [[-7.4, -3], [7.4, -3], [-7.4, 3], [7.4, 3]]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.6, 9, 0.6), wood); l.position.set(x, -4.6, z); scene.add(l); }
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), new THREE.MeshStandardMaterial({ map: concreteTex(4, [6, 6], '#3a3733'), roughness: 0.95 }));
  floor.rotation.x = -Math.PI / 2; floor.position.y = -9; scene.add(floor);
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(70, 30), new THREE.MeshStandardMaterial({ map: corrugatedTex(8, [3, 1]), roughness: 0.7, metalness: 0.4 }));
  wall.position.set(0, 4, -14); scene.add(wall);
  // faint cold sky through a gap in the wall
  const gap = new THREE.Mesh(new THREE.PlaneGeometry(9, 14), new THREE.MeshBasicMaterial({ map: gradientTex([[0, '#1a2a40'], [1, '#05080d']]), fog: false }));
  gap.position.set(-16, 6, -13.9); scene.add(gap);

  // a moonlit doorway behind the figures so they read as dark shapes
  const door = new THREE.Mesh(new THREE.PlaneGeometry(12, 24), new THREE.MeshBasicMaterial({ map: gradientTex([[0, '#30455f'], [0.6, '#1b2a3e'], [1, '#0b121c']]), fog: false }));
  door.position.set(0.2, 2.5, -13.85); scene.add(door);
  const doorGlow = new THREE.PointLight(0x5a7aa6, 6, 30, 1.2); doorGlow.position.set(0, 2, -12); scene.add(doorGlow);
  // the hero capsule: opening faces +X, toward the camera side
  const cap = makeCapsule(); cap.position.set(0, 0.2, 0); cap.rotation.y = -0.25; scene.add(cap);
  const fill = new THREE.PointLight(0x3a9cff, 3.0, 45, 1.3); fill.position.set(0.6, 1.2, 0); scene.add(fill);

  // supporting props on the bench
  const wr = makeWrench(); wr.position.set(-0.75, 0.03, 0.75); wr.rotation.y = 0.35; wr.scale.setScalar(0.8); scene.add(wr);
  const hm = makeHammer(); hm.position.set(-2.4, 0.12, -1.0); hm.rotation.y = -0.35; scene.add(hm);
  const sd = makeScrewdriver(); sd.position.set(0.55, 0.09, -0.55); sd.rotation.y = 2.75; scene.add(sd);
  const scrapMat = new THREE.MeshStandardMaterial({ map: rustTex(12, [0.5, 0.5]), roughness: 0.8, metalness: 0.5 });
  const lead = new THREE.MeshStandardMaterial({ color: 0x55585c, roughness: 0.55, metalness: 0.7 });
  // broken shielding drum piece (the heavy housing it came from)
  const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 0.9, 32, 1, false, 0, Math.PI * 1.3), lead); drum.rotation.set(Math.PI / 2, 0, 0.4); drum.position.set(-3.6, 0.9, -1.4); scene.add(drum);
  const R = rng(17);
  for (let i = 0; i < 9; i++) { const c = scrapChunk(40 + i, 0.18 + R() * 0.25, scrapMat); c.position.set(-4 + R() * 9, 0.08, -2.6 + R() * 1.8); c.rotation.y = R() * 6; scene.add(c); }
  for (let i = 0; i < 6; i++) { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.16, 6), lead); b.rotation.z = Math.PI / 2; b.rotation.y = R() * 6; b.position.set(-0.9 + R() * 1.2, 0.03, -0.9 + R() * 0.5); scene.add(b); }
  // scrap piles in the dark background
  for (let i = 0; i < 26; i++) { const c = scrapChunk(80 + i, 1 + R() * 2.2, scrapMat); c.position.set(-28 + R() * 56, -8 + R() * 1.2, -9 - R() * 4); c.rotation.set(R(), R() * 6, R()); scene.add(c); }
  const dust = driftParticles(500, new THREE.Box3(new THREE.Vector3(-3, -0.2, -2.5), new THREE.Vector3(4, 3.5, 3)), 9, 0x9fd8ff, 0.03, 0.45); scene.add(dust);

  // three silhouettes for the "showed his family and friends" shot
  const figs = [
    Object.assign(makeFigure({ lean: 0.42, armReach: 0.55 }), { pos: [-3.3, -9, -4.0], ry: 0.5 }),
    Object.assign(makeFigure({ lean: 0.32, armReach: 0.2, h: 16 }), { pos: [3.3, -9, -4.1], ry: -0.5 }),
    Object.assign(makeFigure({ lean: 0.2, armReach: 0.75, child: true }), { pos: [0.3, -9, -3.9], ry: 0.0 }),
  ];
  const figGrp = new THREE.Group(); scene.add(figGrp);
  figs.forEach((f) => { f.position.set(...f.pos); f.rotation.y = f.ry; figGrp.add(f); });
  // a cold rim light behind the figures so their outlines read against the wall
  const rim = new THREE.SpotLight(0x5b7da8, 40, 40, 0.7, 0.8, 1.2); rim.position.set(0, 8, -12); rim.target.position.set(0, -2, -3); scene.add(rim, rim.target);

  // a far, dim warm work-lamp for colour contrast on the scrap
  const lamp = new THREE.PointLight(0xff9a50, 2.2, 40, 1.4); lamp.position.set(-14, 6, -9); scene.add(lamp);
  // faint warm key from the left so the steel reads as steel, not blue plastic
  const key = new THREE.SpotLight(0xffc89a, 6, 20, 0.35, 0.8, 1.5); key.position.set(-3, 4, 3); key.target.position.set(0.2, 0.1, 0); scene.add(key, key.target);
  const camera = new THREE.PerspectiveCamera(34, 1080 / 1920, 0.02, 300);
  const out = { scene, camera, bloom: 0.42, exposure: 1.0 };
  out.update = (t, u, shot) => {
    cap.userData.update(t); dust.userData.update(t);
    const glow = shot.id === 'glow';
    figGrp.visible = glow; rim.visible = glow; doorGlow.visible = glow;
    fill.intensity = glow ? 9 : 3.0; fill.distance = glow ? 30 : 45;
    if (glow) { cap.userData.halo.scale.setScalar(7); cap.userData.halo.material.opacity = 0.8; }
    let pos, look;
    if (shot.id === 'hook') ({ pos, look } = hookPose(u));
    else if (glow) {
      // wide, high three-quarter view; slow orbit; figures lean in a little over the shot
      const p = ease(clamp(u / (shot.t1 - shot.t0)));
      const a = lerp(0.26, 0.1, p), d = lerp(25, 21.5, p);
      pos = new THREE.Vector3(Math.sin(a) * d, lerp(4.6, 3.9, p), Math.cos(a) * d); look = new THREE.Vector3(0, 3.6, -2.5);
      figs.forEach((f, i) => { f.userData.torso.rotation.x = (i === 2 ? 0.2 : 0.3) + 0.12 * smooth(0, 2.5, u + i * 0.4); });
    } else {
      // cta: start a little wider/higher and ease into the exact hook frame-1 pose at the very end
      const D = shot.t1 - shot.t0, p = ease(clamp(u / D));
      const h0 = hookPose(0);
      const start = { pos: new THREE.Vector3(3.6, 1.6, 2.4), look: new THREE.Vector3(0.1, 0.1, 0.0) };
      pos = start.pos.clone().lerp(h0.pos, p); look = start.look.clone().lerp(h0.look, p);
    }
    const sh = 0.006 * wobble(t, 0.4, 3);
    camera.position.set(pos.x + sh, pos.y + sh * 0.6, pos.z);
    camera.lookAt(look); camera.updateMatrixWorld();
  };
  scene.updateMatrixWorld();
  return out;
}
