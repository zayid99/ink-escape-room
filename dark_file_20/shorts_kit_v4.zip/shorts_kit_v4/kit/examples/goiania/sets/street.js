// Shot 6: a night street of small houses behind warning tape and floodlights. On "torn down"
// one house's walls and roof drop in a cloud of dust; the camera cranes up.
import * as THREE from 'three';
import { driftParticles, gradientTex, canvasTex, clamp, lerp, ease, smooth, rng, wobble, glowTex, sprite, stars } from '../lib.js';
import { plasterTex, concreteTex, rustTex, scrapChunk } from '../props.js';

function makeHouse(seed, w, d, h, col) {
  const g = new THREE.Group(); const R = rng(seed);
  const wallM = new THREE.MeshStandardMaterial({ map: plasterTex(seed, [1, 1], col), roughness: 0.9 });
  const roofM = new THREE.MeshStandardMaterial({ color: 0x5a2e1e, roughness: 0.85, map: rustTex(seed + 3, [2, 2], '#6a3524') });
  const parts = [];
  const add = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; g.add(m); parts.push(m); return m; };
  add(new THREE.BoxGeometry(w, h, 0.5), wallM, 0, h / 2, d / 2);
  add(new THREE.BoxGeometry(w, h, 0.5), wallM, 0, h / 2, -d / 2);
  add(new THREE.BoxGeometry(0.5, h, d), wallM, -w / 2, h / 2, 0);
  add(new THREE.BoxGeometry(0.5, h, d), wallM, w / 2, h / 2, 0);
  const roof = add(new THREE.CylinderGeometry(0.01, w * 0.78, h * 0.45, 4, 1), roofM, 0, h + h * 0.22, 0); roof.rotation.y = Math.PI / 4; roof.scale.z = d / w;
  // dark door + window
  const dark = new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 1 });
  add(new THREE.BoxGeometry(2.2, 5, 0.2), dark, -w * 0.2, 2.5, d / 2 + 0.3);
  add(new THREE.BoxGeometry(2.6, 2.2, 0.2), dark, w * 0.22, 4.6, d / 2 + 0.3);
  g.userData.parts = parts;
  return g;
}

export function build() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x05080d);
  scene.fog = new THREE.FogExp2(0x070a10, 0.011);
  scene.add(new THREE.HemisphereLight(0x33435c, 0x14100c, 0.45));
  const sky = new THREE.Mesh(new THREE.PlaneGeometry(600, 200), new THREE.MeshBasicMaterial({ map: gradientTex([[0, '#0b1424'], [0.7, '#141c28'], [1, '#1e1c1c']]), fog: false }));
  sky.position.set(0, 60, -160); scene.add(sky);
  scene.add(stars(300, 300, 4, 0.25));
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshStandardMaterial({ map: concreteTex(44, [20, 20], '#3d3934'), roughness: 0.95 }));
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  // a row of small houses on the far side of the street
  const cols = ['#a89a80', '#8d9a8a', '#b2a08a', '#9a9284', '#a29684'];
  const houses = [];
  for (let i = -3; i <= 3; i++) { const h = makeHouse(100 + i * 7, 11, 10, 8, cols[(i + 3) % cols.length]); h.position.set(i * 14, 0, -20); scene.add(h); houses.push(h); }
  const target = houses[3]; // the centre one comes down
  const tParts = target.userData.parts.map((m) => ({ m, p0: m.position.clone(), r0: m.rotation.clone() }));
  // floodlights on stands
  const floods = [];
  for (const x of [-9, 11]) {
    const head = sprite(glowTex(), 0xfff1d6, 2.6, 0.9); head.position.set(x, 11, -6); scene.add(head);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 11, 6), new THREE.MeshStandardMaterial({ color: 0x222222 })); pole.position.set(x, 5.5, -6); scene.add(pole);
    const L = new THREE.SpotLight(0xffeedd, 140, 80, 0.5, 0.6, 1.3); L.position.set(x, 11, -6); L.target.position.set(x * 0.2, 0, -14); L.castShadow = true; L.shadow.mapSize.set(1024, 1024); L.shadow.bias = -0.001; scene.add(L, L.target); floods.push(L);
  }
  // warning tape on posts across the foreground
  const tapeTex = canvasTex(512, 32, (g, W, H) => { for (let x = -H; x < W; x += 48) { g.fillStyle = '#e8c21e'; g.beginPath(); g.moveTo(x, 0); g.lineTo(x + 24, 0); g.lineTo(x + 24 + H, H); g.lineTo(x + H, H); g.fill(); g.fillStyle = '#111'; g.beginPath(); g.moveTo(x + 24, 0); g.lineTo(x + 48, 0); g.lineTo(x + 48 + H, H); g.lineTo(x + 24 + H, H); g.fill(); } }, { repeat: [8, 1] });
  const tape = new THREE.Mesh(new THREE.PlaneGeometry(90, 0.5), new THREE.MeshStandardMaterial({ map: tapeTex, roughness: 0.6, side: THREE.DoubleSide })); tape.position.set(0, 3.6, -8); scene.add(tape);
  for (let x = -40; x <= 40; x += 10) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 4, 6), new THREE.MeshStandardMaterial({ color: 0x8a8a8a })); p.position.set(x, 2, -8); scene.add(p); }
  // rubble left after the fall
  const rubM = new THREE.MeshStandardMaterial({ map: plasterTex(9, [0.5, 0.5], '#8f8572'), roughness: 1 });
  const rubble = new THREE.Group(); const R = rng(23);
  for (let i = 0; i < 40; i++) { const c = scrapChunk(500 + i, 0.6 + R() * 1.4, rubM); c.position.set((R() - 0.5) * 12, 0.3, -20 + (R() - 0.5) * 10); c.rotation.y = R() * 6; rubble.add(c); }
  scene.add(rubble);
  // dust cloud
  const puffs = []; const dR = rng(41);
  for (let i = 0; i < 40; i++) { const s = sprite(glowTex(), 0x7a7266, 6, 0, false); s.material.blending = THREE.NormalBlending; puffs.push({ s, d: new THREE.Vector3(dR() - 0.5, dR() * 0.5, dR() - 0.5).normalize(), v: 4 + dR() * 8 }); scene.add(s); }
  const motes = driftParticles(500, new THREE.Box3(new THREE.Vector3(-25, 0, -30), new THREE.Vector3(25, 20, 0)), 61, 0xe8dcc8, 0.12, 0.3); scene.add(motes);

  const camera = new THREE.PerspectiveCamera(40, 1080 / 1920, 0.1, 800);
  let TT = null; // "torn" word time
  const out = { scene, camera, bloom: 0.4, exposure: 0.95 };
  out.update = (t, u, shot) => {
    if (TT === null) TT = (window.__tl && window.__tl.words.find((w) => w.w.toLowerCase().startsWith('torn'))?.t0) || shot.t0 + 2.2;
    motes.userData.update(t);
    const dt = t - TT;
    const f = clamp(dt / 0.9);
    tParts.forEach(({ m, p0, r0 }, i) => {
      const k = f * f;
      const inward = i < 4 ? (i % 2 === 0 ? 1 : -1) : 0;
      m.position.set(p0.x * (1 - 0.3 * k), p0.y * (1 - 0.85 * k), p0.z * (1 - 0.3 * k));
      m.rotation.set(r0.x + (i < 2 ? inward * 1.2 * k : 0), r0.y, r0.z + (i >= 2 && i < 4 ? (i === 2 ? -1 : 1) * 1.2 * k : 0));
      m.visible = f < 1 || i < 5;
      if (f >= 1 && i < 5) m.position.y = Math.max(0.3, m.position.y);
    });
    rubble.visible = dt > 0.6; rubble.position.y = lerp(-1.2, 0, smooth(0.6, 1.2, dt));
    puffs.forEach(({ s, d, v }) => {
      const k = Math.max(0, dt - 0.3);
      s.position.set(d.x * v * (1 - Math.exp(-k * 1.4)), 2 + d.y * v * (1 - Math.exp(-k)) + k * 0.6, -20 + d.z * v * 0.6 * (1 - Math.exp(-k * 1.4)));
      s.material.opacity = dt > 0.3 ? 0.3 * smooth(0, 0.3, k) * Math.exp(-k * 0.35) : 0; s.scale.setScalar(5 + k * 6);
    });
    const D = shot.t1 - shot.t0, p = ease(clamp(u / D));
    const shk = dt > 0 ? Math.exp(-dt * 3) * 0.2 : 0;
    camera.position.set(lerp(-6, -3, p) + wobble(t, 3, 1) * shk, lerp(9, 16, p) + wobble(t, 2.6, 2) * shk, lerp(28, 32, p));
    camera.lookAt(0, lerp(2.5, 1.5, p), -18); camera.updateMatrixWorld();
  };
  scene.updateMatrixWorld();
  return out;
}
