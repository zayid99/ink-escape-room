// Shot list for Dark File #20, cut in the silence between voice lines.
export const SET_OVERRIDE = {}; // e.g. { clinic: 'bench' } while a set is still being built // e.g. { clinic: 'bench' } while a set is still being built
export function makeShots(tl) {
  const s = tl.segs;
  const mid = (a, b) => (s[a].t1 + s[b].t0) / 2;
  const c = [0, mid(0, 1), mid(2, 3), mid(3, 4), mid(4, 5), mid(5, 6), mid(6, 7), tl.dur];
  const ids = [['hook', 'bench'], ['clinic', 'clinic'], ['glow', 'bench'], ['turn', 'macro'], ['bus', 'bus'], ['street', 'street'], ['cta', 'bench']];
  return ids.map(([id, set], i) => ({ id, set: SET_OVERRIDE[set] || set, n: i + 1, t0: c[i], t1: c[i + 1] }));
}
export const shotAt = (shots, t) => shots.find((s) => t >= s.t0 && t < s.t1) || shots[shots.length - 1];
