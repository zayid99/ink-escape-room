"""Script for Dark File #20: the glowing blue powder of Goiania (1987).

Each segment is one voice line. {SHOWN|spoken words} shows SHOWN in captions but speaks the
second part. `gap` is the silence after the line, in seconds.
"""
VOICE = "am_michael"
SPEED = 1.2
LEAD_IN = 0.12   # first word must start by 0.2 s
TAIL = 0.7       # silence after the last line

SEGS = [
    {"text": "In {1987,|nineteen eighty-seven,} a scrapyard owner found powder that glowed blue.", "gap": 0.40},
    {"text": "A clinic in Brazil had moved, and left an old cancer machine behind.", "gap": 0.30},
    {"text": "Two men took it apart and sold its heavy metal capsule for scrap.", "gap": 0.35},
    {"text": "At night, it glowed. He showed his family and friends.", "gap": 0.45},
    {"text": "But that blue powder was {caesium-137.|seezium one thirty-seven.} It was radioactive.", "gap": 0.45},
    {"text": "His wife carried the pieces in {a|uh} bag, on {a|uh} bus, to health officials.", "gap": 0.35},
    {"text": "Four people died. Seven homes were torn down to the ground.", "gap": 0.45},
    {"text": "Tap the button below for {a|uh} new dark file every day.", "gap": 0.0},
]

import re

TOKEN = re.compile(r"\{([^|}]*)\|([^|}]*)(?:\|(\d+))?\}|(\S+)")


def tokens(text):
    """[(shown, spoken, forced_model_word_count or None)] per display token."""
    out = []
    for m in TOKEN.finditer(text):
        if m.group(4) is not None:
            out.append((m.group(4), m.group(4), None))
        else:
            out.append((m.group(1), m.group(2), int(m.group(3)) if m.group(3) else None))
    return out


def spoken(text):
    return " ".join(sp for _, sp, _ in tokens(text))
