// Caption + label layer (rendered as its own transparent pass).
const clean = (w) => w.replace(/[.,;:!]+$/g, '').replace(/["“”]/g, '');

// caption groups for this video, as word counts per voice line (hand-set so lines break naturally)
const GROUPS = { 0: [2, 3, 2, 3], 1: [2, 2, 2, 2, 3, 2], 2: [2, 3, 2, 3, 3], 3: [2, 2, 2, 2, 2], 4: [2, 2, 2, 3], 5: [2, 3, 3, 3, 3], 6: [3, 2, 3, 3], 7: [4, 3, 2, 2] };
export function makeChunks(words) {
  const chunks = [];
  const bySeg = {};
  for (const w of words) (bySeg[w.seg] = bySeg[w.seg] || []).push(w);
  for (const seg of Object.keys(bySeg).map(Number).sort((a, b) => a - b)) {
    const ws = bySeg[seg]; let g = GROUPS[seg];
    if (!g || g.reduce((a, b) => a + b, 0) !== ws.length) { g = []; for (let i = 0; i < ws.length; i += 3) g.push(Math.min(3, ws.length - i)); console.log('caption group fallback for seg', seg); }
    let k = 0;
    for (const n of g) { chunks.push({ seg, words: ws.slice(k, k + n).map((w) => ({ txt: clean(w.w), t0: w.t0, t1: w.t1 })) }); k += n; }
  }
  for (let i = 0; i < chunks.length; i++) {
    const c = chunks[i];
    c.t0 = i === 0 ? 0 : c.words[0].t0 - 0.04;
    c.t1 = i < chunks.length - 1 ? chunks[i + 1].words[0].t0 - 0.04 : 1e9;
  }
  return chunks;
}

export function makeOverlay(tl, shots) {
  const ui = document.getElementById('ui');
  const chunks = makeChunks(tl.words);
  const S = tl.segs;
  const Wd = (seg, txt) => tl.words.find((w) => w.seg === seg && w.w.replace(/[.,]/g, '').toLowerCase() === txt.toLowerCase()) || null;
  const tCs = Wd(4, 'caesium-137')?.t0 ?? S[4].t0 + 1.2, tIt = Wd(4, 'it')?.t0 ?? S[4].t0 + 2.2, tSeven = Wd(6, 'seven')?.t0 ?? S[6].t0 + 1.2;
  const labels = [
    { html: 'DARK FILE <b>#20</b>', cls: 'top file', t0: 0, t1: 2.0 },
    { html: 'GOIÂNIA, BRAZIL · 1987', cls: 'top', t0: 2.0, t1: shots[0].t1 },
    { html: 'ABANDONED CLINIC', cls: 'top', t0: shots[1].t0 + 0.1, t1: S[2].t0 - 0.05 },
    { html: 'SEPT 13, 1987', cls: 'top', t0: S[2].t0, t1: shots[1].t1 },
    { html: 'CAESIUM-137', cls: 'top', t0: tCs, t1: tIt - 0.05 },
    { html: '93 GRAMS OF POWDER', cls: 'top', t0: tIt, t1: shots[3].t1 },
    { html: 'SEPT 28, 1987', cls: 'top', t0: shots[4].t0 + 0.1, t1: shots[4].t1 },
    { html: '4 DEAD', cls: 'top', t0: S[6].t0, t1: tSeven - 0.05 },
    { html: '7 HOMES DEMOLISHED', cls: 'top', t0: tSeven, t1: tSeven + 1.45 },
    { html: '112,000 PEOPLE CHECKED', cls: 'top', t0: tSeven + 1.5, t1: shots[5].t1 },
  ];
  const sat = (x) => Math.min(1, Math.max(0, x));
  return (t) => {
    let h = '';
    // labels fade in/out over 0.15 s
    for (const l of labels) if (t >= l.t0 && t < l.t1) {
      const a = Math.min(l.t0 === 0 ? 1 : sat((t - l.t0) / 0.15), sat((l.t1 - t) / 0.15));
      h += `<div class="lab ${l.cls}" style="opacity:${a.toFixed(3)}">${l.html}</div>`;
    }
    const c = chunks.find((c) => t >= c.t0 && t < c.t1);
    if (c) {
      let on = -1; c.words.forEach((w, i) => { if (t >= w.t0 - 0.03) on = i; });
      if (on < 0) on = 0;
      h += `<div id="cap"><span class="line">${c.words.map((w, i) => `<span class="${i === on ? 'on' : ''}">${w.txt}</span>`).join(' ')}</span></div>`;
    }
    ui.innerHTML = h;
    const cap = document.getElementById('cap');
    if (cap) { cap.style.fontSize = ''; const w = cap.querySelector('.line').scrollWidth; if (w > 800) cap.style.fontSize = (98 * 800 / w).toFixed(1) + 'px'; }
  };
}
