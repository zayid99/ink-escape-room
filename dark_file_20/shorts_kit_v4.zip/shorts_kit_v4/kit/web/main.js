import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { Pass } from 'three/addons/postprocessing/Pass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { makeShots, shotAt } from './shots.js';
import { makeOverlay } from './overlay.js';

const q = new URLSearchParams(location.search);
const PASS = q.get('pass') || '3d';
const SCALE = parseFloat(q.get('scale') || '1');
const W = Math.round(1080 * SCALE), H = Math.round(1920 * SCALE);
const tl = await (await fetch('/web/timeline.json')).json();
const shots = makeShots(tl);
window.__tl = tl;
window.meta = { frames: tl.frames, fps: tl.fps, dur: tl.dur, shots };

// Renders two scenes into one frame: sceneA above a horizontal split line, sceneB below it.
class SplitPass extends Pass {
  constructor() { super(); this.needsSwap = false; }
  render(renderer, writeBuffer, readBuffer) {
    const { a, b, splitY } = this.set.split; // splitY: fraction of frame height from the top
    const tgt = this.renderToScreen ? null : readBuffer;
    renderer.setRenderTarget(tgt);
    const w = tgt ? tgt.width : renderer.domElement.width, h = tgt ? tgt.height : renderer.domElement.height;
    renderer.setScissorTest(true);
    const yb = Math.round(h * (1 - splitY));
    renderer.setScissor(0, yb, w, h - yb); renderer.setViewport(0, 0, w, h); renderer.clear(); renderer.render(a.scene, a.camera);
    renderer.setScissor(0, 0, w, yb); renderer.clear(); renderer.render(b.scene, b.camera);
    renderer.setScissorTest(false);
  }
}

if (PASS === 'ui') {
  const ui = document.getElementById('ui'); ui.style.transform = `scale(${SCALE})`;
  document.body.style.width = W + 'px'; document.body.style.height = H + 'px';
  const draw = makeOverlay(tl, shots);
  await document.fonts.load('104px Anton'); await document.fonts.load('700 38px JBM'); await document.fonts.load('600 34px JBM');
  window.renderAt = (t) => draw(t);
  window.ready = true;
} else {
  document.documentElement.style.background = '#000'; document.body.style.background = '#000';
  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true, alpha: false });
  renderer.setClearColor(0x000000, 1);
  renderer.setPixelRatio(1); renderer.setSize(W, H);
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; // only lights with castShadow cost anything
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.0;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  document.body.appendChild(renderer.domElement);
  const composer = new EffectComposer(renderer);
  composer.setPixelRatio(1); composer.setSize(W, H);
  const rp = new RenderPass(new THREE.Scene(), new THREE.PerspectiveCamera());
  const sp = new SplitPass();
  const bloom = new UnrealBloomPass(new THREE.Vector2(W / 2, H / 2), 0.45, 0.6, 0.78);
  // clamp out-of-range / NaN pixels before bloom so one bad highlight can't flood the frame
  const sanitize = new ShaderPass({
    uniforms: { tDiffuse: { value: null } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
    fragmentShader: 'uniform sampler2D tDiffuse; varying vec2 vUv; void main(){ vec4 c = texture2D(tDiffuse, vUv); if (any(isnan(c)) || any(isinf(c))) c = vec4(0.0, 0.0, 0.0, 1.0); gl_FragColor = vec4(clamp(c.rgb, 0.0, 30.0), 1.0); }',
  });
  composer.addPass(rp); composer.addPass(sanitize); composer.addPass(bloom); composer.addPass(new OutputPass());
  if (q.get('nobloom')) bloom.enabled = false;
  const builders = {
    bench: () => import('./sets/bench.js'), clinic: () => import('./sets/clinic.js'), macro: () => import('./sets/macro.js'),
    bus: () => import('./sets/bus.js'), street: () => import('./sets/street.js'),
  };
  const cache = {};
  const getSet = async (name) => { if (!cache[name]) cache[name] = (await builders[name]()).build(); return cache[name]; };
  window.renderAt = async (t) => {
    const shot = shotAt(shots, t);
    const set = await getSet(shot.set);
    set.update(t, t - shot.t0, shot);
    if (set.split) { sp.set = set; composer.passes[0] = sp; }
    else { rp.scene = set.scene; rp.camera = set.camera; composer.passes[0] = rp; }
    bloom.strength = set.bloom ?? 0.45;
    renderer.toneMappingExposure = set.exposure ?? 1.0;
    composer.render();
    return shot.id;
  };
  // warm-up: build every set and render each of its scenes once, so all textures upload before the first capture
  for (const sh of shots) {
    const set = await getSet(sh.set);
    const probes = [sh.t0 + 0.3];
    for (const pt of probes) await window.renderAt(pt);
  }
  window.ready = true;
}
