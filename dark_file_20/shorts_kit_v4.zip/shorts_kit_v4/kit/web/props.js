// Reusable props for Dark File #20 (Goiania): the opened caesium source capsule, workshop tools,
// silhouette figures and grimy procedural textures. Units: 1 unit = 10 cm. Pure functions of time only.
import * as THREE from 'three';
import { canvasTex, rng, glowTex, sprite } from './lib.js';

// ---------- textures ----------
function speckle(g, w, h, n, r0, r1, cols, a, seed) {
  const R = rng(seed);
  for (let i = 0; i < n; i++) {
    g.globalAlpha = a * (0.3 + R() * 0.7); g.fillStyle = cols[Math.floor(R() * cols.length)];
    const r = r0 + R() * (r1 - r0); g.beginPath(); g.arc(R() * w, R() * h, r, 0, 6.283); g.fill();
  }
  g.globalAlpha = 1;
}
function blot(g, x, y, r, rgb, a) {
  const gr = g.createRadialGradient(x, y, 0, x, y, r);
  gr.addColorStop(0, `rgba(${rgb},${a})`); gr.addColorStop(1, `rgba(${rgb},0)`);
  g.fillStyle = gr; g.fillRect(x - r, y - r, 2 * r, 2 * r);
}
// rusty steel plate: base grey, rust blooms, scratches
export function rustTex(seed = 1, rep = [1, 1], base = '#4a4844') {
  return canvasTex(1024, 1024, (g, W, H) => {
    g.fillStyle = base; g.fillRect(0, 0, W, H);
    speckle(g, W, H, 14000, 0.6, 3, ['#2e2c29', '#5c5850', '#3d3a35'], 0.45, seed);
    const R = rng(seed + 9);
    for (let i = 0; i < 70; i++) blot(g, R() * W, R() * H, 20 + R() * 130, R() < 0.5 ? '120,64,28' : '86,46,22', 0.35 + R() * 0.35);
    speckle(g, W, H, 3000, 0.5, 2.2, ['#8a4a20', '#a2602a', '#6b3518'], 0.6, seed + 3);
    g.strokeStyle = 'rgba(170,165,155,0.18)'; g.lineWidth = 1;
    for (let i = 0; i < 160; i++) { const x = R() * W, y = R() * H, a = R() * 6.283, l = 20 + R() * 120; g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke(); }
    // oil stains
    for (let i = 0; i < 8; i++) blot(g, R() * W, R() * H, 40 + R() * 90, '12,10,8', 0.5);
  }, { repeat: rep });
}
// brushed stainless steel with grime, for the capsule
export function steelTex(seed = 4) {
  return canvasTex(512, 512, (g, W, H) => {
    g.fillStyle = '#8f9396'; g.fillRect(0, 0, W, H);
    const R = rng(seed);
    for (let y = 0; y < H; y++) { g.fillStyle = `rgba(${R() < 0.5 ? '255,255,255' : '0,0,0'},${0.03 + R() * 0.05})`; g.fillRect(0, y, W, 1); }
    for (let i = 0; i < 40; i++) blot(g, R() * W, R() * H, 10 + R() * 60, '40,36,30', 0.35);
    for (let i = 0; i < 18; i++) blot(g, R() * W, R() * H, 6 + R() * 30, '110,70,40', 0.3);
    g.strokeStyle = 'rgba(30,30,30,0.35)'; g.lineWidth = 1.2;
    for (let i = 0; i < 60; i++) { const x = R() * W, y = R() * H; g.beginPath(); g.moveTo(x, y); g.lineTo(x + (R() - 0.5) * 60, y + (R() - 0.5) * 10); g.stroke(); }
  });
}
export function concreteTex(seed = 2, rep = [1, 1], base = '#5a5752') {
  return canvasTex(1024, 1024, (g, W, H) => {
    g.fillStyle = base; g.fillRect(0, 0, W, H);
    speckle(g, W, H, 20000, 0.5, 2.5, ['#3f3c38', '#6c6862', '#4b4843'], 0.4, seed);
    const R = rng(seed + 5);
    for (let i = 0; i < 40; i++) blot(g, R() * W, R() * H, 40 + R() * 180, R() < 0.6 ? '20,18,16' : '90,80,62', 0.25 + R() * 0.25);
    g.strokeStyle = 'rgba(15,14,12,0.6)'; g.lineWidth = 1.5;
    for (let i = 0; i < 10; i++) { let x = R() * W, y = R() * H; g.beginPath(); g.moveTo(x, y); for (let k = 0; k < 8; k++) { x += (R() - 0.5) * 60; y += R() * 40; g.lineTo(x, y); } g.stroke(); }
  }, { repeat: rep });
}
// dirty square wall tiles (old clinic)
export function tileTex(seed = 3, rep = [1, 1]) {
  return canvasTex(1024, 1024, (g, W, H) => {
    g.fillStyle = '#9ea69f'; g.fillRect(0, 0, W, H);
    const n = 8, s = W / n, R = rng(seed);
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      const v = 150 + R() * 30; g.fillStyle = `rgb(${v - 8},${v},${v - 6})`;
      if (R() < 0.06) g.fillStyle = '#4a4a44'; // missing tile
      g.fillRect(i * s + 3, j * s + 3, s - 6, s - 6);
    }
    g.fillStyle = 'rgba(60,58,50,0.9)';
    for (let i = 0; i <= n; i++) { g.fillRect(i * s - 3, 0, 6, H); g.fillRect(0, i * s - 3, W, 6); }
    for (let i = 0; i < 50; i++) blot(g, R() * W, R() * H * 0.9 + H * 0.1, 30 + R() * 160, R() < 0.5 ? '50,46,32' : '80,66,40', 0.3 + R() * 0.3);
    // drips from the top
    for (let i = 0; i < 40; i++) { const x = R() * W; const l = 80 + R() * 400; const gr = g.createLinearGradient(0, 0, 0, l); gr.addColorStop(0, 'rgba(50,40,24,0.5)'); gr.addColorStop(1, 'rgba(50,40,24,0)'); g.fillStyle = gr; g.fillRect(x, 0, 3 + R() * 6, l); }
  }, { repeat: rep });
}
export function plasterTex(seed = 6, rep = [1, 1], base = '#8c8070') {
  return canvasTex(512, 512, (g, W, H) => {
    g.fillStyle = base; g.fillRect(0, 0, W, H);
    speckle(g, W, H, 8000, 0.5, 2.5, ['#6a6052', '#a09382', '#7a7062'], 0.35, seed);
    const R = rng(seed + 1);
    for (let i = 0; i < 25; i++) blot(g, R() * W, R() * H, 30 + R() * 120, '40,34,26', 0.3);
    const gr = g.createLinearGradient(0, H * 0.7, 0, H); gr.addColorStop(0, 'rgba(40,30,20,0)'); gr.addColorStop(1, 'rgba(40,30,20,0.6)'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
  }, { repeat: rep });
}
export function corrugatedTex(seed = 8, rep = [1, 1]) {
  return canvasTex(1024, 1024, (g, W, H) => {
    for (let x = 0; x < W; x++) { const v = 70 + 28 * Math.sin(x / W * 6.283 * 24); g.fillStyle = `rgb(${v},${v - 3},${v - 8})`; g.fillRect(x, 0, 1, H); }
    const R = rng(seed);
    for (let i = 0; i < 90; i++) blot(g, R() * W, R() * H, 20 + R() * 140, R() < 0.6 ? '110,58,24' : '30,24,18', 0.3 + R() * 0.4);
    for (let i = 0; i < 30; i++) { const x = R() * W; const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, 'rgba(100,50,20,0.5)'); gr.addColorStop(1, 'rgba(100,50,20,0)'); g.fillStyle = gr; g.fillRect(x, R() * H * 0.3, 2 + R() * 4, H); }
  }, { repeat: rep });
}

// ---------- the hero: opened caesium source capsule ----------
// Lies along X. The front cap (+X) is punctured open; blue powder heaps inside and spills out.
export function makeCapsule() {
  const grp = new THREE.Group();
  const steel = new THREE.MeshStandardMaterial({ map: steelTex(), color: 0xffffff, metalness: 0.85, roughness: 0.38, side: THREE.DoubleSide });
  const r = 0.2, L = 0.42;
  const body = new THREE.Mesh(new THREE.CylinderGeometry(r, r, L, 48, 1, true), steel);
  body.rotation.z = Math.PI / 2; grp.add(body);
  // rim bands
  for (const x of [-L / 2 + 0.03, L / 2 - 0.02]) { const b = new THREE.Mesh(new THREE.TorusGeometry(r + 0.004, 0.012, 8, 48), steel); b.rotation.y = Math.PI / 2; b.position.x = x; grp.add(b); }
  const back = new THREE.Mesh(new THREE.CircleGeometry(r, 48), steel); back.rotation.y = -Math.PI / 2; back.position.x = -L / 2; grp.add(back);
  // front cap with a jagged hole (torn by a screwdriver)
  const sh = new THREE.Shape(); sh.absarc(0, 0, r, 0, Math.PI * 2, false);
  const hole = new THREE.Path(); const R = rng(21);
  for (let i = 0; i <= 18; i++) { const a = i / 18 * Math.PI * 2; const rr = r * (0.55 + R() * 0.22); const x = Math.cos(a) * rr + 0.02, y = Math.sin(a) * rr - 0.01; i ? hole.lineTo(x, y) : hole.moveTo(x, y); }
  sh.holes.push(hole);
  const cap = new THREE.Mesh(new THREE.ExtrudeGeometry(sh, { depth: 0.012, bevelEnabled: false, curveSegments: 32 }), steel);
  cap.rotation.y = Math.PI / 2; cap.position.x = L / 2 - 0.006; grp.add(cap);
  // bent flap of torn metal
  const flap = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.12, 0.09), steel); flap.position.set(L / 2 + 0.05, 0.12, 0.02); flap.rotation.set(0.3, 0, -0.9); grp.add(flap);
  // glowing powder: inside heap + spill
  const glowMat = new THREE.MeshStandardMaterial({ color: 0x0a2a44, emissive: 0x3fb4ff, emissiveIntensity: 1.3, roughness: 0.9 });
  const heap = new THREE.Mesh(new THREE.SphereGeometry(0.17, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), glowMat);
  heap.scale.set(1.25, 0.55, 0.95); heap.position.set(0.05, -0.16, 0); grp.add(heap);
  const inner = new THREE.Mesh(new THREE.CircleGeometry(r * 0.96, 32), new THREE.MeshBasicMaterial({ color: 0x2c88d8, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false }));
  inner.rotation.y = Math.PI / 2; inner.position.x = L / 2 - 0.02; grp.add(inner);
  // grains spilled on the bench in front of the opening (y = -r is the bench surface)
  const N = 1400, gGeo = new THREE.DodecahedronGeometry(0.0048, 0);
  const grains = new THREE.InstancedMesh(gGeo, new THREE.MeshStandardMaterial({ color: 0x0a2a44, emissive: 0x52c2ff, emissiveIntensity: 1.5, roughness: 0.9 }), N);
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), v = new THREE.Vector3(), s = new THREE.Vector3();
  for (let i = 0; i < N; i++) {
    const d = Math.pow(R(), 1.9) * 0.7, a = (R() - 0.5) * 2.0;
    v.set(L / 2 + 0.02 + Math.cos(a) * d, -r + 0.006, Math.sin(a) * d * 0.9);
    const k = 0.4 + R() * 1.4 * (1 - d); s.set(k, k * 0.6, k);
    e.set(R() * 6, R() * 6, R() * 6); q.setFromEuler(e); m.compose(v, q, s); grains.setMatrixAt(i, m);
  }
  grp.add(grains);
  // a smear of dust on the bench (additive decal)
  const smear = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 1.1), new THREE.MeshBasicMaterial({ map: glowTex(), color: 0x2f9cf0, transparent: true, opacity: 0.2, blending: THREE.AdditiveBlending, depthWrite: false }));
  smear.rotation.x = -Math.PI / 2; smear.position.set(L / 2 + 0.3, -r + 0.004, 0); grp.add(smear);
  const halo = sprite(glowTex(), 0x58c4ff, 0.7, 0.3); halo.position.set(L / 2 + 0.05, -0.08, 0); grp.add(halo);
  const light = new THREE.PointLight(0x46b0ff, 1.6, 9, 1.8); light.position.set(L / 2 + 0.3, 0.12, 0); grp.add(light);
  grp.userData = { light, halo, glowMat, grains, smear, inner };
  // breathing glow, pure function of t
  grp.userData.update = (t, k = 1) => {
    const f = 1 + 0.06 * Math.sin(t * 2.1) + 0.03 * Math.sin(t * 7.3 + 1);
    light.intensity = 1.6 * f * k; halo.material.opacity = 0.3 * f * k; halo.scale.setScalar(0.7 * (0.95 + 0.05 * f));
    glowMat.emissiveIntensity = 1.3 * f * k; grains.material.emissiveIntensity = 1.5 * f * k; smear.material.opacity = 0.2 * f * k;
  };
  return grp;
}

// ---------- tools ----------
const darkSteel = () => new THREE.MeshStandardMaterial({ color: 0x6b6d6e, metalness: 0.8, roughness: 0.45, map: rustTex(31, [0.3, 0.3], '#5d5e5e') });
export function makeWrench() {
  const g = new THREE.Group(), mat = darkSteel();
  const shaft = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.05, 0.16), mat); g.add(shaft);
  const jaw = new THREE.Shape(); jaw.absarc(0, 0, 0.17, 0, Math.PI * 2, false); const h = new THREE.Path(); h.moveTo(0.05, -0.07); h.lineTo(0.25, -0.07); h.lineTo(0.25, 0.07); h.lineTo(0.05, 0.07); h.lineTo(0.05, -0.07); jaw.holes.push(h);
  const j = new THREE.Mesh(new THREE.ExtrudeGeometry(jaw, { depth: 0.05, bevelEnabled: false }), mat); j.rotation.x = Math.PI / 2; j.position.set(0.8, 0.025, 0); g.add(j);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.04, 8, 24), mat); ring.rotation.x = Math.PI / 2; ring.position.x = -0.8; g.add(ring);
  return g;
}
export function makeHammer() {
  const g = new THREE.Group();
  const wood = new THREE.MeshStandardMaterial({ color: 0x5a3e26, roughness: 0.8 });
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 2.6, 12), wood); handle.rotation.z = Math.PI / 2; g.add(handle);
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.24, 0.8), darkSteel()); head.position.set(1.25, 0.04, 0); g.add(head);
  return g;
}
export function makeScrewdriver() {
  const g = new THREE.Group();
  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.09, 0.8, 8), new THREE.MeshStandardMaterial({ color: 0x3b2a1c, roughness: 0.6 })); grip.rotation.z = Math.PI / 2; g.add(grip);
  const bit = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 1.0, 8), new THREE.MeshStandardMaterial({ color: 0x9a9c9e, metalness: 0.9, roughness: 0.3 })); bit.rotation.z = Math.PI / 2; bit.position.x = 0.9; g.add(bit);
  return g;
}
// a jagged scrap chunk
export function scrapChunk(seed, size = 1, mat) {
  const geo = new THREE.IcosahedronGeometry(size, 0); const p = geo.attributes.position; const R = rng(seed);
  for (let i = 0; i < p.count; i++) p.setXYZ(i, p.getX(i) * (0.6 + R() * 0.8), p.getY(i) * (0.3 + R() * 0.5), p.getZ(i) * (0.6 + R() * 0.8));
  geo.computeVertexNormals();
  return new THREE.Mesh(geo, mat);
}

// ---------- silhouette figure (no face, matte black) ----------
// pose: { lean (rad forward), sit (bool), armReach (0..1), h (height units) }
export function makeFigure(pose = {}) {
  const { lean = 0.15, sit = false, armReach = 0.3, h = 17, child = false } = pose;
  const k = h / 17;
  const mat = new THREE.MeshStandardMaterial({ color: 0x07080a, roughness: 0.85, metalness: 0.0 });
  const root = new THREE.Group();
  const hips = new THREE.Group(); hips.position.y = sit ? 4.4 * k : 8.6 * k; root.add(hips);
  const legGeo = new THREE.CapsuleGeometry(0.62 * k, 7.2 * k, 4, 10);
  for (const s of [-1, 1]) {
    if (sit) {
      const th = new THREE.Mesh(new THREE.CapsuleGeometry(0.66 * k, 3.6 * k, 4, 10), mat); th.rotation.x = Math.PI / 2; th.position.set(s * 0.8 * k, 0, 2.0 * k); hips.add(th);
      const sh = new THREE.Mesh(new THREE.CapsuleGeometry(0.56 * k, 3.4 * k, 4, 10), mat); sh.position.set(s * 0.8 * k, -2.1 * k, 4.0 * k); hips.add(sh);
    } else { const l = new THREE.Mesh(legGeo, mat); l.position.set(s * 0.8 * k, -4.2 * k, 0); hips.add(l); }
  }
  const torso = new THREE.Group(); torso.rotation.x = lean; hips.add(torso);
  const tg = new THREE.LatheGeometry([[0.01, 0], [1.5, 0.2], [1.55, 2.5], [2.0, 5.2], [1.9, 5.9], [0.6, 6.4], [0.01, 6.5]].map(([x, y]) => new THREE.Vector2(x * k, y * k)), 18);
  const tor = new THREE.Mesh(tg, mat); tor.scale.z = 0.6; torso.add(tor);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.45 * k, 0.5 * k, 0.9 * k, 10), mat); neck.position.y = 6.8 * k; torso.add(neck);
  const head = new THREE.Mesh(new THREE.SphereGeometry(1.08 * k, 18, 14), mat); head.scale.set(0.88, 1.08, 0.98); head.position.y = 8.1 * k; torso.add(head);
  const arms = [];
  for (const s of [-1, 1]) {
    const sh = new THREE.Group(); sh.position.set(s * 1.95 * k, 5.6 * k, 0); torso.add(sh);
    const up = new THREE.Mesh(new THREE.CapsuleGeometry(0.45 * k, 2.8 * k, 4, 8), mat); up.position.y = -1.7 * k; sh.add(up);
    const el = new THREE.Group(); el.position.y = -3.3 * k; sh.add(el);
    const lo = new THREE.Mesh(new THREE.CapsuleGeometry(0.38 * k, 2.6 * k, 4, 8), mat); lo.position.y = -1.5 * k; el.add(lo);
    sh.rotation.x = -armReach * 1.1; sh.rotation.z = s * 0.12; el.rotation.x = -armReach * 0.7;
    arms.push({ sh, el });
  }
  if (child) root.scale.setScalar(0.62);
  root.userData = { hips, torso, arms, head, mat };
  return root;
}
