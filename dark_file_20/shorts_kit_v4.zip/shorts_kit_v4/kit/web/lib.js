// Shared helpers, procedural textures and models. Every animation is a pure function of time.
import * as THREE from 'three';

export const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a, b, t) => a + (b - a) * t;
export const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };
export const ease = (t) => { t = clamp(t); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
export const easeOut = (t) => 1 - Math.pow(1 - clamp(t), 3);
export function rng(seed) { let s = (seed >>> 0) || 1; return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return (s >>> 0) / 4294967296; }; }
// smooth deterministic noise for camera shake etc.
export const wobble = (t, f = 1, seed = 0) => Math.sin(t * f * 6.283 + seed) * 0.6 + Math.sin(t * f * 13.7 + seed * 2.1) * 0.3 + Math.sin(t * f * 27.3 + seed * 3.7) * 0.1;

export function canvasTex(w, h, draw, opts = {}) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c);
  if (opts.srgb !== false) t.colorSpace = THREE.SRGBColorSpace;
  if (opts.repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(opts.repeat[0], opts.repeat[1]); }
  t.anisotropy = 4;
  return t;
}

function noiseDots(g, w, h, n, r0, r1, colors, alpha, seed) {
  const R = rng(seed);
  for (let i = 0; i < n; i++) {
    g.globalAlpha = alpha * (0.4 + R() * 0.6);
    g.fillStyle = colors[Math.floor(R() * colors.length)];
    const r = r0 + R() * (r1 - r0);
    g.beginPath(); g.arc(R() * w, R() * h, r, 0, 6.283); g.fill();
  }
  g.globalAlpha = 1;
}
function blotch(g, x, y, r, col, a) {
  const gr = g.createRadialGradient(x, y, 0, x, y, r);
  gr.addColorStop(0, col.replace('A', a)); gr.addColorStop(1, col.replace('A', 0));
  g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
}

// ---------- bomb paint (lathe UV: u around, v nose->tail; canvas top = tail) ----------
export function bombTextures(variant = 'sea') {
  const W = 2048, H = 1024;
  const sea = variant === 'sea';
  const map = canvasTex(W, H, (g) => {
    g.fillStyle = sea ? '#56524a' : '#5d6553'; g.fillRect(0, 0, W, H);
    noiseDots(g, W, H, 9000, 1, 5, sea ? ['#3a3c35', '#5a5e52', '#45473f'] : ['#525a49', '#6a7260', '#59614f'], 0.35, 7);
    const R = rng(11);
    // panel seams (constant v) + rivets
    g.strokeStyle = 'rgba(20,22,18,0.55)'; g.lineWidth = 3;
    for (const v of [0.12, 0.22, 0.45, 0.62, 0.75]) {
      const y = H * (1 - v); g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke();
      g.fillStyle = 'rgba(30,30,26,0.6)';
      for (let x = 8; x < W; x += 28) { g.beginPath(); g.arc(x, y + 7, 2.2, 0, 6.283); g.fill(); }
    }
    // access panel outlines
    g.strokeStyle = 'rgba(25,26,22,0.5)'; g.lineWidth = 2.5;
    g.strokeRect(W * 0.2, H * 0.42, 150, 90); g.strokeRect(W * 0.7, H * 0.5, 110, 140);
    // rust / weathering
    const nR = sea ? 110 : 10;
    for (let i = 0; i < nR; i++) blotch(g, R() * W, R() * H, 20 + R() * (sea ? 140 : 40), 'rgba(122,70,32,A)', sea ? 0.55 : 0.25);
    if (sea) {
      for (let i = 0; i < 18; i++) blotch(g, R() * W, R() * H, 40 + R() * 140, 'rgba(70,86,52,A)', 0.3); // algae tint
      // streaks along the axis
      for (let i = 0; i < 220; i++) {
        const x = R() * W, y = R() * H, l = 40 + R() * 260;
        g.strokeStyle = `rgba(${90 + R() * 50},${55 + R() * 25},${30},${0.15 + R() * 0.25})`; g.lineWidth = 1 + R() * 4;
        g.beginPath(); g.moveTo(x, y); g.lineTo(x + (R() - 0.5) * 8, y + l); g.stroke();
      }
      noiseDots(g, W, H, 2600, 2, 9, ['#8a5a2e', '#6e4423', '#a26a36'], 0.35, 23);
      noiseDots(g, W, H, 1800, 1, 4, ['#c8c2a8', '#9fa08c'], 0.25, 29);
    } else {
      // stenciled bands near nose
      g.fillStyle = 'rgba(200,170,60,0.75)'; g.fillRect(0, H * (1 - 0.16), W, 14);
    }
  });
  const bump = canvasTex(1024, 512, (g, w, h) => {
    g.fillStyle = '#808080'; g.fillRect(0, 0, w, h);
    noiseDots(g, w, h, sea ? 7000 : 2500, 1, sea ? 6 : 3, ['#5a5a5a', '#a8a8a8', '#707070', '#949494'], 0.5, 41);
    g.strokeStyle = '#3a3a3a'; g.lineWidth = 2;
    for (const v of [0.12, 0.22, 0.45, 0.62, 0.75]) { const y = h * (1 - v); g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
  }, { srgb: false });
  return { map, bump };
}

// Mark 15-style bomb. Nose at -Y, tail (fins) at +Y, centered. Length 3.6, radius 0.44.
export function makeBomb(variant = 'sea') {
  const g = new THREE.Group();
  const pts = [];
  pts.push(new THREE.Vector2(0.0001, -1.8));
  for (let i = 1; i <= 14; i++) { const th = (i / 14) * Math.PI / 2; pts.push(new THREE.Vector2(0.44 * Math.sin(th), -1.8 + 0.46 * (1 - Math.cos(th)))); }
  pts.push(new THREE.Vector2(0.44, 0.7));
  for (let i = 1; i <= 8; i++) { const k = i / 8; pts.push(new THREE.Vector2(0.44 - 0.22 * Math.pow(k, 1.3), 0.7 + 1.05 * k)); }
  pts.push(new THREE.Vector2(0.2, 1.8)); pts.push(new THREE.Vector2(0.0001, 1.8));
  const { map, bump } = bombTextures(variant);
  const mat = new THREE.MeshStandardMaterial({ map, bumpMap: bump, bumpScale: variant === 'sea' ? 2.2 : 0.8, metalness: 0.45, roughness: variant === 'sea' ? 0.82 : 0.55 });
  const body = new THREE.Mesh(new THREE.LatheGeometry(pts, 96), mat);
  g.add(body);
  const finMat = new THREE.MeshStandardMaterial({ color: 0xffffff, map, bumpMap: bump, bumpScale: 1.5, metalness: 0.4, roughness: 0.8 });
  const fs = new THREE.Shape();
  fs.moveTo(0.36, 0.86); fs.lineTo(0.98, 1.32); fs.lineTo(0.98, 1.86); fs.lineTo(0.2, 1.82); fs.closePath();
  const fg = new THREE.ExtrudeGeometry(fs, { depth: 0.045, bevelEnabled: false }); fg.translate(0, 0, -0.0225);
  for (let i = 0; i < 4; i++) { const f = new THREE.Mesh(fg, finMat); f.rotation.y = i * Math.PI / 2 + Math.PI / 4; g.add(f); }
  const bandMat = new THREE.MeshStandardMaterial({ color: 0x2c2d28, metalness: 0.6, roughness: 0.6 });
  for (const y of [-1.0, -0.15, 0.62]) { const b = new THREE.Mesh(new THREE.TorusGeometry(0.446, 0.014, 8, 96), bandMat); b.rotation.x = Math.PI / 2; b.position.y = y; g.add(b); }
  for (const y of [-0.45, 0.35]) { const lug = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.16, 0.08), bandMat); lug.position.set(0, y, 0.45); g.add(lug); }
  if (variant === 'sea') {
    const R = rng(5), n = 150;
    const bar = new THREE.InstancedMesh(new THREE.SphereGeometry(0.026, 7, 5), new THREE.MeshStandardMaterial({ color: 0x7d7a68, roughness: 0.95 }), n);
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3();
    for (let i = 0; i < n; i++) {
      const a = R() * 6.283, y = -1.3 + R() * 2.0, r = 0.44;
      p.set(Math.sin(a) * r, y, Math.cos(a) * r);
      const sc = 0.4 + R() * 0.9; s.set(sc, sc * 0.55, sc);
      q.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(Math.sin(a), 0, Math.cos(a)));
      m.compose(p, q, s); bar.setMatrixAt(i, m);
    }
    g.add(bar);
  }
  g.traverse((o) => { if (o.isMesh) { o.castShadow = false; o.receiveShadow = false; } });
  return g;
}

// ---------- sediment / sand ----------
export function mudFaceTexture() {
  return canvasTex(2048, 1024, (g, W, H) => {
    const bands = [['#4a3f2e', 0.0], ['#382f22', 0.07], ['#2b2419', 0.18], ['#3a3122', 0.3], ['#231d15', 0.42], ['#30281c', 0.55], ['#1b1611', 0.68], ['#251f17', 0.8], ['#14110d', 0.9]];
    const R = rng(3);
    for (let i = 0; i < bands.length; i++) {
      const [col, y0] = bands[i];
      g.fillStyle = col; g.beginPath(); g.moveTo(0, H);
      for (let x = 0; x <= W; x += 32) { const y = y0 * H + Math.sin(x * 0.004 + i * 1.7) * 14 + Math.sin(x * 0.013 + i) * 6; g.lineTo(x, y); }
      g.lineTo(W, H); g.closePath(); g.fill();
    }
    noiseDots(g, W, H, 26000, 0.8, 3, ['#5a4e3c', '#1e1913', '#463b2c', '#6a5c47'], 0.45, 9);
    // shell fragments and pebbles
    for (let i = 0; i < 160; i++) {
      const x = R() * W, y = R() * H, r = 3 + R() * 9;
      g.strokeStyle = `rgba(${190 + R() * 40},${180 + R() * 30},${150 + R() * 30},${0.35 + R() * 0.35})`; g.lineWidth = 1.5 + R() * 2;
      g.beginPath(); g.arc(x, y, r, R() * 3, R() * 3 + 2.2); g.stroke();
    }
    noiseDots(g, W, H, 380, 3, 10, ['#5b5547', '#4b463b', '#6f6858'], 0.8, 13);
    // top lighter sand layer
    const gr = g.createLinearGradient(0, 0, 0, H * 0.08); gr.addColorStop(0, 'rgba(140,128,100,0.55)'); gr.addColorStop(1, 'rgba(140,128,100,0)');
    g.fillStyle = gr; g.fillRect(0, 0, W, H * 0.08);
  });
}
export function sandTexture(rep = 6) {
  return canvasTex(1024, 1024, (g, W, H) => {
    g.fillStyle = '#3a3226'; g.fillRect(0, 0, W, H);
    noiseDots(g, W, H, 22000, 0.8, 3, ['#4a4132', '#2c261d', '#564b39', '#40372a'], 0.55, 17);
    g.strokeStyle = 'rgba(30,26,20,0.25)'; g.lineWidth = 6;
    for (let y = 0; y < H; y += 46) { g.beginPath(); for (let x = 0; x <= W; x += 16) g.lineTo(x, y + Math.sin(x * 0.02 + y) * 6); g.stroke(); }
    noiseDots(g, W, H, 140, 2, 7, ['#b9b092', '#8d856c'], 0.5, 19);
  }, { repeat: [rep, rep] });
}

export function gradientTex(stops, w = 16, h = 512) {
  return canvasTex(w, h, (g, W, H) => {
    const gr = g.createLinearGradient(0, 0, 0, H);
    for (const [o, c] of stops) gr.addColorStop(o, c);
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
  });
}
export function radialTex(stops, size = 256) {
  return canvasTex(size, size, (g, W) => {
    const gr = g.createRadialGradient(W / 2, W / 2, 0, W / 2, W / 2, W / 2);
    for (const [o, c] of stops) gr.addColorStop(o, c);
    g.fillStyle = gr; g.fillRect(0, 0, W, W);
  });
}
export const glowTex = () => radialTex([[0, 'rgba(255,255,255,1)'], [0.2, 'rgba(255,255,255,0.55)'], [0.5, 'rgba(255,255,255,0.12)'], [1, 'rgba(255,255,255,0)']]);

export function sprite(tex, color, size, opacity = 1, additive = true) {
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, color, transparent: true, opacity, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, fog: false }));
  s.scale.set(size, size, 1);
  return s;
}

// floating particles in a box; positions are a pure function of t
export function driftParticles(n, box, seed, color = 0xcfe6ea, size = 0.03, opacity = 0.5) {
  const R = rng(seed);
  const base = new Float32Array(n * 3), vel = new Float32Array(n * 3), pos = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    base[i * 3] = box.min.x + R() * (box.max.x - box.min.x);
    base[i * 3 + 1] = box.min.y + R() * (box.max.y - box.min.y);
    base[i * 3 + 2] = box.min.z + R() * (box.max.z - box.min.z);
    vel[i * 3] = (R() - 0.5) * 0.06; vel[i * 3 + 1] = -0.02 - R() * 0.05; vel[i * 3 + 2] = (R() - 0.5) * 0.05;
  }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const mat = new THREE.PointsMaterial({ color, size, transparent: true, opacity, depthWrite: false, map: glowTex(), blending: THREE.AdditiveBlending, sizeAttenuation: true });
  const pts = new THREE.Points(geo, mat);
  const sx = box.max.x - box.min.x, sy = box.max.y - box.min.y, sz = box.max.z - box.min.z;
  pts.userData.update = (t) => {
    for (let i = 0; i < n; i++) {
      const wx = Math.sin(t * 0.7 + i) * 0.04;
      pos[i * 3] = box.min.x + (((base[i * 3] - box.min.x + vel[i * 3] * t + wx) % sx) + sx) % sx;
      pos[i * 3 + 1] = box.min.y + (((base[i * 3 + 1] - box.min.y + vel[i * 3 + 1] * t) % sy) + sy) % sy;
      pos[i * 3 + 2] = box.min.z + (((base[i * 3 + 2] - box.min.z + vel[i * 3 + 2] * t) % sz) + sz) % sz;
    }
    geo.attributes.position.needsUpdate = true;
  };
  return pts;
}

// soft additive light shafts through water
export function lightShafts(n, seed, area) {
  const g = new THREE.Group();
  const tex = canvasTex(64, 512, (c, W, H) => {
    const gr = c.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, 'rgba(255,255,255,0.9)'); gr.addColorStop(0.6, 'rgba(255,255,255,0.25)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = gr; c.fillRect(0, 0, W, H);
    const gx = c.createLinearGradient(0, 0, W, 0); gx.addColorStop(0, 'rgba(0,0,0,1)'); gx.addColorStop(0.5, 'rgba(0,0,0,0)'); gx.addColorStop(1, 'rgba(0,0,0,1)');
    c.globalCompositeOperation = 'destination-out'; c.fillStyle = gx; c.fillRect(0, 0, W, H);
  });
  const R = rng(seed);
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(area.w * (0.6 + R()), area.h), new THREE.MeshBasicMaterial({ map: tex, color: 0x9fd8e0, transparent: true, opacity: 0.05 + R() * 0.05, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false }));
    m.position.set(area.x0 + R() * area.dx, area.y, area.z0 + R() * area.dz);
    m.rotation.z = (R() - 0.5) * 0.5 + 0.25; m.rotation.y = (R() - 0.5) * 0.6;
    m.userData.ph = R() * 6; g.add(m);
  }
  g.userData.update = (t) => g.children.forEach((m, i) => { m.material.opacity = (0.05 + 0.04 * Math.sin(t * 0.8 + m.userData.ph)) ; m.rotation.z = 0.25 + Math.sin(t * 0.25 + m.userData.ph) * 0.06; });
  return g;
}

// ---------- aircraft ----------
const alu = () => new THREE.MeshStandardMaterial({ color: 0x9aa3ab, metalness: 0.75, roughness: 0.38 });
function slab(points, depth) {
  const s = new THREE.Shape(); s.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i++) s.lineTo(points[i][0], points[i][1]);
  s.closePath();
  const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: true, bevelThickness: depth * 0.4, bevelSize: depth * 0.4, bevelSegments: 1 });
  g.translate(0, 0, -depth / 2);
  return g;
}
function fuselage(profile, segs = 48) {
  // profile: [[x, r]] along X; lathe is around Y so rotate after
  const pts = profile.map(([x, r]) => new THREE.Vector2(Math.max(0.0001, r), x));
  const g = new THREE.LatheGeometry(pts, segs); g.rotateZ(-Math.PI / 2);
  return g;
}
function navLight(color, size = 0.5) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), new THREE.MeshBasicMaterial({ color }));
  const s = sprite(glowTex(), color, size * 3, 0.9); m.add(s); return m;
}
// B-47-style six-jet bomber, nose toward -X, ~33 m long
export function makeBomber() {
  const g = new THREE.Group(); const mat = alu();
  g.add(new THREE.Mesh(fuselage([[-16.5, 0], [-16, 0.5], [-14.5, 1.0], [-11, 1.3], [-4, 1.4], [6, 1.35], [12, 0.95], [16.5, 0.35], [16.8, 0]]), mat));
  const wingR = new THREE.Mesh(slab([[-3.4, 0.9], [8.6, 17.5], [11.2, 17.5], [3.4, 0.9]], 0.24), mat); wingR.rotation.x = Math.PI / 2; wingR.position.y = 1.05;
  const wl = new THREE.Mesh(slab([[-3.4, -0.9], [8.6, -17.5], [11.2, -17.5], [3.4, -0.9]], 0.24), mat); wl.rotation.x = Math.PI / 2; wl.position.y = 1.05;
  g.add(wingR, wl);
  g.userData.wingR = wingR; g.userData.wingL = wl;
  const pod = (x, z, twin) => {
    const pg = new THREE.Group();
    const n = twin ? 2 : 1;
    for (let i = 0; i < n; i++) {
      const c = new THREE.Mesh(fuselage([[-2.3, 0.48], [-2.1, 0.58], [0, 0.62], [1.6, 0.5], [2.1, 0.32]], 24), mat);
      c.position.z = twin ? (i - 0.5) * 1.25 : 0; pg.add(c);
      const intake = new THREE.Mesh(new THREE.CircleGeometry(0.46, 20), new THREE.MeshBasicMaterial({ color: 0x050607 })); intake.rotation.y = -Math.PI / 2; intake.position.set(-2.31, 0, c.position.z); pg.add(intake);
    }
    const py = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.0, 0.18), mat); py.position.set(0.6, 0.75, 0); pg.add(py);
    pg.position.set(x, -0.25, z); return pg;
  };
  g.add(pod(1.6, 6.4, true), pod(1.6, -6.4, true), pod(7.6, 12.8, false), pod(7.6, -12.8, false));
  const fin = new THREE.Mesh(slab([[11.5, 1.0], [15.8, 7.2], [17.8, 7.2], [16.8, 0.9]], 0.18), mat); g.add(fin);
  const hs = new THREE.Mesh(slab([[13.6, 0.4], [16.2, 6.0], [17.4, 6.0], [16.6, 0.4]], 0.14), mat); hs.rotation.x = Math.PI / 2; hs.position.y = 1.1; g.add(hs);
  const hs2 = new THREE.Mesh(slab([[13.6, -0.4], [16.2, -6.0], [17.4, -6.0], [16.6, -0.4]], 0.14), mat); hs2.rotation.x = Math.PI / 2; hs2.position.y = 1.1; g.add(hs2);
  const glass = new THREE.MeshStandardMaterial({ color: 0x1a2630, metalness: 0.2, roughness: 0.08, emissive: 0x05090c });
  const can = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12), glass); can.scale.set(3.2, 0.75, 0.68); can.position.set(-11.2, 1.05, 0); g.add(can);
  const nlR = navLight(0x33ff66); nlR.position.set(11.2, 1.05, 17.6); const nlL = navLight(0xff2a1a); nlL.position.set(11.2, 1.05, -17.6);
  const tail = navLight(0xffffff, 0.35); tail.position.set(16.9, 0.3, 0);
  const beacon = navLight(0xff2010, 0.9); beacon.position.set(-2, -1.5, 0); g.add(nlR, nlL, tail, beacon);
  g.userData.beacon = beacon;
  // bomb bay recess + doors (underside, mid fuselage)
  const bay = new THREE.Mesh(new THREE.BoxGeometry(5.2, 0.3, 1.25), new THREE.MeshBasicMaterial({ color: 0x030405 })); bay.position.set(-0.5, -1.27, 0); g.add(bay);
  const dmat = new THREE.MeshStandardMaterial({ color: 0x8f989f, metalness: 0.7, roughness: 0.42, side: THREE.DoubleSide });
  const mkDoor = (side) => { const h = new THREE.Group(); const d = new THREE.Mesh(new THREE.BoxGeometry(5.1, 0.05, 0.62), dmat); d.position.z = side * 0.31; h.add(d); h.position.set(-0.5, -1.4, side * 0.63); return h; };
  const doorA = mkDoor(-1), doorB = mkDoor(1);
  doorA.position.z = 0.62; doorA.children[0].position.z = -0.31; doorB.position.z = -0.62; doorB.children[0].position.z = 0.31;
  g.add(doorA, doorB); g.userData.doors = [doorA, doorB];
  return g;
}
// F-86-style fighter, nose toward -X, ~11 m long. Wings are separate so one can tear off.
export function makeFighter() {
  const g = new THREE.Group(); const mat = alu();
  g.add(new THREE.Mesh(fuselage([[-5.7, 0.42], [-5.2, 0.6], [-3, 0.74], [0, 0.78], [3, 0.6], [5.4, 0.38], [5.7, 0.3]], 32), mat));
  const intake = new THREE.Mesh(new THREE.CircleGeometry(0.38, 20), new THREE.MeshBasicMaterial({ color: 0x050607 })); intake.rotation.y = -Math.PI / 2; intake.position.x = -5.71; g.add(intake);
  const wR = new THREE.Mesh(slab([[-1.6, 0.5], [2.0, 5.65], [3.3, 5.65], [1.6, 0.5]], 0.16), mat); wR.rotation.x = Math.PI / 2; wR.position.y = -0.3;
  const wL = new THREE.Mesh(slab([[-1.6, -0.5], [2.0, -5.65], [3.3, -5.65], [1.6, -0.5]], 0.16), mat); wL.rotation.x = Math.PI / 2; wL.position.y = -0.3;
  g.add(wR, wL); g.userData.wingR = wR; g.userData.wingL = wL;
  g.add(new THREE.Mesh(slab([[2.6, 0.5], [5.0, 3.1], [6.1, 3.1], [5.6, 0.4]], 0.12), mat));
  const hs = new THREE.Mesh(slab([[3.9, 0.3], [5.2, 2.1], [6.0, 2.1], [5.7, 0.3]], 0.1), mat); hs.rotation.x = Math.PI / 2; hs.position.y = 0.2; g.add(hs);
  const hs2 = new THREE.Mesh(slab([[3.9, -0.3], [5.2, -2.1], [6.0, -2.1], [5.7, -0.3]], 0.1), mat); hs2.rotation.x = Math.PI / 2; hs2.position.y = 0.2; g.add(hs2);
  const can = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 10), new THREE.MeshStandardMaterial({ color: 0x1a2630, metalness: 0.2, roughness: 0.08 })); can.scale.set(1.3, 0.5, 0.45); can.position.set(-2.8, 0.62, 0); g.add(can);
  const a = navLight(0x33ff66, 0.35); a.position.set(3.3, -0.3, 5.7); wR.attach(a);
  const b = navLight(0xff2a1a, 0.35); b.position.set(3.3, -0.3, -5.7); wL.attach(b);
  return g;
}

// ---------- 1950s small search boat, bow toward -X ----------
export function makeBoat(withLight = true) {
  const g = new THREE.Group();
  const hullMat = new THREE.MeshStandardMaterial({ color: 0x4b5258, metalness: 0.3, roughness: 0.7 });
  const hs = new THREE.Shape(); hs.moveTo(-5, 0.9); hs.quadraticCurveTo(-4.2, -0.4, -2.2, -0.6); hs.lineTo(4.6, -0.6); hs.lineTo(5, 0.9); hs.closePath();
  const hull = new THREE.Mesh(new THREE.ExtrudeGeometry(hs, { depth: 2.4, bevelEnabled: true, bevelThickness: 0.2, bevelSize: 0.2, bevelSegments: 2 }), hullMat); hull.position.z = -1.2; g.add(hull);
  const cab = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.5, 1.9), new THREE.MeshStandardMaterial({ color: 0x8a9096, metalness: 0.2, roughness: 0.6 })); cab.position.set(0.5, 1.7, 0); g.add(cab);
  const win = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.4), new THREE.MeshBasicMaterial({ color: 0xffcf7a })); win.position.set(-0.71, 1.95, 0); win.rotation.y = -Math.PI / 2; g.add(win);
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3.2), hullMat); mast.position.set(1.2, 3.4, 0); g.add(mast);
  const mlight = navLight(0xffffff, 0.4); mlight.position.set(1.2, 5.0, 0); g.add(mlight);
  if (withLight) {
    const lamp = new THREE.Group(); lamp.position.set(-0.6, 2.6, 0); g.add(lamp);
    const head = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.28, 0.4, 14), hullMat); head.rotation.z = Math.PI / 2; lamp.add(head);
    const lens = sprite(glowTex(), 0xfff2c8, 1.6, 0.95); lens.position.x = -0.25; lamp.add(lens);
    const cone = new THREE.Mesh(new THREE.ConeGeometry(2.0, 30, 24, 1, true), new THREE.MeshBasicMaterial({ color: 0xfff1c6, transparent: true, opacity: 0.035, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }));
    cone.geometry.translate(0, -15, 0); cone.rotation.z = Math.PI / 2 + 0.12; lamp.add(cone);
    g.userData.lamp = lamp; g.userData.cone = cone;
  }
  return g;
}

// ---------- water surface (normal map scrolls with time) ----------
export function waterNormalTex(seed = 2) {
  return canvasTex(512, 512, (g, W, H) => {
    const img = g.createImageData(W, H); const R = rng(seed);
    const waves = Array.from({ length: 14 }, () => ({ kx: Math.round((R() - 0.5) * 10), ky: Math.round((R() - 0.5) * 10) || 1, a: 0.3 + R(), p: R() * 6.28 }));
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      let dx = 0, dy = 0;
      for (const w of waves) { const ph = (w.kx * x / W + w.ky * y / H) * 6.283 + w.p; const c = Math.cos(ph) * w.a; dx += c * w.kx; dy += c * w.ky; }
      const i = (y * W + x) * 4; img.data[i] = 128 + dx * 4; img.data[i + 1] = 128 + dy * 4; img.data[i + 2] = 230; img.data[i + 3] = 255;
    }
    g.putImageData(img, 0, 0);
  }, { srgb: false, repeat: [24, 24] });
}

export function skyDome(stops, radius = 900) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(radius, 32, 16), new THREE.MeshBasicMaterial({ map: gradientTex(stops), side: THREE.BackSide, fog: false, depthWrite: false }));
  return m;
}
export function stars(n, radius, seed, minY = 0.05) {
  const R = rng(seed); const p = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const u = R() * 2 - 1, th = R() * 6.283; let y = Math.abs(u); if (y < minY) y = minY + R() * 0.5;
    const r = Math.sqrt(1 - y * y); p[i * 3] = Math.cos(th) * r * radius; p[i * 3 + 1] = y * radius; p[i * 3 + 2] = Math.sin(th) * r * radius;
  }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(p, 3));
  return new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xdfe8ff, size: 2.2, sizeAttenuation: false, transparent: true, opacity: 0.8, fog: false, depthWrite: false }));
}

// moonlight glitter on a night sea: twinkling points along a path from near the camera toward the moon
export function glitter(n, seed, from, to, w0, w1) {
  const R = rng(seed); const p = new Float32Array(n * 3), col = new Float32Array(n * 3), ph = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const k = Math.pow(R(), 1.25); const x = lerp(from.x, to.x, k), z = lerp(from.z, to.z, k);
    const w = lerp(w0, w1, k) * (R() - 0.5) * (0.4 + 0.6 * R());
    p[i * 3] = x + w; p[i * 3 + 1] = from.y; p[i * 3 + 2] = z; ph[i] = R() * 50;
  }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(p, 3)); geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({ size: 0.3, map: glowTex(), vertexColors: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true, fog: false }));
  pts.userData.update = (t) => {
    for (let i = 0; i < n; i++) { const v = 0.35 + 1.4 * Math.pow(Math.max(0, Math.sin(t * 5 + ph[i])), 6); col[i * 3] = v * 0.75; col[i * 3 + 1] = v * 0.82; col[i * 3 + 2] = v; }
    geo.attributes.color.needsUpdate = true;
  };
  return pts;
}
