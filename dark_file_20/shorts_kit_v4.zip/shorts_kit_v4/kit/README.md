# shorts_kit v4: Zayid's 3D "Dark File" Shorts pipeline

v4: 15 Oct 2026 (Dark File #20, the Goiania glowing powder). v3 was Dark File #19 (Tybee bomb). Narration with exact word timing,
Three.js 3D scenes rendered frame by frame, word-by-word captions, synthesized music and effects.
Use together with cta_kit.zip (avatar + Subscribe/Follow pops).

## Setup (fresh workspace)
1. `mkdir -p /home/claude/short && cp -r kit/* /home/claude/short/` (paths in tools/ are hard-coded to that folder)
2. `bash /home/claude/short/tools/setup.sh` (GitHub and npm/pip are reachable; Hugging Face is not)
3. Unzip cta_kit.zip to /home/claude/ and read its README.

## Files
- tools/script_data.py: the voice lines (SEGS). `{SHOWN|spoken}` shows one thing in captions but says another,
  e.g. `{1958,|nineteen fifty-eight,}`. `{x|y|1}` forces how many model words the token covers. `gap` = pause after the line.
- tools/tts.py: voice (am_michael, SPEED 1.2, never change) -> audio/vo.wav + web/timeline.json. Prints MISMATCH if words can't be timed.
- tools/asr_check.py: transcribes every line. Compare SCRIPT vs HEARD and fix anything swallowed.
- web/shots.js: shot list (cut in the gaps between voice lines). web/sets/*.js: one file per scene, each exports build().
- web/overlay.js: captions (GROUPS = hand-set words per caption line, per voice line) + labels + extras.
- web/lib.js: helpers + reusable models: makeBomb, makeBomber, makeFighter, makeBoat, sky dome, stars, particles,
  light shafts, water normal map, moon glitter, sediment textures.
- web/sets/cut.js exports addWater / addSeabed / addSonar (underwater cutaway); drop.js exports seaSurface / coastLights; sky.js exports cloudLayer.
- tools/render.mjs: `--pass 3d|ui`, `--scale 0.5` previews, `--times 1,2.5`, `--from/--to` frame ranges, `--out dir`.
- web/props.js (v4): makeCapsule (glowing opened source capsule), makeWrench/makeHammer/makeScrewdriver, scrapChunk,
  makeFigure (faceless silhouette: standing/sitting/child, lean, arm reach), textures rustTex/steelTex/concreteTex/tileTex/plasterTex/corrugatedTex.
- web/sets/bench.js, clinic.js, macro.js, bus.js, street.js (v4, Dark File #20). bench.js hookPose() shows the loop trick: the CTA shot eases into the exact frame-1 pose.
- web/shots.js SET_OVERRIDE: map an unfinished set to a finished one so previews run while you build.
- tools/scan.py (v4): scans finished frames for black frames, white haze and jumps that are not at a cut (cuts come from out/cuts.json, written by render.mjs). Exit 1 if anything is flagged.
- tools/sheet.py: contact sheet `python3 tools/sheet.py out/prev out/sheet.jpg 8 240 [uidir]`.
- tools/audio.py: music + effects + mix. Rewrite the cue section per video. Levels are set relative to the voice.
- tools/assemble.sh NAME: final MP4.
- examples/tybee_bomb/: the full Dark File #19 versions of the per-video files, as a reference.
- examples/goiania/: the full Dark File #20 versions (script, shots, overlay, audio, sets).

## Run order
1. Edit tools/script_data.py -> `python3 tools/tts.py && python3 tools/asr_check.py`
2. Write web/sets/<name>.js, update shots.js ids/sets, main.js `builders`, overlay.js labels + GROUPS.
3. Preview: `xvfb-run -a -s "-screen 0 1280x1024x24" node tools/render.mjs --pass 3d --scale 0.5 --times 0.1,3,6 --out out/prev`
   then `node tools/render.mjs --pass ui --scale 0.5 --times 0.1,3,6 --out out/prevui` and
   `python3 tools/sheet.py out/prev out/sheet.jpg 8 240 out/prevui`. LOOK at the sheet.
4. Check one full-resolution frame (no --scale) before the full render.
5. Full: `nohup xvfb-run -a -s "-screen 0 1280x1024x24" node tools/render.mjs --pass 3d --out frames/3d > logs/r.log 2>&1 &`
   (about 0.6-0.8 s/frame, 900 frames is about 10-12 min), then `node tools/render.mjs --pass ui --out frames/ui`,
   `python3 tools/scan.py frames/3d`, `python3 tools/audio.py`, `bash tools/assemble.sh NAME`.
6. `python3 /home/claude/cta_kit/apply_cta.py apply final/NAME.mp4 --out-dir final --pops TURN,CTA`
   (TURN = start of the turn line, CTA = start of "Tap the button..." from web/timeline.json segs).

## Hard-won rules
- 3D must run headed Chromium under xvfb with `--use-gl=angle --use-angle=gl` (Mesa llvmpipe; render.mjs does it). SwiftShader is ~7x slower.
- main.js warms up every scene once at startup. Keep it: textures that first upload mid-run got scrambled (white haze in a whole shot).
- main.js has a sanitize pass that clamps NaN/huge pixels before bloom. Keep it. In shaders, clamp before pow(): pow(negative) = NaN = black boxes.
- Renderer is alpha:false on a black page, otherwise transparent pixels screenshot as white.
- Every animation is a pure function of time. No accumulated state.
- Moon/sun lights must not face the camera across water: specular glare turns the sea white. Use glitter() for moonlight on water instead.
- Camera-facing sprites stretched tall (scale.y >> x) become vertical light pillars. Don't use them for reflections.
- Portrait planes: shoot aircraft from directly below with camera.up = (-1,0,0) so the fuselage runs top to bottom.
- Canvas textures max 4096 wide.
- Kokoro merges "for a" into one word and drops the "a". Write `for {a|uh}`. Also watch "in the", "of the", "on the". asr_check.py catches these.
- Captions: hand-set GROUPS so no line ends on a/the/into; lines wider than 800 px auto-shrink. Keep captions at y 1150-1260, labels at y 318.
- Safe zone x 60-880, y 290-1300. Avatar corner x 40-230, y 1320-1490 stays empty.
- First label at t=0 must not fade in (frame 1 needs it visible).
- Mix: music about -17 dB and effects about -9 dB under the voice, then -14 LUFS. Check the printed ratios.
- Final MP4 under 30 MB (crf 19 gives about 13 MB for 30 s).
- (v4) Shadows are on in main.js (PCF soft); only lights with castShadow cost time. Keep castShadow to 1-3 spotlights per set.
- (v4) A glowing hero object needs restraint: emissive about 1.3, halo sprite under 0.4 opacity, point light about 1.6 at close range.
  Higher values plus bloom turn a close-up into flat blue haze. Check a full-resolution frame, not just the half-scale sheet.
- (v4) Silhouette figures vanish against a black set. Put a dim moonlit doorway/window plane behind them (MeshBasic, fog:false).
- (v4) Macro "grains": use instanced boxes with per-instance colour (setColorAt), low emissive (about 0.16) and two nearby point
  lights. High emissive makes them read as flat cartoon ice.
- (v4) Foreground props within about 1 m of a close-up camera look huge. Keep them behind or beside the hero object.
- (v4) Run the speech check on the final mix too (not just vo.wav) to be sure effects never bury a word.
- (v4) This container may block news, encyclopedia and IAEA websites (only GitHub, npm and PyPI open). If so, say so plainly; fact checks then rest on search-result extracts.
