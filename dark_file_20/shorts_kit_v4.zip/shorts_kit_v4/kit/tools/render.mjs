// Frame renderer. 3D pass runs headed Chromium under xvfb on Mesa llvmpipe (much faster than SwiftShader).
// usage: node tools/render.mjs --pass 3d|ui [--scale 0.5] [--times 1,2.5] [--from 0 --to 900] [--out frames/3d]
import { chromium } from 'playwright';
import http from 'http'; import fs from 'fs'; import path from 'path';

const A = {}; for (let i = 2; i < process.argv.length; i += 2) A[process.argv[i].replace(/^--/, '')] = process.argv[i + 1];
const pass = A.pass || '3d', scale = parseFloat(A.scale || '1');
const out = A.out || `frames/${pass}`;
const ROOT = '/home/claude/short';
fs.mkdirSync(path.resolve(ROOT, out), { recursive: true });
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.woff2': 'font/woff2', '.woff': 'font/woff', '.png': 'image/png', '.jpg': 'image/jpeg' };
const server = http.createServer((req, res) => {
  const f = path.join(ROOT, decodeURIComponent(req.url.split('?')[0]));
  if (!f.startsWith(ROOT) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  fs.createReadStream(f).pipe(res);
}).listen(0);
const port = server.address().port;
const W = Math.round(1080 * scale), H = Math.round(1920 * scale);
const browser = pass === '3d'
  ? await chromium.launch({ headless: false, args: ['--use-gl=angle', '--use-angle=gl', '--ignore-gpu-blocklist', '--enable-webgl', '--no-sandbox', `--window-size=${W},${H + 100}`] })
  : await chromium.launch({ headless: true, executablePath: '/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell' });
const page = await browser.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
page.on('console', (m) => { const t = m.text(); if (/error|Error|warn/i.test(t) && !/404/.test(t)) console.log('[page]', t.slice(0, 300)); });
page.on('pageerror', (e) => console.log('[pageerror]', e.message));
await page.goto(`http://127.0.0.1:${port}/web/index.html?pass=${pass}&scale=${scale}`);
await page.waitForFunction(() => window.ready === true, null, { timeout: 120000 });
const meta = await page.evaluate(() => window.meta);
fs.mkdirSync(path.resolve(ROOT, 'out'), { recursive: true });
fs.writeFileSync(path.resolve(ROOT, 'out/cuts.json'), JSON.stringify(meta.shots.slice(1).map((s) => +s.t0.toFixed(3)))); // read by tools/scan.py
if (pass === '3d') { const gl = await page.evaluate(() => { const c = document.querySelector('canvas'); const g = c.getContext('webgl2'); const d = g.getExtension('WEBGL_debug_renderer_info'); return d ? g.getParameter(d.UNMASKED_RENDERER_WEBGL) : 'n/a'; }); console.log('GL:', gl); }
let list;
if (A.times) list = A.times.split(',').map((s) => ({ t: parseFloat(s), name: String(Math.round(parseFloat(s) * meta.fps)).padStart(5, '0') }));
else { const f0 = parseInt(A.from || '0'), f1 = Math.min(meta.frames, parseInt(A.to || String(meta.frames))); list = []; for (let f = f0; f < f1; f++) list.push({ t: f / meta.fps, name: String(f).padStart(5, '0') }); }
const t0 = Date.now();
for (let i = 0; i < list.length; i++) {
  const { t, name } = list[i];
  await page.evaluate(async (t) => { await window.renderAt(t); }, t);
  await page.screenshot({ path: path.resolve(ROOT, out, name + '.png'), clip: { x: 0, y: 0, width: W, height: H }, omitBackground: pass === 'ui' });
  if (i % 30 === 29 || i === list.length - 1) console.log(`${i + 1}/${list.length} frames, ${((Date.now() - t0) / 1000 / (i + 1)).toFixed(2)} s/frame`);
}
await browser.close(); server.close();
