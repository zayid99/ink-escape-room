#!/bin/bash
# One-time setup in a fresh workspace. Run from /home/claude/short.
set -e
cd /home/claude/short
npm init -y >/dev/null
npm i three@0.170.0 @fontsource/anton @fontsource/jetbrains-mono playwright@1.56.1 --silent
pip install --break-system-packages -q kokoro-onnx soundfile pyloudnorm onnx sherpa-onnx scipy
mkdir -p models audio frames out logs final
cd models
[ -f kokoro-v1.0.onnx ] || curl -sSL -o kokoro-v1.0.onnx https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx
[ -f voices-v1.0.bin ] || curl -sSL -o voices-v1.0.bin https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin
python3 - <<'PY'
import onnx, os
from onnx import helper, TensorProto
if not os.path.exists("kokoro-v1.0-timed.onnx"):
    m = onnx.load("kokoro-v1.0.onnx")
    m.graph.node.append(helper.make_node("Identity", ["/encoder/Clip_output_0"], ["duration"]))
    m.graph.output.append(helper.make_tensor_value_info("duration", TensorProto.FLOAT, None))
    onnx.save(m, "kokoro-v1.0-timed.onnx")
print("timed voice model ready")
PY
# speech checker (optional but recommended: catches swallowed words)
if [ ! -d asr/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8 ]; then
  mkdir -p asr && cd asr && curl -sSL -o p.tar.bz2 https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8.tar.bz2 && tar xjf p.tar.bz2 && rm p.tar.bz2
fi
echo "setup done"
