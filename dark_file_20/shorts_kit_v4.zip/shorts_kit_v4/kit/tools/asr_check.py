"""Speech check: transcribes each voice line so swallowed or wrong words show up. Run after tts.py."""
import json, numpy as np, soundfile as sf, sherpa_onnx
from scipy import signal
d = "/home/claude/short/models/asr/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8/"
rec = sherpa_onnx.OfflineRecognizer.from_transducer(encoder=d + "encoder.int8.onnx", decoder=d + "decoder.int8.onnx", joiner=d + "joiner.int8.onnx", tokens=d + "tokens.txt", model_type="nemo_transducer", num_threads=1)
vo, sr = sf.read("/home/claude/short/audio/vo.wav")
tl = json.load(open("/home/claude/short/web/timeline.json"))
for s in tl["segs"]:
    a = vo[int(s["t0"] * sr):int(s["t1"] * sr) + int(0.1 * sr)]
    st = rec.create_stream(); st.accept_waveform(16000, signal.resample_poly(a, 16000, sr).astype(np.float32)); rec.decode_stream(st)
    print(f"{s['i']}: SCRIPT: {s['text']}\n   HEARD: {st.result.text}")
