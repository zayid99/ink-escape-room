#!/bin/bash
# Combine 3D frames + caption layer + mix into final/NAME.mp4.  usage: tools/assemble.sh NAME
set -e; cd /home/claude/short; N=${1:-short}
ffmpeg -loglevel error -y -framerate 30 -i frames/3d/%05d.png -framerate 30 -i frames/ui/%05d.png -i audio/mix.wav \
  -filter_complex "[0:v]vignette=PI/5[b];[b][1:v]overlay,format=yuv420p[v]" -map "[v]" -map 2:a \
  -c:v libx264 -preset slow -crf 19 -r 30 -c:a aac -b:a 256k -movflags +faststart -shortest final/$N.mp4
ffprobe -v error -show_entries format=duration,size -of compact final/$N.mp4
