"""Contact sheet: python3 tools/sheet.py <dir_or_glob> <out.jpg> [cols] [thumb_width] [uidir]"""
import sys, glob, os
from PIL import Image, ImageDraw
src, out = sys.argv[1], sys.argv[2]
cols = int(sys.argv[3]) if len(sys.argv) > 3 else 6
tw = int(sys.argv[4]) if len(sys.argv) > 4 else 270
ui = sys.argv[5] if len(sys.argv) > 5 else None
fs = sorted(glob.glob(os.path.join(src, '*.png'))) if os.path.isdir(src) else sorted(glob.glob(src))
ims = []
for f in fs:
    a = Image.open(f).convert('RGBA')
    if ui and os.path.exists(os.path.join(ui, os.path.basename(f))):
        b = Image.open(os.path.join(ui, os.path.basename(f))).convert('RGBA').resize(a.size)
        a = Image.alpha_composite(a, b)
    th = int(a.size[1] * tw / a.size[0])
    a = a.convert('RGB').resize((tw, th))
    d = ImageDraw.Draw(a); d.rectangle([0, 0, 90, 22], fill=(0, 0, 0)); d.text((4, 4), f"{int(os.path.basename(f)[:5]) / 30:.2f}s", fill=(255, 255, 0))
    ims.append(a)
rows = (len(ims) + cols - 1) // cols
th = ims[0].size[1]
S = Image.new('RGB', (cols * tw, rows * th), (30, 30, 30))
for i, im in enumerate(ims): S.paste(im, ((i % cols) * tw, (i // cols) * th))
S.save(out, quality=88)
print(out, S.size)
