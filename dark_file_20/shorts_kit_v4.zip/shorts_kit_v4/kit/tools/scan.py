"""Frame scan: flags black frames, white haze and sudden jumps that are not at a planned cut.
usage: python3 tools/scan.py [frames/3d] [--cuts 4.28,12.6,...]   (cuts default: read from out/cuts.json if present)
Run it on the finished 3D frames before assembling. Exit code 1 if anything is flagged."""
import sys, os, glob, json
import numpy as np
from PIL import Image

src = 'frames/3d'; cuts = None
args = sys.argv[1:]
for i, a in enumerate(args):
    if a == '--cuts': cuts = [float(x) for x in args[i + 1].split(',')]
    elif not a.startswith('--') and (i == 0 or args[i - 1] != '--cuts'): src = a
ROOT = '/home/claude/short'
if cuts is None and os.path.exists(f'{ROOT}/out/cuts.json'): cuts = json.load(open(f'{ROOT}/out/cuts.json'))
cuts = cuts or []
fs = sorted(glob.glob(os.path.join(ROOT, src, '*.png')))
FPS = 30
cut_frames = {int(round(c * FPS)) for c in cuts} | {int(c * FPS) + 1 for c in cuts} | {int(c * FPS) for c in cuts}
prev = None; diffs = []; bad = []
for f in fs:
    n = int(os.path.basename(f)[:5])
    a = np.asarray(Image.open(f).convert('L').resize((135, 240)), np.float32)
    mean = a.mean(); white = (a > 235).mean()
    if mean < 2.0: bad.append((n, f'BLACK frame (mean {mean:.1f})'))
    if white > 0.2: bad.append((n, f'WHITE haze ({white * 100:.0f}% near-white)'))
    if prev is not None:
        d = np.abs(a - prev).mean(); diffs.append((d, n))
    prev = a
ds = np.array([d for d, _ in diffs]) if diffs else np.zeros(1)
thr = max(12.0, np.median(ds) * 8)
for d, n in diffs:
    if d > thr and n not in cut_frames: bad.append((n, f'JUMP (diff {d:.1f}, median {np.median(ds):.2f}) not at a cut'))
print(f'{len(fs)} frames scanned; median frame diff {np.median(ds):.2f}; jump threshold {thr:.1f}')
print('largest diffs:', ', '.join(f'{n}({d:.1f}{"*cut" if n in cut_frames else ""})' for d, n in sorted(diffs, reverse=True)[:10]))
for n, m in sorted(bad): print(f'  frame {n} ({n / FPS:.2f}s): {m}')
print('CLEAN' if not bad else f'{len(bad)} issue(s)')
sys.exit(1 if bad else 0)
