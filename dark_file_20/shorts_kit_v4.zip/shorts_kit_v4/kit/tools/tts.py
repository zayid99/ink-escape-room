"""Narration: synthesize each segment with exact per-word timings, join with gaps.
Writes audio/vo.wav and web/timeline.json. Prints MISMATCH when display words can't be mapped.
"""
import sys, os, json, re
import numpy as np, soundfile as sf
sys.path.insert(0, os.path.dirname(__file__))
from script_data import SEGS, VOICE, SPEED, LEAD_IN, TAIL, tokens, spoken
from kokoro_onnx import Kokoro

ROOT = "/home/claude/short"
FPS = 30
LEAD_MS = 0.055  # measured model lead before the first phoneme

k = Kokoro(f"{ROOT}/models/kokoro-v1.0-timed.onnx", f"{ROOT}/models/voices-v1.0.bin")
assert k.has_timings
PUNCT = set(".,!?;:—…\"'()“”")


def phon_words(tm):
    """group phoneme timings into words split on spaces; drop pure punctuation groups"""
    words, cur = [], None
    for t in tm:
        if t.phoneme == " ":
            cur = None
            continue
        if all(c in PUNCT for c in t.phoneme):
            continue
        if cur is None:
            cur = [t.phoneme, t.start, t.end]
            words.append(cur)
        else:
            cur[0] += t.phoneme
            cur[2] = t.end
    return words


def n_spoken_words(s):
    ph = k.tokenizer.phonemize(s, "en-us")
    return len([w for w in ph.split(" ") if w and not all(c in PUNCT for c in w)])


def trim(a, sr, thr=0.008, pad=0.03):
    nz = np.where(np.abs(a) > thr)[0]
    s = max(0, nz[0] - int(pad * sr))
    e = min(len(a), nz[-1] + int(pad * 2 * sr))
    return s, e


out, words, segs = [], [], []
t = LEAD_IN
sr = 24000
out.append(np.zeros(int(LEAD_IN * sr), np.float32))
for i, seg in enumerate(SEGS):
    a, sr, tm = k.create_timed(spoken(seg["text"]), voice=VOICE, speed=SPEED, lang="en-us",
                               sentence_pause=0, clause_pause=0)
    s, e = trim(a, sr)
    a = a[s:e]
    shift = s / sr
    pw = phon_words(tm)
    toks = tokens(seg["text"])
    counts = [n if n else n_spoken_words(sp) for _, sp, n in toks]
    if sum(counts) != len(pw):
        print(f"MISMATCH seg {i}: tokens->{sum(counts)} spoken words, model gave {len(pw)}: {[w[0] for w in pw]}")
        # fall back: spread tokens evenly over the model words
        idx = np.linspace(0, len(pw), len(toks) + 1).astype(int)
        groups = [(idx[j], max(idx[j] + 1, idx[j + 1])) for j in range(len(toks))]
    else:
        groups, c = [], 0
        for n in counts:
            groups.append((c, c + n))
            c += n
    for (shown, _, _), (g0, g1) in zip(toks, groups):
        g1 = min(g1, len(pw))
        g0 = min(g0, g1 - 1)
        w0 = pw[g0][1] - LEAD_MS - shift
        w1 = pw[g1 - 1][2] - LEAD_MS - shift
        words.append({"w": shown, "t0": round(t + max(0, w0), 3), "t1": round(t + max(0, w1), 3), "seg": i})
    segs.append({"i": i, "t0": round(t, 3), "t1": round(t + len(a) / sr, 3), "text": seg["text"]})
    out.append(a.astype(np.float32))
    t += len(a) / sr
    if seg["gap"]:
        out.append(np.zeros(int(seg["gap"] * sr), np.float32))
        t += seg["gap"]
out.append(np.zeros(int(TAIL * sr), np.float32))
vo = np.concatenate(out)
os.makedirs(f"{ROOT}/audio", exist_ok=True)
os.makedirs(f"{ROOT}/web", exist_ok=True)
sf.write(f"{ROOT}/audio/vo.wav", vo, sr)
dur = len(vo) / sr
frames = int(np.ceil(dur * FPS))
json.dump({"fps": FPS, "dur": round(dur, 3), "frames": frames, "segs": segs, "words": words},
          open(f"{ROOT}/web/timeline.json", "w"), indent=1)
print(f"duration {dur:.2f}s, frames {frames}")
for s_ in segs:
    print(f"  seg {s_['i']}: {s_['t0']:6.2f} - {s_['t1']:6.2f}  {s_['text'][:60]}")
